import React, { useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import policiesRaw from '../data/policies.json';
import type { PolicyItem } from '../types/sokfarm';
import { SeoHead } from '../components/SeoHead';

const policies: Record<string, PolicyItem> = policiesRaw as Record<string, PolicyItem>;

export const PolicyPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const policy = slug ? policies[slug] : undefined;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [slug]);

  if (!policy) {
    return (
      <>
        <SeoHead
          title="Không tìm thấy chính sách | Sokfarm"
          description="Trang chính sách bạn tìm kiếm không tồn tại."
          canonicalPath="/policy-and-information/chinh-sach-bao-mat"
        />
        <div className="breadcrumbs">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="bread-inner">
                  <ul className="bread-list">
                    <li>
                      <Link to="/">
                        Trang chủ<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                    <li className="active">
                      <span>Không tìm thấy chính sách</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <section className="section py-5">
          <div className="container text-center">
            <h2 className="web-color-origin mb-3">404 - Không tìm thấy trang chính sách</h2>
            <p className="mb-4">Đường dẫn chính sách không tồn tại hoặc đã thay đổi.</p>
            <Link to="/policy-and-information/chinh-sach-bao-mat" className="btn btn-success text-white">
              Xem Chính sách bảo mật Sokfarm
            </Link>
          </div>
        </section>
      </>
    );
  }

  const canonicalPath = `/policy-and-information/${slug}`;

  return (
    <>
      <SeoHead
        title={`${policy.title} | Sokfarm`}
        description={`${policy.title} chính thức của Công ty TNHH Trà Vinh Farm (Sokfarm).`}
        canonicalPath={canonicalPath}
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: policy.title, path: canonicalPath },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to={canonicalPath}>{policy.title}</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="blog-single-main" style={{ padding: '50px 0' }}>
          <div className="row">
            <div className="col-12">
              <div className="blog-detail">
                <div
                  className="content text-justify"
                  dangerouslySetInnerHTML={{ __html: policy.contentHtml }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
