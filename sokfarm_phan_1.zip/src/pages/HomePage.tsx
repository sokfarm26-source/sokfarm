import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  products,
  B2C_CATEGORIES,
  HOME_PRODUCT_TABS,
  getProductsForGrouping,
  getCategoryPath,
  DESKTOP_BANNERS,
  MOBILE_BANNERS,
  TIKTOK_VIDEOS,
  latestRecipes,
  latestBlogs,
  formatBlogDateVi,
} from '../data/siteData';
import { ProductCard } from '../components/ProductCard';
import { CertificateShowcase } from '../components/CertificateShowcase';
import { SeoHead } from '../components/SeoHead';
import { YouTubeFacade } from '../components/YouTubeFacade';
import { useApp } from '../context/AppContext';

const HAPPY_GALLERY_IMAGES = [
  { thumb: '/images/opt/nnhp/hinh_1.webp', full: '/images/opt/nnhp-full/hinh_1.webp', w: 570, h: 205, alt: 'Toàn cảnh vùng nguyên liệu dừa hữu cơ Sokfarm xanh mát nhìn từ trên cao tại Trà Vinh' },
  { thumb: '/images/opt/nnhp/hinh_2.webp', full: '/images/opt/nnhp-full/hinh_2.webp', w: 570, h: 205, alt: 'Đội ngũ Sokfarm chào đón khách hàng bằng nghi thức chắp tay thân thiện của người Khmer' },
  { thumb: '/images/opt/nnhp/hinh_3.webp', full: '/images/opt/nnhp-full/hinh_3.webp', w: 285, h: 416, alt: 'Nông dân Sokfarm mang những bình mật hoa dừa tươi vừa thu hoạch từ vườn dừa' },
  { thumb: '/images/opt/nnhp/hinh_7.webp', full: '/images/opt/nnhp-full/hinh_7.webp', w: 285, h: 205, alt: 'Hoạt động hướng dẫn học tập và chăm lo thế hệ trẻ tại cộng đồng Sokfarm' },
  { thumb: '/images/opt/nnhp/hinh_4.webp', full: '/images/opt/nnhp-full/hinh_4.webp', w: 570, h: 205, alt: 'Đại diện Sokfarm nhận giải thưởng và bằng khen nông nghiệp tiêu biểu' },
  { thumb: '/images/opt/nnhp/hinh_5.webp', full: '/images/opt/nnhp-full/hinh_5.webp', w: 570, h: 205, alt: 'Tập thể nông dân và nhân viên Sokfarm chụp ảnh kỷ niệm tại vườn dừa Trà Vinh' },
  { thumb: '/images/opt/nnhp/hinh_8.webp', full: '/images/opt/nnhp-full/hinh_8.webp', w: 285, h: 205, alt: 'Nhân viên nhà máy Sokfarm kiểm tra và đóng gói chai mật hoa dừa cô đặc đạt chuẩn an toàn thực phẩm' },
  { thumb: '/images/opt/nnhp/hinh_9.webp', full: '/images/opt/nnhp-full/hinh_9.webp', w: 285, h: 205, alt: 'Đại diện Sokfarm giới thiệu sản phẩm mật hoa dừa hữu cơ với đối tác quốc tế' },
  { thumb: '/images/opt/nnhp/hinh_6.webp', full: '/images/opt/nnhp-full/hinh_6.webp', w: 285, h: 625, alt: 'Người thợ thu mật Sokfarm thực hiện kỹ thuật mát-xa cụm hoa dừa truyền thống trên cây' },
];

const HOME_CATEGORY_CARDS = [
  { slug: 'mat-hoa-dua-tuoi', repSlug: 'mat-hoa-dua-tuoi-huu-co-330ml', tagline: 'Giải khát & bù khoáng tự nhiên' },
  { slug: 'mat-hoa-dua-co-dac', repSlug: 'mat-hoa-dua-co-dac-huu-co', tagline: 'Cô đặc chân không 55-60°C' },
  { slug: 'duong-hoa-dua', repSlug: 'duong-hoa-dua-huu-co', tagline: 'Không tinh luyện, giữ trọn mật' },
  { slug: 'do-uong', repSlug: 'mat-hoa-dua-matcha-330ml', tagline: 'Thức uống thuần thực vật' },
  { slug: 'gia-vi', repSlug: 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban', tagline: 'Lên men tự nhiên không đậu nành' },
  { slug: 'san-pham-cho-be', repSlug: 'nuoc-tuong-mat-hoa-dua-huu-co-cho-be', tagline: 'Thuần thực vật an lành cho bé' },
  { slug: 'qua-tang', repSlug: 'bo-qua-tang-hanh-phuc', tagline: 'Hộp quà sức khỏe Trà Vinh' },
];

export const HomePage: React.FC = () => {
  const { lang } = useApp();
  const isEn = lang === 'en';

  const [desktopSlide, setDesktopSlide] = useState(0);
  const [mobileSlide, setMobileSlide] = useState(0);
  const [isMobileViewport, setIsMobileViewport] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.matchMedia('(max-width: 767.98px)').matches : false
  );
  const [activeCategorySlug, setActiveCategorySlug] = useState(HOME_PRODUCT_TABS[0].slug);
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  const statsRef = useRef<HTMLElement | null>(null);
  const tiktokSectionRef = useRef<HTMLElement | null>(null);
  const [animatedOnce, setAnimatedOnce] = useState(false);
  const [tiktokRequested, setTiktokRequested] = useState(false);
  const [counts, setCounts] = useState({ hectar: 25, incre: 3, local: 280, ton: 70 });

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mql = window.matchMedia('(max-width: 767.98px)');
    setIsMobileViewport(mql.matches);
    const onChange = (e: MediaQueryListEvent) => setIsMobileViewport(e.matches);
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setDesktopSlide((s) => (s + 1) % DESKTOP_BANNERS.length);
      setMobileSlide((s) => (s + 1) % MOBILE_BANNERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (lightboxIdx === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightboxIdx(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [lightboxIdx]);

  useEffect(() => {
    const onScroll = () => {
      if (animatedOnce || !statsRef.current) return;
      const rect = statsRef.current.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        setAnimatedOnce(true);
        const duration = 2000;
        const start = performance.now();
        const targets = { hectar: 25, incre: 3, local: 280, ton: 70 };
        const step = (now: number) => {
          const p = Math.min((now - start) / duration, 1);
          setCounts({
            hectar: Math.floor(p * targets.hectar),
            incre: Math.floor(p * targets.incre),
            local: Math.floor(p * targets.local),
            ton: Math.floor(p * targets.ton),
          });
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [animatedOnce]);

  useEffect(() => {
    const el = tiktokSectionRef.current;
    if (!el || tiktokRequested) return;
    if (!('IntersectionObserver' in window)) {
      setTiktokRequested(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setTiktokRequested(true);
          observer.disconnect();
        }
      },
      { rootMargin: '300px 0px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [tiktokRequested]);

  useEffect(() => {
    if (!tiktokRequested) return;
    const existing = document.querySelector('script[src="https://www.tiktok.com/embed.js"]');
    if (existing) return;
    const s = document.createElement('script');
    s.src = 'https://www.tiktok.com/embed.js';
    s.async = true;
    document.body.appendChild(s);
  }, [tiktokRequested]);

  const visibleProducts = getProductsForGrouping(activeCategorySlug);

  return (
    <>
      <SeoHead
        title="Sokfarm - Mật Hoa Dừa Hữu Cơ Trà Vinh"
        description="Sokfarm là nhà sản xuất, kinh doanh và xuất khẩu các sản phẩm từ mật hoa dừa hữu cơ tại Việt Nam."
        canonicalPath="/"
        breadcrumbs={[{ name: 'Trang chủ', path: '/' }]}
      />

      {/* 1. BANNER CHÍNH */}
      {!isMobileViewport && (
        <section
          id="Gslider"
          className="carousel slide d-none d-md-block d-lg-block"
          aria-roledescription="carousel"
          aria-label="Banner nổi bật Sokfarm"
        >
          <div className="carousel-indicators">
            {DESKTOP_BANNERS.map((_, i) => (
              <button
                key={i}
                type="button"
                aria-label={`Chọn banner ${i + 1}`}
                aria-current={desktopSlide === i ? 'true' : undefined}
                className={desktopSlide === i ? 'active' : ''}
                onClick={() => setDesktopSlide(i)}
              />
            ))}
          </div>
          <div className="carousel-inner">
            {DESKTOP_BANNERS.map((banner, i) => {
              const pictureEl = (
                <picture>
                  <source type="image/webp" srcSet={banner.srcSet} sizes="100vw" />
                  <img
                    className="first-slide"
                    src={banner.fallbackSrc}
                    width={banner.width}
                    height={banner.height}
                    fetchPriority={i === 0 ? 'high' : undefined}
                    loading={i === 0 ? undefined : 'lazy'}
                    decoding={i === 0 ? 'sync' : 'async'}
                    alt={banner.alt}
                  />
                </picture>
              );

              return (
                <div key={i} className={`carousel-item ${desktopSlide === i ? 'active' : ''}`}>
                  <div className="sokfarm-banner-stage">
                    {banner.href ? <Link to={banner.href}>{pictureEl}</Link> : pictureEl}
                    {banner.ctaHotspot && (
                      <Link
                        to={banner.ctaHotspot.to}
                        className="sokfarm-banner-cta-hotspot"
                        aria-label={banner.ctaHotspot.ariaLabel}
                        style={{
                          left: banner.ctaHotspot.left,
                          top: banner.ctaHotspot.top,
                          width: banner.ctaHotspot.width,
                          height: banner.ctaHotspot.height,
                        }}
                      />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          <button
            type="button"
            className="carousel-control-prev"
            aria-label="Banner trước"
            onClick={() =>
              setDesktopSlide((s) => (s - 1 + DESKTOP_BANNERS.length) % DESKTOP_BANNERS.length)
            }
          >
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          </button>
          <button
            type="button"
            className="carousel-control-next"
            aria-label="Banner tiếp theo"
            onClick={() => setDesktopSlide((s) => (s + 1) % DESKTOP_BANNERS.length)}
          >
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
          </button>
        </section>
      )}

      {isMobileViewport && (
        <section
          id="GsliderMobile"
          className="carousel slide d-block d-md-none d-lg-none"
          aria-roledescription="carousel"
          aria-label="Banner di động Sokfarm"
        >
          <div className="carousel-indicators">
            {MOBILE_BANNERS.map((_, i) => (
              <button
                key={i}
                type="button"
                aria-label={`Chọn banner ${i + 1}`}
                aria-current={mobileSlide === i ? 'true' : undefined}
                className={mobileSlide === i ? 'active' : ''}
                onClick={() => setMobileSlide(i)}
              />
            ))}
          </div>
          <div className="carousel-inner">
            {MOBILE_BANNERS.map((banner, i) => (
              <div key={i} className={`carousel-item ${mobileSlide === i ? 'active' : ''}`}>
                <div className="sokfarm-banner-stage" style={{ aspectRatio: banner.aspectRatio }}>
                  <picture>
                    <source type="image/webp" srcSet={banner.srcSet} sizes="100vw" />
                    <img
                      className="first-slide"
                      src={banner.fallbackSrc}
                      width={banner.width}
                      height={banner.height}
                      fetchPriority={i === 0 ? 'high' : undefined}
                      loading={i === 0 ? undefined : 'lazy'}
                      decoding={i === 0 ? 'sync' : 'async'}
                      alt={banner.alt}
                    />
                  </picture>
                  {banner.ctaHotspot && (
                    <Link
                      to={banner.ctaHotspot.to}
                      className="sokfarm-banner-cta-hotspot"
                      aria-label={banner.ctaHotspot.ariaLabel}
                      style={{
                        left: banner.ctaHotspot.left,
                        top: banner.ctaHotspot.top,
                        width: banner.ctaHotspot.width,
                        height: banner.ctaHotspot.height,
                      }}
                    />
                  )}
                </div>
              </div>
            ))}
          </div>
          <button
            type="button"
            className="carousel-control-prev"
            aria-label="Banner trước"
            onClick={() =>
              setMobileSlide((s) => (s - 1 + MOBILE_BANNERS.length) % MOBILE_BANNERS.length)
            }
          >
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          </button>
          <button
            type="button"
            className="carousel-control-next"
            aria-label="Banner tiếp theo"
            onClick={() => setMobileSlide((s) => (s + 1) % MOBILE_BANNERS.length)}
          >
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
          </button>
        </section>
      )}

      {/* Hero Value Proposition & Direct Action Band */}
      <section className="py-4" style={{ backgroundColor: '#fbf4eb', borderBottom: '1px solid #e5ece7' }}>
        <div className="container">
          <div className="row align-items-center" style={{ rowGap: '16px' }}>
            <div className="col-12 col-lg-8">
              <h1 className="web-color-origin mb-2" style={{ fontSize: 'clamp(1.5rem, 2.8vw, 2.25rem)', lineHeight: 1.25 }}>
                {isEn
                  ? 'Sokfarm — Organic Coconut Flower Nectar From Tra Vinh'
                  : 'Sokfarm — Tinh hoa mật hoa dừa hữu cơ Trà Vinh'}
              </h1>
              <p className="mb-0" style={{ color: '#2b2b2b', fontSize: '15.5px', lineHeight: 1.6, maxWidth: '720px' }}>
                {isEn
                  ? 'Hand-harvested using traditional Khmer flower-massage techniques, low-temperature processed, plant-based & low GI for everyday health.'
                  : 'Thu hoạch thủ công bằng kỹ thuật mát-xa hoa dừa truyền thống của người Khmer Nam Bộ, chế biến nhiệt độ thấp, 100% thuần thực vật và giàu khoáng chất tự nhiên.'}
              </p>
            </div>
            <div className="col-12 col-lg-4 d-flex flex-wrap align-items-center justify-content-lg-end" style={{ gap: '10px' }}>
              <Link
                to="/san-pham"
                className="btn btn-success text-white px-4 py-2"
                style={{
                  backgroundColor: '#158247',
                  borderColor: '#158247',
                  minHeight: '44px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  fontWeight: 600,
                }}
              >
                {isEn ? 'Explore Products' : 'Khám phá sản phẩm'}
              </Link>
              <Link
                to="/about-us"
                className="btn btn-outline-success px-3 py-2"
                style={{
                  borderColor: '#158247',
                  color: '#158247',
                  minHeight: '44px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  fontWeight: 600,
                }}
              >
                {isEn ? 'Learn About Sokfarm' : 'Tìm hiểu Sokfarm'}
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. DANH MỤC SẢN PHẨM */}
      <section className="py-5 bg-white" aria-labelledby="home-categories-heading">
        <div className="container">
          <div className="d-flex flex-column flex-md-row align-items-md-end justify-content-between mb-4" style={{ gap: '12px' }}>
            <div>
              <h2 id="home-categories-heading" className="web-color-origin mb-1" style={{ fontSize: '28px' }}>
                {isEn ? 'Product Categories' : 'Danh mục sản phẩm'}
              </h2>
              <p className="mb-0" style={{ color: '#4a554e', fontSize: '15px' }}>
                {isEn
                  ? 'Explore natural coconut flower sweeteners, beverages, organic seasonings, and gift boxes.'
                  : 'Chọn nhanh theo từng dòng sản phẩm hữu cơ từ hoa dừa Sokfarm.'}
              </p>
            </div>
            <Link
              to="/san-pham"
              className="btn btn-sm btn-outline-success align-self-start align-self-md-end"
              style={{ borderColor: '#158247', color: '#158247', fontWeight: 600, minHeight: '38px', display: 'inline-flex', alignItems: 'center' }}
            >
              Xem tất cả sản phẩm &rarr;
            </Link>
          </div>

          <div className="row" style={{ rowGap: '16px' }}>
            {HOME_CATEGORY_CARDS.map((card) => {
              const cat = B2C_CATEGORIES.find((c) => c.slug === card.slug);
              const repProd = products.find((p) => p.slug === card.repSlug);
              if (!cat) return null;
              return (
                <div key={cat.slug} className="col-6 col-md-4 col-lg-3">
                  <Link
                    to={getCategoryPath(cat.slug)}
                    className="d-flex flex-column h-100 p-3 rounded border text-decoration-none sokfarm-cat-card"
                    style={{ backgroundColor: '#fbf4eb', borderColor: '#d7e6dc', color: '#222' }}
                  >
                    <div
                      className="bg-white rounded mb-3 d-flex align-items-center justify-content-center p-2"
                      style={{ aspectRatio: '1 / 1', width: '100%' }}
                    >
                      {repProd && (
                        <img
                          src={repProd.defaultImg}
                          alt={isEn ? `${cat.nameEn} Sokfarm` : `Danh mục ${cat.name} Sokfarm`}
                          width={240}
                          height={240}
                          loading="lazy"
                          decoding="async"
                          style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                        />
                      )}
                    </div>
                    <h3 className="web-color-origin mb-1" style={{ fontSize: '16px', fontWeight: 700 }}>
                      {isEn ? cat.nameEn : cat.name}
                    </h3>
                    <p className="mb-0" style={{ fontSize: '13px', color: '#444', lineHeight: 1.45 }}>
                      {card.tagline}
                    </p>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. SẢN PHẨM NỔI BẬT */}
      <section className="product-area py-5" style={{ backgroundColor: '#f8faf8' }} aria-labelledby="featured-products-heading">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 id="featured-products-heading" className="web-color-origin mb-2 text-center text-md-left" style={{ fontSize: '28px' }}>
                {isEn ? 'Featured Products' : 'Sản phẩm nổi bật từ mật hoa dừa'}
              </h2>
              <p className="mb-0" style={{ fontSize: '15px', color: '#444', maxWidth: '860px' }}>
                Mật hoa dừa không phải mật ong, mà là vị ngọt thuần thực vật thu từ hoa dừa với chỉ số đường huyết thấp, phù hợp cho gia đình, người ăn chay và chế độ ăn lành mạnh.
              </p>
            </div>
          </div>

          <div className="row mt-4">
            <div className="col-12">
              <div className="text-center mb-3" role="tablist" aria-label="Danh mục sản phẩm nổi bật Sokfarm">
                {HOME_PRODUCT_TABS.map((cat) => (
                  <button
                    key={cat.slug}
                    type="button"
                    role="tab"
                    aria-selected={activeCategorySlug === cat.slug}
                    onClick={() => setActiveCategorySlug(cat.slug)}
                    className={`category-title-list ${activeCategorySlug === cat.slug ? 'active' : ''}`}
                    data-categoryid={cat.id}
                    style={{ background: activeCategorySlug === cat.slug ? '#158247' : '#fff' }}
                  >
                    {isEn ? cat.nameEn : cat.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="col-12">
              <div className="product-info mt-3">
                <div className="tab-content isotope-grid" id="myTabContent">
                  <div className="row">
                    {visibleProducts.map((prod) => (
                      <ProductCard key={prod.slug} product={prod} variant="home" />
                    ))}
                  </div>
                </div>
                <div className="d-flex flex-wrap justify-content-center mt-4" style={{ gap: '12px' }}>
                  <Link
                    to="/san-pham/ban-chay-nhat"
                    className="btn btn-outline-success px-4 py-2"
                    style={{ borderColor: '#158247', color: '#158247', minHeight: '44px', display: 'inline-flex', alignItems: 'center', fontWeight: 600 }}
                  >
                    {isEn ? 'View Best Sellers' : 'Xem sản phẩm bán chạy nhất'}
                  </Link>
                  <Link
                    to="/san-pham"
                    className="btn btn-success text-white px-4 py-2"
                    style={{ backgroundColor: '#158247', borderColor: '#158247', minHeight: '44px', display: 'inline-flex', alignItems: 'center', fontWeight: 600 }}
                  >
                    {isEn ? 'View All Products' : 'Xem tất cả & lọc sản phẩm'}
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. CHỨNG NHẬN HỮU CƠ & CHẤT LƯỢNG */}
      <CertificateShowcase
        sectionId="home-chung-nhan"
        title={isEn ? 'Organic & Quality Certifications' : 'Chứng nhận hữu cơ & Chất lượng'}
        subtitle={
          isEn
            ? 'Sokfarm products satisfy USDA, EU, JAS, Canada Organic, ISO 22000:2018, FDA, HALAL, and national OCOP 5-Star standards.'
            : 'Các dòng sản phẩm mật hoa dừa Sokfarm đáp ứng đồng thời tiêu chuẩn hữu cơ USDA, EU, JAS, Canada, an toàn thực phẩm ISO 22000:2018, FDA, HALAL và OCOP 5 sao.'
        }
      />

      {/* 5. CÂU CHUYỆN VÙNG NGUYÊN LIỆU */}
      <section className="introduce py-5" style={{ backgroundColor: '#fbf4eb' }} aria-labelledby="origin-story-heading">
        <div className="container">
          <div className="row introduce-home-page align-items-center mb-5">
            <div className="col-md-12 col-lg-5">
              <img
                src="/images/opt/ui/Sokfarm-NNHP.webp"
                width={840}
                height={238}
                loading="lazy"
                decoding="async"
                style={{ width: '100%', height: 'auto' }}
                alt="Sokfarm Nông nghiệp hạnh phúc"
                className="mb-3"
              />
              <h2 id="origin-story-heading" className="web-color-origin mb-3" style={{ fontSize: '26px' }}>
                {isEn ? 'Tra Vinh Organic Coconut Region Story' : 'Câu chuyện vùng nguyên liệu Trà Vinh'}
              </h2>
              <p className="description mt-1" style={{ fontSize: '15.5px', color: '#2b2b2b', lineHeight: 1.65 }}>
                Dưới những rặng dừa xanh mướt của vùng sông nước miền Tây, Sokfarm tự hào là Doanh nghiệp đầu tiên tại Việt Nam kế thừa và nối tiếp ngành nghề thu mật hoa dừa truyền thống của người Khmer Nam Bộ.
              </p>
              <p className="description mb-3" style={{ fontSize: '15.5px', color: '#2b2b2b', lineHeight: 1.65 }}>
                Chúng tôi theo đuổi mô hình Nông nghiệp Hạnh phúc tạo tác động xã hội, mang lại sinh kế bền vững cho người nông dân trước thách thức xâm nhập mặn và bảo tồn giá trị bản địa.
              </p>
              <Link
                to="/phat-trien-ben-vung"
                className="btn btn-outline-success"
                style={{ borderColor: '#158247', color: '#158247', fontWeight: 600 }}
              >
                Tìm hiểu Phát triển bền vững &rarr;
              </Link>
            </div>
            <div className="col-md-12 col-lg-7 mt-4 mt-lg-0">
              <YouTubeFacade
                videoId="fJFz3h-idC8"
                title="SOKFARM - NÔNG NGHIỆP HẠNH PHÚC"
                height={420}
              />
            </div>
          </div>

          {/* 6 Sustainable Pillars */}
          <div className="row mb-5">
            <div className="col-4 col-md-2 mb-3 mb-md-0">
              <div className="rounded-circle bg-white tyle-dn">
                <img src="/images/icon_sok1.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '100%', height: 'auto' }} alt="Sản phẩm hữu cơ" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Organic Products' : 'Sản phẩm hữu cơ'}
              </div>
            </div>
            <div className="col-4 col-md-2 mb-3 mb-md-0">
              <div className="rounded-circle bg-white tyle-dn">
                <img src="/images/icon_sok2.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '100%', height: 'auto' }} alt="Sinh kế bền vững" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Sustainable Livelihood' : 'Sinh kế bền vững'}
              </div>
            </div>
            <div className="col-4 col-md-2 mb-3 mb-md-0">
              <div className="rounded-circle bg-white tyle-dn">
                <img src="/images/icon_sok3.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '100%', height: 'auto' }} alt="Thích nghi biến đổi khí hậu" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Climate Adaptation' : 'Thích nghi biến đổi khí hậu'}
              </div>
            </div>
            <div className="col-4 col-md-2">
              <div className="rounded-circle bg-white tyle-dn">
                <img src="/images/icon_sok4.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '100%', height: 'auto' }} alt="Thuần thực vật" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Plant-based / Vegan' : 'Thuần thực vật / Thuần chay'}
              </div>
            </div>
            <div className="col-4 col-md-2">
              <div className="rounded-circle bg-white tyle-dn">
                <img src="/images/icon_sok5.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '100%', height: 'auto' }} alt="Nghề truyền thống" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Traditional Craft' : 'Nghề truyền thống'}
              </div>
            </div>
            <div className="col-4 col-md-2">
              <div className="rounded-circle bg-white text-center tyle-dn">
                <img src="/images/icon_sok6.svg" width={120} height={120} loading="lazy" decoding="async" style={{ width: '80%', height: 'auto' }} alt="Hương vị phù sa" />
              </div>
              <div className="text-center mt-2 web-color-origin sokfarm-pillar-label">
                {isEn ? 'Alluvial Flavor' : 'Hương vị phù sa'}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Green Stats Banner + Standards + Photo Mosaic inside Region Story */}
      <section
        ref={statsRef}
        className="introduce py-5 nb-run-animation"
        id="nb-run-animation"
        style={{ backgroundColor: '#158247' }}
      >
        <div className="container">
          <div className="row introduce-home-page align-items-center">
            <div className="col-md-12 col-lg-5">
              <p className="description mt-1 text-white mb-0" style={{ fontSize: '15.5px', lineHeight: 1.65 }}>
                Trà Vinh có hơn 25.000 hectar dừa và tình trạng xâm nhập mặn tại vùng Đồng Bằng sông Cửu Long thường làm giảm 30–70% năng suất thu hoạch trái dừa. Bằng kỹ thuật mát-xa hoa dừa thu mật truyền thống và chế biến sâu, Sokfarm giúp nông dân gia tăng giá trị kinh tế gấp 3–5 lần so với bán trái dừa thô.
              </p>
            </div>
            <div className="col-md-12 col-lg-7 mt-4 mt-lg-0">
              <div className="row">
                <div className="col-6">
                  <div className="text-center m-2">
                    <div className="text-white font-weight-bold sokfarm-stat-number">
                      <span id="hectar-coconut">{counts.hectar}</span>+
                    </div>
                    <h3 className="h6 text-white">Hectar vùng dừa hữu cơ</h3>
                  </div>
                </div>
                <div className="col-6">
                  <div className="text-center m-2">
                    <div className="text-white font-weight-bold sokfarm-stat-number">
                      <span id="incre-economy">{counts.incre}</span>+
                    </div>
                    <h3 className="h6 text-white">Lần tăng giá trị kinh tế</h3>
                  </div>
                </div>
                <div className="col-6">
                  <div className="text-center m-2">
                    <div className="text-white font-weight-bold sokfarm-stat-number">
                      <span id="local-people">{counts.local}</span>+
                    </div>
                    <h3 className="h6 text-white">Người dân địa phương</h3>
                  </div>
                </div>
                <div className="col-6">
                  <div className="text-center m-2">
                    <div className="text-white font-weight-bold sokfarm-stat-number">
                      <span id="ton-coconut">{counts.ton}</span>+
                    </div>
                    <h3 className="h6 text-white">Tấn mật hoa dừa tươi/ha</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3 Standards & Happy Enterprise Mosaic */}
      <section className="introduce py-5 bg-white">
        <div className="container">
          <div className="row introduce-home-page mb-5" style={{ rowGap: '16px' }}>
            <div className="col-12 col-md-4">
              <div className="h-100 rounded overflow-hidden" style={{ background: '#f3f8f5' }}>
                <img
                  src="/images/opt/cards/hinh_1.webp"
                  width={720}
                  height={480}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '100%', height: 'auto' }}
                  alt="Sokfarm tiêu chuẩn hữu cơ quốc tế về trồng dừa"
                />
                <div className="py-3 px-4">
                  <h3 className="h5 web-color-origin mb-2">Tiêu chuẩn hữu cơ quốc tế</h3>
                  <p className="mb-0" style={{ fontSize: '14.5px', color: '#333' }}>
                    Sử dụng đất và nước hữu cơ, loại bỏ hoàn toàn phân bón hóa học để sản phẩm an toàn cho sức khỏe và thân thiện môi trường.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-12 col-md-4">
              <div className="h-100 rounded overflow-hidden" style={{ background: '#f3f8f5' }}>
                <img
                  src="/images/opt/cards/hinh_2.webp"
                  width={720}
                  height={480}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '100%', height: 'auto' }}
                  alt="Tiêu chuẩn ngành nghề truyền thống"
                />
                <div className="py-3 px-4">
                  <h3 className="h5 web-color-origin mb-2">Ngành nghề truyền thống</h3>
                  <p className="mb-0" style={{ fontSize: '14.5px', color: '#333' }}>
                    Phục dựng và nâng tầm nghề mát-xa hoa dừa lấy mật truyền thống của cộng đồng người Khmer Nam Bộ tại Trà Vinh.
                  </p>
                </div>
              </div>
            </div>
            <div className="col-12 col-md-4">
              <div className="h-100 rounded overflow-hidden" style={{ background: '#f3f8f5' }}>
                <img
                  src="/images/opt/cards/hinh_3.webp"
                  width={720}
                  height={480}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '100%', height: 'auto' }}
                  alt="Tiêu chuẩn phát triển bền vững"
                />
                <div className="py-3 px-4">
                  <h3 className="h5 web-color-origin mb-2">Phát triển bền vững</h3>
                  <p className="mb-0" style={{ fontSize: '14.5px', color: '#333' }}>
                    Thu mật hàng tháng không gây hại cây dừa, giúp ổn định thu nhập quanh năm và giảm áp lực sinh kế cho nông hộ.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <h3 className="web-color-origin mb-3 text-center text-md-left" style={{ fontSize: '24px' }}>
            {isEn ? 'Happy Enterprise Gallery' : 'Hình ảnh Nông nghiệp Hạnh phúc'}
          </h3>
          <div className="row no-gutters introduce-home-page nongnghiephanhphuc overflow-hidden">
            {[0, 1].map((idx) => (
              <div key={idx} className="col-6 p-0">
                <button
                  type="button"
                  aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[idx].alt}`}
                  onClick={() => setLightboxIdx(idx)}
                  style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
                >
                  <img
                    src={HAPPY_GALLERY_IMAGES[idx].thumb}
                    width={HAPPY_GALLERY_IMAGES[idx].w}
                    height={HAPPY_GALLERY_IMAGES[idx].h}
                    loading="lazy"
                    decoding="async"
                    className={`w-100 ${idx === 0 ? 'img-fluid' : ''}`}
                    style={{ height: 'auto' }}
                    alt={HAPPY_GALLERY_IMAGES[idx].alt}
                  />
                </button>
              </div>
            ))}
            <div className="col-3 p-0">
              <div className="row no-gutters">
                {[2, 3].map((idx) => (
                  <div key={idx} className="col-12">
                    <button
                      type="button"
                      aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[idx].alt}`}
                      onClick={() => setLightboxIdx(idx)}
                      style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
                    >
                      <img
                        src={HAPPY_GALLERY_IMAGES[idx].thumb}
                        width={HAPPY_GALLERY_IMAGES[idx].w}
                        height={HAPPY_GALLERY_IMAGES[idx].h}
                        loading="lazy"
                        decoding="async"
                        className="w-100"
                        style={{ height: 'auto' }}
                        alt={HAPPY_GALLERY_IMAGES[idx].alt}
                      />
                    </button>
                  </div>
                ))}
              </div>
            </div>
            <div className="col-6 p-0">
              <div className="row no-gutters">
                {[4, 5].map((idx) => (
                  <div key={idx} className="col-12">
                    <button
                      type="button"
                      aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[idx].alt}`}
                      onClick={() => setLightboxIdx(idx)}
                      style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
                    >
                      <img
                        src={HAPPY_GALLERY_IMAGES[idx].thumb}
                        width={HAPPY_GALLERY_IMAGES[idx].w}
                        height={HAPPY_GALLERY_IMAGES[idx].h}
                        loading="lazy"
                        decoding="async"
                        className="w-100"
                        style={{ height: 'auto' }}
                        alt={HAPPY_GALLERY_IMAGES[idx].alt}
                      />
                    </button>
                  </div>
                ))}
                <div className="col-6 pr-0">
                  <button
                    type="button"
                    aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[6].alt}`}
                    onClick={() => setLightboxIdx(6)}
                    style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
                  >
                    <img
                      src={HAPPY_GALLERY_IMAGES[6].thumb}
                      width={HAPPY_GALLERY_IMAGES[6].w}
                      height={HAPPY_GALLERY_IMAGES[6].h}
                      loading="lazy"
                      decoding="async"
                      className="w-100"
                      style={{ height: 'auto' }}
                      alt={HAPPY_GALLERY_IMAGES[6].alt}
                    />
                  </button>
                </div>
                <div className="col-6 pl-0">
                  <button
                    type="button"
                    aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[7].alt}`}
                    onClick={() => setLightboxIdx(7)}
                    style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
                  >
                    <img
                      src={HAPPY_GALLERY_IMAGES[7].thumb}
                      width={HAPPY_GALLERY_IMAGES[7].w}
                      height={HAPPY_GALLERY_IMAGES[7].h}
                      loading="lazy"
                      decoding="async"
                      className="w-100"
                      style={{ height: 'auto' }}
                      alt={HAPPY_GALLERY_IMAGES[7].alt}
                    />
                  </button>
                </div>
              </div>
            </div>
            <div className="col-3 p-0">
              <button
                type="button"
                aria-label={`Xem phóng lớn ${HAPPY_GALLERY_IMAGES[8].alt}`}
                onClick={() => setLightboxIdx(8)}
                style={{ border: 0, padding: 0, width: '100%', display: 'block', background: 'transparent', cursor: 'pointer' }}
              >
                <img
                  src={HAPPY_GALLERY_IMAGES[8].thumb}
                  width={HAPPY_GALLERY_IMAGES[8].w}
                  height={HAPPY_GALLERY_IMAGES[8].h}
                  loading="lazy"
                  decoding="async"
                  className="w-100"
                  style={{ height: 'auto' }}
                  alt={HAPPY_GALLERY_IMAGES[8].alt}
                />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox Modal */}
      {lightboxIdx !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Thư viện ảnh Nông nghiệp hạnh phúc Sokfarm"
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.82)',
            zIndex: 999999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
          onClick={() => setLightboxIdx(null)}
        >
          <div
            style={{ position: 'relative', maxWidth: '1000px', width: '100%', maxHeight: '90vh' }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              aria-label="Đóng thư viện ảnh"
              onClick={() => setLightboxIdx(null)}
              style={{
                position: 'absolute',
                top: '8px',
                right: '8px',
                background: 'rgba(0,0,0,0.65)',
                border: 'none',
                color: '#fff',
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                fontSize: '28px',
                lineHeight: 1,
                zIndex: 2,
                cursor: 'pointer',
              }}
            >
              &times;
            </button>
            <img
              src={HAPPY_GALLERY_IMAGES[lightboxIdx].full}
              alt={HAPPY_GALLERY_IMAGES[lightboxIdx].alt}
              style={{ maxWidth: '100%', maxHeight: '85vh', borderRadius: '6px' }}
            />
            <button
              type="button"
              aria-label="Ảnh trước"
              onClick={() =>
                setLightboxIdx((i) =>
                  i === null ? 0 : (i - 1 + HAPPY_GALLERY_IMAGES.length) % HAPPY_GALLERY_IMAGES.length
                )
              }
              style={{
                position: 'absolute',
                left: '10px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(0,0,0,0.5)',
                color: '#fff',
                border: 'none',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                cursor: 'pointer',
              }}
            >
              &#10094;
            </button>
            <button
              type="button"
              aria-label="Ảnh tiếp theo"
              onClick={() =>
                setLightboxIdx((i) => (i === null ? 0 : (i + 1) % HAPPY_GALLERY_IMAGES.length))
              }
              style={{
                position: 'absolute',
                right: '10px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(0,0,0,0.5)',
                color: '#fff',
                border: 'none',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                cursor: 'pointer',
              }}
            >
              &#10095;
            </button>
          </div>
        </div>
      )}

      {/* 6. CÔNG THỨC SỬ DỤNG (& Tin tức / Video) */}
      <section className="shop-blog py-5" style={{ backgroundColor: '#f8faf8' }} aria-labelledby="recipes-heading">
        <div className="container">
          <div className="d-flex flex-column flex-md-row align-items-md-end justify-content-between mb-4" style={{ gap: '12px' }}>
            <div>
              <h2 id="recipes-heading" className="web-color-origin mb-1" style={{ fontSize: '28px' }}>
                {isEn ? 'Recipes & Usage Inspiration' : 'Công thức sử dụng mật hoa dừa'}
              </h2>
              <p className="mb-0" style={{ color: '#444', fontSize: '15px' }}>
                Ứng dụng mật hoa dừa cô đặc, đường hoa dừa và gia vị hữu cơ vào pha chế thức uống và món ngon mỗi ngày.
              </p>
            </div>
            <Link
              to="/goc-kham-pha/cong-thuc-che-bien"
              className="btn btn-sm btn-outline-success align-self-start align-self-md-end"
              style={{ borderColor: '#158247', color: '#158247', fontWeight: 600, minHeight: '38px', display: 'inline-flex', alignItems: 'center' }}
            >
              Xem tất cả công thức &rarr;
            </Link>
          </div>

          <div className="row" style={{ rowGap: '16px' }}>
            {latestRecipes.map((recipe) => {
              const recipeSrcSet =
                recipe.img.startsWith('/images/opt/recipes/') && recipe.img.endsWith('-640w.webp')
                  ? `${recipe.img.slice(0, -'-640w.webp'.length)}-360w.webp 360w, ${recipe.img} 640w`
                  : undefined;
              const recipeUrl = recipe.customPath || `/tin-tuc/${recipe.slug}`;
              return (
                <div key={recipe.slug} className="col-sm-6 col-lg-3">
                  <Link to={recipeUrl} className="text-decoration-none d-block h-100">
                    <article className="shop-single-blog h-100 bg-white rounded border p-2 d-flex flex-column" style={{ borderColor: '#e5ece7' }}>
                      <div style={{ position: 'relative' }}>
                        <img
                          src={recipe.img}
                          srcSet={recipeSrcSet}
                          sizes="(max-width: 767.98px) 92vw, 320px"
                          alt={recipe.imgAlt || recipe.title}
                          width={360}
                          height={240}
                          loading="lazy"
                          decoding="async"
                          style={{ borderRadius: '8px', width: '100%', height: 'auto', aspectRatio: '3 / 2', objectFit: 'cover' }}
                        />
                        <span
                          className="categories-news-link position-absolute"
                          style={{ left: '10px', bottom: '10px', fontSize: '12px', padding: '2px 12px' }}
                        >
                          {recipe.cat}
                        </span>
                      </div>
                      <div className="content text-left p-2 flex-grow-1 d-flex flex-column justify-content-between">
                        <div>
                          {recipe.date && (
                            <div className="web-color-origin mb-1" style={{ fontSize: '12.5px' }}>
                              <i className="fa fa-calendar mr-1" aria-hidden="true"></i>
                              {formatBlogDateVi(recipe.date)}
                            </div>
                          )}
                          <h3 className="web-color-origin mb-2" style={{ fontSize: '15.5px', lineHeight: 1.4, fontWeight: 600 }}>
                            {recipe.title}
                          </h3>
                        </div>
                        <span style={{ color: '#158247', fontSize: '13.5px', fontWeight: 600 }}>
                          Xem công thức &rarr;
                        </span>
                      </div>
                    </article>
                  </Link>
                </div>
              );
            })}
          </div>

          {/* Tin tức nổi bật */}
          <div className="mt-5 pt-4 border-top" style={{ borderColor: '#dce3de' }}>
            <div className="d-flex flex-column flex-md-row align-items-md-end justify-content-between mb-3" style={{ gap: '10px' }}>
              <h3 className="web-color-origin mb-0" style={{ fontSize: '22px' }}>
                {isEn ? 'Latest News' : 'Tin tức & Kiến thức mới nhất'}
              </h3>
              <Link to="/goc-kham-pha" style={{ color: '#158247', fontWeight: 600, fontSize: '14.5px' }}>
                Xem chuyên mục Tin tức &amp; Kiến thức &rarr;
              </Link>
            </div>
            <div className="row">
              {latestBlogs.map((post) => (
                <div key={post.slug} className="col-lg-4 col-md-6 col-12 mb-3 mb-lg-0">
                  <Link to={`/tin-tuc/${post.slug}`} className="text-decoration-none d-block h-100">
                    <article className="shop-single-blog h-100 bg-white rounded border p-2" style={{ borderColor: '#e5ece7' }}>
                      <div style={{ position: 'relative' }}>
                        <img
                          src={post.img}
                          srcSet={
                            post.img.startsWith('/images/opt/blogs/') && post.img.endsWith('-640w.webp')
                              ? `${post.img.slice(0, -'-640w.webp'.length)}-360w.webp 360w, ${post.img} 640w`
                              : undefined
                          }
                          sizes="(max-width: 767.98px) 92vw, 360px"
                          alt={post.imgAlt || post.title}
                          width={360}
                          height={240}
                          loading="lazy"
                          decoding="async"
                          style={{ borderRadius: '8px', width: '100%', height: 'auto', aspectRatio: '3 / 2', objectFit: 'cover' }}
                        />
                        <span
                          className="categories-news-link position-absolute"
                          style={{ left: '12px', bottom: '12px', fontSize: '12px', padding: '2px 12px' }}
                        >
                          {post.cat}
                        </span>
                      </div>
                      <div className="content text-left p-2">
                        <div className="d-flex pb-2" style={{ fontSize: '13px', color: '#444' }}>
                          <div className="web-color-origin">
                            <i className="fa fa-calendar mr-1" aria-hidden="true"></i>
                            {formatBlogDateVi(post.date)}
                          </div>
                          <div className="web-color-origin ml-3">
                            <i className="fa fa-eye mr-1" aria-hidden="true"></i> {post.views}
                          </div>
                        </div>
                        <h4 className="web-color-origin mb-0" style={{ fontSize: '15.5px', lineHeight: 1.45, fontWeight: 600 }}>
                          {post.title}
                        </h4>
                      </div>
                    </article>
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Lazy-loaded Video TikTok */}
          <div ref={tiktokSectionRef as React.RefObject<HTMLDivElement>} className="mt-5 pt-4 border-top" style={{ borderColor: '#dce3de' }}>
            <h3 className="web-color-origin mb-3 text-center text-md-left" style={{ fontSize: '22px' }}>
              {isEn ? 'Short Videos from Sokfarm' : 'Video thực tế tại Sokfarm'}
            </h3>
            <div className="row">
              {TIKTOK_VIDEOS.map((vid) => (
                <div key={vid.id} className="col-12 col-md-4 tiktok-embed-wrapper mb-4 mb-md-0">
                  <blockquote
                    className="tiktok-embed"
                    cite={vid.cite}
                    data-video-id={vid.id}
                    style={{ maxWidth: '605px', minWidth: 0, width: '100%' }}
                  >
                    <section>
                      <a
                        target="_blank"
                        rel="noreferrer"
                        title="@ngai_mathoadua_sokfarm"
                        href="https://www.tiktok.com/@ngai_mathoadua_sokfarm?refer=embed"
                      >
                        @ngai_mathoadua_sokfarm
                      </a>{' '}
                      {vid.caption}
                    </section>
                  </blockquote>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 7. HỢP TÁC B2B & XUẤT KHẨU */}
      <section className="py-5 bg-white" aria-labelledby="b2b-cooperation-heading">
        <div className="container">
          <div
            className="p-4 p-md-5 rounded"
            style={{ backgroundColor: '#158247', color: '#fff' }}
          >
            <div className="row align-items-center" style={{ rowGap: '20px' }}>
              <div className="col-12 col-lg-7">
                <h2 id="b2b-cooperation-heading" className="text-white mb-3" style={{ fontSize: '28px' }}>
                  {isEn ? 'B2B Partnerships, HORECA & Export Solutions' : 'Hợp tác B2B, Đại lý & Xuất khẩu'}
                </h2>
                <p className="text-white mb-3" style={{ fontSize: '15.5px', lineHeight: 1.65, opacity: 0.95 }}>
                  Sokfarm cung cấp nguyên liệu mật hoa dừa hữu cơ quy cách công nghiệp (can, túi lớn, thùng) cho chuỗi nhà hàng, khách sạn, quán cà phê (HORECA), nhà máy chế biến thực phẩm F&amp;B và đối tác nhập khẩu quốc tế (USDA, EU, JAS Organic, ISO 22000:2018, FDA, HALAL).
                </p>
                <div className="d-flex flex-wrap" style={{ gap: '16px', fontSize: '14px' }}>
                  <Link to="/nguyen-lieu" className="text-white font-weight-bold" style={{ textDecoration: 'underline' }}>
                    Xem danh mục Nguyên liệu công nghiệp &rarr;
                  </Link>
                  <Link to="/giai-phap-horeca" className="text-white font-weight-bold" style={{ textDecoration: 'underline' }}>
                    Xem Giải pháp HORECA &rarr;
                  </Link>
                </div>
              </div>

              <div className="col-12 col-lg-5 d-flex flex-column flex-sm-row flex-lg-column align-items-stretch" style={{ gap: '10px' }}>
                <Link
                  to="/export-markets#bao-gia-xuat-khau"
                  className="btn px-4 py-3 text-center"
                  style={{
                    backgroundColor: '#f6ad1b',
                    color: '#1a1a1a',
                    fontWeight: 700,
                    minHeight: '46px',
                    borderRadius: '8px',
                  }}
                >
                  Nhận báo giá B2B / Nguyên liệu
                </Link>
                <Link
                  to="/contact?subject=Dang-ky-dai-ly"
                  className="btn btn-light px-4 py-3 text-center"
                  style={{
                    backgroundColor: '#ffffff',
                    color: '#158247',
                    fontWeight: 700,
                    minHeight: '46px',
                    borderRadius: '8px',
                  }}
                >
                  Đăng ký đại lý phân phối
                </Link>
                <Link
                  to="/export-markets"
                  className="btn btn-outline-light px-4 py-3 text-center"
                  style={{
                    borderColor: '#ffffff',
                    color: '#ffffff',
                    fontWeight: 600,
                    minHeight: '46px',
                    borderRadius: '8px',
                  }}
                >
                  Liên hệ xuất khẩu quốc tế
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
