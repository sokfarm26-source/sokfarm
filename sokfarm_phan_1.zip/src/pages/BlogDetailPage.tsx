import React, { useState, useEffect, useRef } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import {
  latestBlogs,
  loadAllBlogs,
  PARTNER_EXPORT_NEWS_CATEGORY,
  RECRUITMENT_CATEGORY,
} from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { SeoHead } from '../components/SeoHead';
import { useArticleComments } from '../hooks/useArticleComments';
import { ArticleMetaBar } from '../components/ArticleMetaBar';
import { ArticleCommentsSection } from '../components/ArticleCommentsSection';
import { RelatedArticlesSection } from '../components/RelatedArticlesSection';
import { BlogSidebar } from '../components/BlogSidebar';

const detailCache = new Map<string, BlogPost>();

export const BlogDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [blogs, setBlogs] = useState<BlogPost[]>(latestBlogs);
  const [loadedDetail, setLoadedDetail] = useState<BlogPost | null>(
    slug && detailCache.has(slug) ? detailCache.get(slug)! : null
  );
  const [loadingDetail, setLoadingDetail] = useState(true);
  const { comments, addComment } = useArticleComments(slug || '');
  const contentRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let cancelled = false;
    loadAllBlogs().then((all) => {
      if (!cancelled) setBlogs(all);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const post = loadedDetail || blogs.find((b) => b.slug === slug);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    if (!slug) {
      setLoadedDetail(null);
      setLoadingDetail(false);
      return;
    }
    const cached = detailCache.get(slug);
    if (cached) {
      setLoadedDetail(cached);
      setLoadingDetail(false);
      return;
    }
    let cancelled = false;
    setLoadingDetail(true);
    fetch(`/data/blogs/${encodeURIComponent(slug)}.json`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data: BlogPost | null) => {
        if (cancelled) return;
        if (data && data.slug) {
          detailCache.set(slug, data);
          setLoadedDetail(data);
        }
        setLoadingDetail(false);
      })
      .catch(() => {
        if (!cancelled) setLoadingDetail(false);
      });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  useEffect(() => {
    const container = contentRef.current;
    if (!container) return;
    const handleClick = (e: Event) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      if (!anchor) return;
      const href = anchor.getAttribute('href') || '';
      if (href.startsWith('/')) {
        e.preventDefault();
        navigate(href);
      }
    };
    container.addEventListener('click', handleClick);
    return () => container.removeEventListener('click', handleClick);
  }, [navigate, loadedDetail]);

  if (!post) {
    return (
      <>
        <SeoHead
          title="Không tìm thấy bài viết | Sokfarm"
          description="Bài viết bạn tìm kiếm không tồn tại hoặc đã được chuyển."
          canonicalPath="/goc-kham-pha"
        />
        <div className="breadcrumbs">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="bread-inner">
                  <ul className="bread-list">
                    <li>
                      <Link to="/">
                        Trang chủ<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                    <li>
                      <Link to="/goc-kham-pha">
                        Góc khám phá<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                    <li className="active">
                      <span>Không tìm thấy bài viết</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <section className="section py-5">
          <div className="container text-center">
            <h1 className="web-color-origin mb-3" style={{ fontSize: '28px' }}>
              404 - Không tìm thấy bài viết
            </h1>
            <p className="mb-4">Bài viết không tồn tại hoặc đường dẫn đã thay đổi.</p>
            <Link to="/goc-kham-pha" className="btn btn-success text-white">
              Quay lại Góc khám phá
            </Link>
          </div>
        </section>
      </>
    );
  }

  const canonicalPath = `/tin-tuc/${post.slug}`;
  const isExportNews = post.catSlug === PARTNER_EXPORT_NEWS_CATEGORY.slug;
  const isRecruitment = post.catSlug === RECRUITMENT_CATEGORY.slug;
  const sectionCrumb = isExportNews
    ? { name: 'Tin Xuất khẩu', path: '/doi-tac/tin-xuat-khau' }
    : isRecruitment
    ? { name: 'Tuyển dụng', path: '/tuyen-dung' }
    : {
        name: post.cat || 'Góc khám phá',
        path: post.catSlug ? `/goc-kham-pha/${post.catSlug}` : '/goc-kham-pha',
      };

  const activeContentHtml = loadedDetail?.contentHtml || post.contentHtml || '';

  return (
    <>
      <SeoHead
        title={`${post.title} | Sokfarm`}
        description={post.excerpt}
        canonicalPath={canonicalPath}
        image={post.img}
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          ...(!isExportNews && !isRecruitment ? [{ name: 'Góc khám phá', path: '/goc-kham-pha' }] : []),
          sectionCrumb,
          { name: post.title, path: canonicalPath },
        ]}
        articleSchema={{
          headline: post.title,
          image: post.img,
          datePublished: post.date,
          description: post.excerpt,
        }}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  {!isExportNews && !isRecruitment && (
                    <li>
                      <Link to="/goc-kham-pha">
                        Góc khám phá<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                  )}
                  <li>
                    <Link to={sectionCrumb.path}>
                      {sectionCrumb.name}
                      <i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to={canonicalPath}>{post.title}</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="blog-single section">
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-12">
              <div className="blog-single-main">
                <div className="row">
                  <div className="col-12">
                    <div className="image">
                      <img
                        src={post.img}
                        alt={post.imgAlt || post.title}
                        width={800}
                        height={450}
                        decoding="async"
                      />
                    </div>
                    <div className="blog-detail">
                      <h1 className="blog-title" style={{ fontSize: '26px', lineHeight: 1.35 }}>
                        {post.title}
                      </h1>
                      <ArticleMetaBar
                        author={post.author || (post.sourceUrl ? 'Admin' : undefined)}
                        date={post.date}
                        commentCount={comments.length}
                      />
                      {loadingDetail && !activeContentHtml ? (
                        <div className="content content-post py-4 text-muted">
                          Đang tải nội dung bài viết...
                        </div>
                      ) : (
                        <div
                          ref={contentRef}
                          className="content content-post"
                          dangerouslySetInnerHTML={{ __html: activeContentHtml }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <ArticleCommentsSection comments={comments} onAddComment={addComment} />

              <RelatedArticlesSection
                currentSlug={post.slug}
                catSlug={post.catSlug}
                posts={blogs}
              />
            </div>

            <BlogSidebar
              recentPosts={blogs.slice(0, 5)}
              recentTitle="Tin Mới"
              activeCategorySlug={post.catSlug}
            />
          </div>
        </div>
      </section>
    </>
  );
};
