import React from 'react';
import { Link } from 'react-router-dom';
import {
  BLOG_CATEGORIES,
  PARTNER_EXPORT_NEWS_CATEGORY,
  RECRUITMENT_CATEGORY,
  formatBlogDateVi,
} from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { NewsletterSignup } from './NewsletterSignup';

export interface BlogSidebarProps {
  recentPosts: BlogPost[];
  recentTitle?: string;
  activeCategorySlug?: string;
  showSearch?: boolean;
  searchQuery?: string;
  onSearchChange?: (value: string) => void;
  onSearchSubmit?: () => void;
  showExploreAllLink?: boolean;
  exploreTotalCount?: number;
  categoryCounts?: Record<string, number>;
  showOtherCategories?: boolean;
  exportNewsCount?: number;
  recruitmentCount?: number;
  onCategorySelect?: () => void;
}

export const BlogSidebar: React.FC<BlogSidebarProps> = ({
  recentPosts,
  recentTitle = 'Tin Mới',
  activeCategorySlug,
  showSearch = false,
  searchQuery = '',
  onSearchChange,
  onSearchSubmit,
  showExploreAllLink = false,
  exploreTotalCount,
  categoryCounts,
  showOtherCategories = false,
  exportNewsCount,
  recruitmentCount,
  onCategorySelect,
}) => {
  return (
    <aside className="col-lg-4 col-12" aria-label="Thanh bên Tin tức & Kiến thức">
      <div className="main-sidebar">
        {showSearch && onSearchChange && (
          <div className="single-widget search">
            <form
              className="form"
              onSubmit={(e) => {
                e.preventDefault();
                onSearchSubmit?.();
              }}
            >
              <input
                type="text"
                aria-label="Tìm kiếm bài viết"
                placeholder="Tìm kiếm bài viết..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
              />
              <button className="button" type="submit" aria-label="Tìm kiếm bài viết">
                <i className="fa fa-search" aria-hidden="true"></i>
              </button>
            </form>
          </div>
        )}

        <div className="single-widget category">
          <h3 className="title">Chuyên mục Góc Khám Phá</h3>
          <ul className="categor-list">
            {showExploreAllLink && (
              <li>
                <Link
                  to="/goc-kham-pha"
                  onClick={onCategorySelect}
                  style={{
                    fontWeight: !activeCategorySlug ? 700 : 400,
                    color: !activeCategorySlug ? '#158247' : undefined,
                  }}
                >
                  Tất cả bài viết Góc khám phá
                  {typeof exploreTotalCount === 'number' ? ` (${exploreTotalCount})` : ''}
                </Link>
              </li>
            )}
            {BLOG_CATEGORIES.map((bc) => {
              const count = categoryCounts?.[bc.slug];
              const isActive = activeCategorySlug === bc.slug;
              return (
                <li key={bc.slug}>
                  <Link
                    to={`/goc-kham-pha/${bc.slug}`}
                    onClick={onCategorySelect}
                    style={{
                      fontWeight: isActive ? 700 : 400,
                      color: isActive ? '#158247' : undefined,
                    }}
                  >
                    {bc.name}
                    {typeof count === 'number' ? ` (${count})` : ''}
                  </Link>
                </li>
              );
            })}
          </ul>
          {showOtherCategories && (
            <div className="mt-3 pt-3 border-top" style={{ fontSize: '13.5px' }}>
              <div className="text-muted mb-2 font-weight-bold">Chuyên mục khác:</div>
              <div className="d-flex flex-column" style={{ gap: '6px' }}>
                <Link to="/doi-tac/tin-xuat-khau" style={{ color: '#158247' }}>
                  <i className="ti-angle-right mr-1" aria-hidden="true"></i>
                  {PARTNER_EXPORT_NEWS_CATEGORY.name} (Đối tác &amp; B2B)
                  {typeof exportNewsCount === 'number' ? ` (${exportNewsCount})` : ''}
                </Link>
                <Link to="/tuyen-dung" style={{ color: '#158247' }}>
                  <i className="ti-angle-right mr-1" aria-hidden="true"></i>
                  {RECRUITMENT_CATEGORY.name} Sokfarm
                  {typeof recruitmentCount === 'number' ? ` (${recruitmentCount})` : ''}
                </Link>
              </div>
            </div>
          )}
        </div>

        <div className="single-widget recent-post">
          <h3 className="title">{recentTitle}</h3>
          {recentPosts.map((rp) => {
            const rpUrl = rp.customPath || `/tin-tuc/${rp.slug}`;
            return (
              <div key={rp.slug} className="single-post">
                <div className="image">
                  <img
                    src={rp.img}
                    alt={rp.imgAlt || rp.title}
                    width={80}
                    height={80}
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="content">
                  <h5>
                    <Link to={rpUrl}>{rp.title}</Link>
                  </h5>
                  {rp.date && (
                    <ul className="comment">
                      <li>
                        <i className="fa fa-calendar" aria-hidden="true"></i> {formatBlogDateVi(rp.date)}
                      </li>
                    </ul>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <NewsletterSignup />
      </div>
    </aside>
  );
};
