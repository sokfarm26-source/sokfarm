import storesRaw from './stores.json';
import type { StoreDirectory, StoreRegionMeta } from '../types/sokfarm';

export const STORE_DIRECTORY: StoreDirectory = storesRaw as StoreDirectory;

export const STORE_REGIONS: StoreRegionMeta[] = [
  { key: 'hcm_stores', label: 'Thành phố Hồ Chí Minh' },
  { key: 'hn_stores', label: 'Thành phố Hà Nội' },
  { key: 'other_stores', label: 'Các tỉnh khác' },
  { key: 'online', label: 'Online' },
];

export function normalizeExternalHref(rawHref?: string): string {
  if (!rawHref) return '';
  const decoded = rawHref.replace(/&amp;/g, '&').trim();
  if (!decoded) return '';
  if (/^https?:\/\//i.test(decoded)) return decoded;
  return `https://${decoded}`;
}
