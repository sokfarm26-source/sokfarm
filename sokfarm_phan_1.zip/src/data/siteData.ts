import productsRaw from './productsSummary.json';
import latestBlogsRaw from './latestBlogs.json';
import latestRecipesRaw from './latestRecipes.json';
import type { Product, BlogPost } from '../types/sokfarm';

export const products: Product[] = productsRaw as Product[];
export const latestBlogs: BlogPost[] = latestBlogsRaw as BlogPost[];
export const latestRecipes: BlogPost[] = latestRecipesRaw as BlogPost[];

let cachedAllBlogs: BlogPost[] | null = null;
export async function loadAllBlogs(): Promise<BlogPost[]> {
  if (cachedAllBlogs) return cachedAllBlogs;
  const mod = await import('./blogs.json');
  cachedAllBlogs = mod.default as BlogPost[];
  return cachedAllBlogs;
}

export interface CategoryInfo {
  id: string;
  slug: string;
  name: string;
  nameEn: string;
  description?: string;
  parentSlug?: string;
  childrenSlugs?: string[];
  productSlugs?: string[];
  isCollection?: boolean;
  isB2B?: boolean;
}

/**
 * Chuẩn hóa danh mục sản phẩm B2C theo cấu trúc thông tin mới:
 * SẢN PHẨM (/san-pham)
 * ├── Mật hoa dừa (/danh-muc/mat-hoa-dua)
 * │   ├── Mật hoa dừa tươi (/danh-muc/mat-hoa-dua-tuoi)
 * │   └── Mật hoa dừa cô đặc (/danh-muc/mat-hoa-dua-co-dac)
 * ├── Đường hoa dừa (/danh-muc/duong-hoa-dua)
 * ├── Đồ uống (/danh-muc/do-uong)
 * ├── Gia vị (/danh-muc/gia-vi)
 * ├── Sản phẩm cho bé (/danh-muc/san-pham-cho-be)
 * └── Quà tặng (/danh-muc/qua-tang)
 */
export const B2C_CATEGORIES: CategoryInfo[] = [
  {
    id: 'cat-mat-hoa-dua',
    slug: 'mat-hoa-dua',
    name: 'Mật hoa dừa',
    nameEn: 'Coconut Flower Nectar',
    description:
      'Tinh hoa thu từ hoa dừa hữu cơ Trà Vinh bằng kỹ thuật mát-xa truyền thống của người Khmer, gồm dòng Mật hoa dừa tươi thanh mát và Mật hoa dừa cô đặc sánh mịn giàu khoáng chất.',
    childrenSlugs: ['mat-hoa-dua-tuoi', 'mat-hoa-dua-co-dac'],
    productSlugs: [
      'mat-hoa-dua-tuoi-huu-co',
      'mat-hoa-dua-tuoi-huu-co-330ml',
      'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'mat-hoa-dua-co-dac-huu-co',
      'mat-hoa-dua-co-dac-huu-co-cho-be',
    ],
  },
  {
    id: 'cat-mat-hoa-dua-tuoi',
    slug: 'mat-hoa-dua-tuoi',
    name: 'Mật hoa dừa tươi',
    nameEn: 'Fresh Coconut Flower Nectar',
    parentSlug: 'mat-hoa-dua',
    description:
      'Nước uống mật hoa dừa tươi 100% nguyên chất, bù khoáng điện giải tự nhiên, không thêm đường và không chất bảo quản.',
    productSlugs: [
      'mat-hoa-dua-tuoi-huu-co',
      'mat-hoa-dua-tuoi-huu-co-330ml',
      'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
    ],
  },
  {
    id: 'cat-mat-hoa-dua-co-dac',
    slug: 'mat-hoa-dua-co-dac',
    name: 'Mật hoa dừa cô đặc',
    nameEn: 'Concentrated Coconut Flower Nectar',
    parentSlug: 'mat-hoa-dua',
    description:
      'Mật hoa dừa cô đặc chân không ở nhiệt độ thấp 55-60°C giúp giữ trọn vị ngọt tự nhiên, chỉ số đường huyết thấp và giàu khoáng chất.',
    productSlugs: [
      'mat-hoa-dua-co-dac-huu-co',
      'mat-hoa-dua-co-dac-huu-co-cho-be',
    ],
  },
  {
    id: 'cat-duong-hoa-dua',
    slug: 'duong-hoa-dua',
    name: 'Đường hoa dừa',
    nameEn: 'Coconut Flower Sugar',
    description:
      'Đường hoa dừa hữu cơ dạng hạt không tách mật, không qua tinh luyện, giữ nguyên khoáng chất và hương thơm dừa tự nhiên.',
    productSlugs: [
      'duong-hoa-dua-huu-co',
      'duong-hoa-dua-huu-co-cho-be',
      'tui-duong-hoa-dua-huu-co-cho-be',
    ],
  },
  {
    id: 'cat-do-uong',
    slug: 'do-uong',
    name: 'Đồ uống',
    nameEn: 'Beverages',
    description:
      'Các dòng thức uống hữu cơ từ mật hoa dừa Sokfarm: mật hoa dừa tươi cấp đông, hộp giấy UHT 330ml, mật hoa dừa Matcha và mật hoa dừa lên men.',
    productSlugs: [
      'mat-hoa-dua-tuoi-huu-co',
      'mat-hoa-dua-tuoi-huu-co-330ml',
      'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'mat-hoa-dua-matcha-330ml',
      'combo-mua-11-tang-1-mat-hoa-dua-matcha-330ml',
      'mat-hoa-dua-len-men-huu-co',
    ],
  },
  {
    id: 'cat-gia-vi',
    slug: 'gia-vi',
    name: 'Gia vị hữu cơ',
    nameEn: 'Organic Seasonings',
    description:
      'Gia vị hữu cơ lên men từ mật hoa dừa Sokfarm gồm nước tương mật hoa dừa (nguyên bản & ít muối), xốt Teriyaki và giấm mật hoa dừa.',
    productSlugs: [
      'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
      'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
      'xot-teriyaki-mat-hoa-dua-huu-co-265g',
      'giam-mat-hoa-dua-huu-co',
    ],
  },
  {
    id: 'cat-san-pham-cho-be',
    slug: 'san-pham-cho-be',
    name: 'Sản phẩm cho bé',
    nameEn: 'Products for Kids',
    description:
      'Gia vị hữu cơ thuần thực vật từ mật hoa dừa phù hợp chế biến món ăn dặm cho bé từ 1 tuổi trở lên.',
    productSlugs: [
      'mat-hoa-dua-co-dac-huu-co-cho-be',
      'duong-hoa-dua-huu-co-cho-be',
      'tui-duong-hoa-dua-huu-co-cho-be',
      'nuoc-tuong-mat-hoa-dua-huu-co-cho-be',
    ],
  },
  {
    id: 'cat-qua-tang',
    slug: 'qua-tang',
    name: 'Quà tặng',
    nameEn: 'Gifting & Combos',
    description:
      'Hộp quà tặng mật hoa dừa hữu cơ và bộ gia vị hạnh phúc Sokfarm sang trọng, ý nghĩa cho người thân và đối tác.',
    productSlugs: [
      'hop-qua-tang-gia-vi-huu-co',
      'bo-qua-tang-hanh-phuc',
      'combo-detox',
      'bo-qua-tang-gia-vi-hanh-phuc',
      'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
    ],
  },
];

// Top-level B2C menu categories shown in header/sidebar/home (excluding nested child views so no duplication)
export const TOP_B2C_CATEGORIES: CategoryInfo[] = B2C_CATEGORIES.filter((c) => !c.parentSlug);

// Bộ sưu tập theo nhu cầu sử dụng (không trùng lặp danh mục sản phẩm chính)
export const SECONDARY_COLLECTIONS: CategoryInfo[] = [
  {
    id: 'col-ban-chay-nhat',
    slug: 'ban-chay-nhat',
    name: 'Bán chạy nhất',
    nameEn: 'Best Sellers',
    isCollection: true,
    description: 'Những sản phẩm mật hoa dừa hữu cơ được khách hàng tin dùng và lựa chọn nhiều nhất tại Sokfarm.',
    // Danh sách có thể cấu hình thứ tự & sản phẩm cho trang /san-pham/ban-chay-nhat
    productSlugs: [
      'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'mat-hoa-dua-matcha-330ml',
      'xot-teriyaki-mat-hoa-dua-huu-co-265g',
      'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
      'combo-mua-11-tang-1-mat-hoa-dua-matcha-330ml',
      'mat-hoa-dua-tuoi-huu-co',
      'mat-hoa-dua-tuoi-huu-co-330ml',
      'mat-hoa-dua-co-dac-huu-co',
      'duong-hoa-dua-huu-co',
      'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
      'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
      'giam-mat-hoa-dua-huu-co',
      'mat-hoa-dua-len-men-huu-co',
      'nuoc-tuong-mat-hoa-dua-huu-co-cho-be',
    ],
  },
  {
    id: 'col-dung-pha-che',
    slug: 'dung-pha-che',
    name: 'Dùng pha chế',
    nameEn: 'For Beverages & Mixing',
    isCollection: true,
    description: 'Các sản phẩm mật hoa dừa tươi, cô đặc và đường hoa dừa lý tưởng để pha chế cà phê, trà, sinh tố và đồ uống hàng ngày.',
    productSlugs: [
      'mat-hoa-dua-co-dac-huu-co',
      'duong-hoa-dua-huu-co',
      'mat-hoa-dua-tuoi-huu-co',
      'mat-hoa-dua-tuoi-huu-co-330ml',
      'mat-hoa-dua-matcha-330ml',
      'mat-hoa-dua-len-men-huu-co',
    ],
  },
  {
    id: 'col-dung-nau-an',
    slug: 'dung-nau-an',
    name: 'Dùng nấu ăn',
    nameEn: 'For Cooking & Seasoning',
    isCollection: true,
    description: 'Gia vị và chất tạo ngọt hữu cơ từ hoa dừa giúp món kho, món xào, ướp nướng và salad đậm vị tự nhiên.',
    productSlugs: [
      'mat-hoa-dua-co-dac-huu-co',
      'duong-hoa-dua-huu-co',
      'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
      'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
      'xot-teriyaki-mat-hoa-dua-huu-co-265g',
      'giam-mat-hoa-dua-huu-co',
    ],
  },
];

// Danh mục B2B tách khỏi B2C, chuyển sang Đối tác & Xuất khẩu
export const B2B_HORECA_CATEGORY: CategoryInfo = {
  id: '18',
  slug: 'nguyen-lieu-horeca',
  name: 'Giải pháp HORECA & Nguyên liệu',
  nameEn: 'HORECA & Bulk Ingredients',
  isB2B: true,
  description:
    'Nguyên liệu mật hoa dừa hữu cơ đóng gói quy cách lớn dành cho chuỗi nhà hàng, khách sạn, quán cà phê, bếp ăn công nghiệp và nhà máy sản xuất thực phẩm F&B.',
};

// Danh sách tab hiển thị trên Trang chủ (chỉ B2C, không lẫn B2B HORECA)
export const HOME_PRODUCT_TABS: CategoryInfo[] = [
  SECONDARY_COLLECTIONS[0], // Bán chạy nhất
  ...TOP_B2C_CATEGORIES,
];

// Backward compatibility alias for existing imports (B2C categories only)
export const PRODUCT_CATEGORIES: CategoryInfo[] = TOP_B2C_CATEGORIES;

export const ALL_PRODUCT_GROUPINGS: CategoryInfo[] = [
  ...B2C_CATEGORIES,
  ...SECONDARY_COLLECTIONS,
  B2B_HORECA_CATEGORY,
];

export function isB2BProduct(product: Product): boolean {
  return product.cats.includes('18');
}

export function getB2CProducts(): Product[] {
  return products.filter((p) => !isB2BProduct(p));
}

export function getProductsForGrouping(slug?: string): Product[] {
  if (!slug) return [];
  const info = ALL_PRODUCT_GROUPINGS.find((g) => g.slug === slug);
  if (!info) return [];
  if (info.isB2B || slug === 'nguyen-lieu-horeca') {
    return products.filter((p) => p.cats.includes('18'));
  }
  if (slug === 'ban-chay-nhat') {
    if (info.productSlugs && info.productSlugs.length > 0) {
      const orderMap = new Map(info.productSlugs.map((s, idx) => [s, idx]));
      return products
        .filter((p) => !isB2BProduct(p) && orderMap.has(p.slug))
        .sort((a, b) => (orderMap.get(a.slug) ?? 999) - (orderMap.get(b.slug) ?? 999));
    }
    return products.filter((p) => p.cats.includes('12') && !p.cats.includes('18'));
  }
  if (info.productSlugs && info.productSlugs.length > 0) {
    const orderMap = new Map(info.productSlugs.map((s, idx) => [s, idx]));
    return products
      .filter((p) => !isB2BProduct(p) && orderMap.has(p.slug))
      .sort((a, b) => (orderMap.get(a.slug) ?? 999) - (orderMap.get(b.slug) ?? 999));
  }
  return [];
}

export function getPrimaryCategoryForProduct(product: Product): CategoryInfo | null {
  if (isB2BProduct(product)) return B2B_HORECA_CATEGORY;
  // Prefer child category for fresh/concentrated coconut nectar, then top-level B2C category
  const childMatch = B2C_CATEGORIES.find(
    (c) => c.parentSlug && c.productSlugs?.includes(product.slug)
  );
  if (childMatch) return childMatch;
  const topMatch = TOP_B2C_CATEGORIES.find((c) => c.productSlugs?.includes(product.slug));
  return topMatch || TOP_B2C_CATEGORIES[0];
}

export function getCategoryPath(slug: string): string {
  if (slug === 'nguyen-lieu-horeca') return '/giai-phap-horeca';
  if (slug === 'ban-chay-nhat') return '/san-pham/ban-chay-nhat';
  if (SECONDARY_COLLECTIONS.some((c) => c.slug === slug)) return `/bo-suu-tap/${slug}`;
  return `/danh-muc/${slug}`;
}

export const LEGACY_CATEGORY_REDIRECT_MAP: Record<string, string> = {
  'ban-chay-nhat': '/san-pham/ban-chay-nhat',
  'san-pham-do-uong': '/danh-muc/do-uong',
  'thuc-pham-thieu-yeu': '/danh-muc/mat-hoa-dua',
  'san-pham-gia-vi': '/danh-muc/gia-vi',
  'gia-vi-cho-be': '/danh-muc/san-pham-cho-be',
  'gifting': '/danh-muc/qua-tang',
  'nguyen-lieu-horeca': '/giai-phap-horeca',
};

/**
 * Chuẩn hóa Góc Khám Phá (thay cho Tin tức):
 * - Kiến thức mật hoa dừa
 * - Công thức chế biến
 * - Câu chuyện Sokfarm
 * - Tin tức & sự kiện
 */
export interface BlogCategoryInfo {
  slug: string;
  name: string;
  description: string;
  hasCampaignPlaceholder?: boolean;
}

export const BLOG_CATEGORIES: BlogCategoryInfo[] = [
  {
    slug: 'kien-thuc-mat-hoa-dua',
    name: 'Kiến thức mật hoa dừa',
    description: 'Kiến thức khoa học, quy trình thu mật hoa dừa truyền thống và hướng dẫn sử dụng mật hoa dừa hữu cơ.',
  },
  {
    slug: 'cong-thuc-che-bien',
    name: 'Công thức chế biến',
    description: 'Gợi ý các món ăn, thức uống ngon và lành mạnh chế biến cùng mật hoa dừa, đường hoa dừa và nước tương mật hoa dừa Sokfarm.',
  },
  {
    slug: 'cau-chuyen-sokfarm',
    name: 'Câu chuyện Sokfarm',
    description: 'Hành trình xây dựng Nông nghiệp Hạnh phúc, đồng hành cùng nông dân Trà Vinh và phát triển bền vững.',
  },
  {
    slug: 'tin-tuc-su-kien',
    name: 'Tin tức & sự kiện',
    description: 'Hoạt động, giải thưởng, hội chợ và dấu ấn nổi bật của Sokfarm trong nước và quốc tế.',
  },
];

export const PARTNER_EXPORT_NEWS_CATEGORY: BlogCategoryInfo = {
  slug: 'tin-xuat-khau',
  name: 'Tin Xuất khẩu',
  description: 'Hoạt động xúc tiến thương mại và xuất khẩu các sản phẩm từ mật hoa dừa Sokfarm ra thị trường quốc tế.',
};

export const RECRUITMENT_CATEGORY: BlogCategoryInfo = {
  slug: 'tuyen-dung',
  name: 'Tuyển dụng',
  description: 'Thông tin cơ hội nghề nghiệp và đồng hành phát triển cùng Công ty TNHH Trà Vinh Farm (Sokfarm).',
};

export const LEGACY_BLOG_CAT_REDIRECT_MAP: Record<string, string> = {
  'tin-tuc': '/goc-kham-pha/tin-tuc-su-kien',
  'tin-tuc-2401273647-36': '/goc-kham-pha',
  'mon-ngon-tu-mat-hoa-dua-sokfarm': '/goc-kham-pha/cong-thuc-che-bien',
  'tin-xuat-khau': '/doi-tac/tin-xuat-khau',
  'tuyen-dung': '/tuyen-dung',
};

export const LEGACY_PRODUCT_SLUG_MAP: Record<string, string> = {
  // Original raw Sokfarm slugs & previous organic slugs -> canonical Vietnamese non-accented SEO slugs
  'combo-mua-11-tang-1-mat-hoa-dua-matcha-sokfarm-330ml': 'combo-mua-11-tang-1-mat-hoa-dua-matcha-330ml',
  'combo-12-hop-mat-hoa-dua-tuoi-organic-sokfarm-330ml': 'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'combo-12-hop-mat-hoa-dua-tuoi-organic-330ml': 'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'xot-teriyaki-mat-hoa-dua-organic-sokfarm-265g': 'xot-teriyaki-mat-hoa-dua-huu-co-265g',
  'xot-teriyaki-mat-hoa-dua-organic-265g': 'xot-teriyaki-mat-hoa-dua-huu-co-265g',
  'mat-hoa-dua-matcha-sokfarm-330ml': 'mat-hoa-dua-matcha-330ml',
  'tui-duong-hoa-dua-organic-sokfarm-cho-be': 'tui-duong-hoa-dua-huu-co-cho-be',
  'tui-duong-hoa-dua-organic-cho-be': 'tui-duong-hoa-dua-huu-co-cho-be',
  'loc-6-hop-mat-hoa-dua-tuoi-organic-sokfarm-330ml-hop-qua-tet': 'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'loc-6-hop-mat-hoa-dua-tuoi-organic-330ml': 'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'mat-hoa-dua-tuoi-huu-co-sokfarm': 'mat-hoa-dua-tuoi-huu-co',
  'mat-hoa-dua-tuoi-organic': 'mat-hoa-dua-tuoi-huu-co',
  'organic-fresh-coconut-flower-juice-330ml-uht-single-2604281722-552': 'mat-hoa-dua-tuoi-huu-co-330ml',
  'mat-hoa-dua-tuoi-organic-sokfarm-hop-giay-330ml': 'mat-hoa-dua-tuoi-huu-co-330ml',
  'mat-hoa-dua-tuoi-organic-330ml': 'mat-hoa-dua-tuoi-huu-co-330ml',
  'mat-hoa-dua-co-dac-organic-sokfarm-2605265715-571': 'mat-hoa-dua-co-dac-huu-co',
  'mat-hoa-dua-co-dac-huu-co-sokfarm': 'mat-hoa-dua-co-dac-huu-co',
  'mat-hoa-dua-co-dac-organic': 'mat-hoa-dua-co-dac-huu-co',
  'sokfarm-organic-coconut-flower-sugar-2604282359-848': 'duong-hoa-dua-huu-co',
  'duong-hoa-dua-huu-co-sokfarm': 'duong-hoa-dua-huu-co',
  'duong-hoa-dua-organic': 'duong-hoa-dua-huu-co',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-dong-it-muoi': 'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
  'nuoc-tuong-mat-hoa-dua-organic-dong-it-muoi': 'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
  'nuoc-tuong-mat-hoa-dua-huu-co-sokfarm': 'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
  'sokfarm-organic-coconut-flower-aminos': 'nuoc-tuong-mat-hoa-dua-huu-co-it-muoi',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-dong-nguyen-ban': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-dong-nguyen-ban-2506300051-628': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
  'nuoc-tuong-mat-hoa-dua-organic-dong-nguyen-ban': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
  'giam-mat-hoa-dua-organic-sokfarm': 'giam-mat-hoa-dua-huu-co',
  'giam-mat-hoa-dua-huu-co-sokfarm': 'giam-mat-hoa-dua-huu-co',
  'giam-mat-hoa-dua-organic': 'giam-mat-hoa-dua-huu-co',
  'sokfarm-organic-coconut-flower-cider': 'mat-hoa-dua-len-men-huu-co',
  'mat-hoa-dua-len-men-organic': 'mat-hoa-dua-len-men-huu-co',
  'mat-hoa-dua-co-dac-organic-sokfarm-cho-be': 'mat-hoa-dua-co-dac-huu-co-cho-be',
  'mat-hoa-dua-co-dac-organic-cho-be': 'mat-hoa-dua-co-dac-huu-co-cho-be',
  'duong-hoa-dua-organic-sokfarm-cho-be': 'duong-hoa-dua-huu-co-cho-be',
  'duong-hoa-dua-organic-cho-be': 'duong-hoa-dua-huu-co-cho-be',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-cho-be': 'nuoc-tuong-mat-hoa-dua-huu-co-cho-be',
  'nuoc-tuong-mat-hoa-dua-organic-cho-be': 'nuoc-tuong-mat-hoa-dua-huu-co-cho-be',
  'hop-qua-tang-gia-vi-huu-co': 'hop-qua-tang-gia-vi-huu-co',
  'bo-qua-tang-hanh-phuc': 'bo-qua-tang-hanh-phuc',
  'combo-detox': 'combo-detox',
  'bo-qua-tang-gia-vi-hanh-phuc': 'bo-qua-tang-gia-vi-hanh-phuc',
  'duong-hoa-dua-organic-sokfarm-nguyen-lieu': 'duong-hoa-dua-huu-co-nguyen-lieu',
  'duong-hoa-dua-organic-nguyen-lieu': 'duong-hoa-dua-huu-co-nguyen-lieu',
  'mat-hoa-dua-tuoi-organic-sokfarm-nguyen-lieu': 'mat-hoa-dua-tuoi-huu-co-nguyen-lieu',
  'mat-hoa-dua-tuoi-organic-nguyen-lieu': 'mat-hoa-dua-tuoi-huu-co-nguyen-lieu',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-nguyen-lieu': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-lieu',
  'nuoc-tuong-mat-hoa-dua-organic-nguyen-lieu': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-lieu',
  'giam-mat-hoa-dua-organic-sokfarm-nguyen-lieu': 'giam-mat-hoa-dua-huu-co-nguyen-lieu',
  'giam-mat-hoa-dua-organic-nguyen-lieu': 'giam-mat-hoa-dua-huu-co-nguyen-lieu',
  'mat-hoa-dua-co-dac-organic-sokfarm-nguyen-lieu': 'mat-hoa-dua-co-dac-huu-co-nguyen-lieu',
  'mat-hoa-dua-co-dac-organic-nguyen-lieu': 'mat-hoa-dua-co-dac-huu-co-nguyen-lieu',
  'mua-2-tang-1-combo-2-chai-xot-teriyaki-mat-hoa-dua-huu-co-sokfarm-265g-tang-1-tui-duong-hoa-dua-huu-co-sokfarm-100g-cho-be': 'xot-teriyaki-mat-hoa-dua-huu-co-265g',
  'bo-qua-tang-tet-hanh-phuc': 'bo-qua-tang-hanh-phuc',
  'combo-mua-1-tang-1-1-thung-mat-hoa-dua-tuoi-organic-sokfarm-330ml-tang-1-tui-duong-hoa-dua-tuoi-organic-sokfarm-300g': 'combo-12-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'combo-mua-5-tang-1-mat-hoa-dua-tuoi-organic-sokfarm-330ml': 'loc-6-hop-mat-hoa-dua-tuoi-huu-co-330ml',
  'mua-combo-tang-1-bo-gia-vi-mat-hoa-dua-huu-co-sokfarm': 'bo-qua-tang-gia-vi-hanh-phuc',
  'nuoc-tuong-mat-hoa-dua-organic-sokfarm-dong-chuyen-nau': 'nuoc-tuong-mat-hoa-dua-huu-co-nguyen-ban',
  'organic-fresh-coconut-flower-juice-330ml-uht-single-2604204415-919': 'mat-hoa-dua-tuoi-huu-co-330ml',
  'sokfarm-organic-coconut-flower-nectar-2604282022-582': 'mat-hoa-dua-co-dac-huu-co',
  'sokfarm-organic-coconut-flower-vinegar': 'giam-mat-hoa-dua-huu-co',
};

export function resolveCanonicalProductSlug(slug?: string): string | null {
  if (!slug) return null;
  if (products.some((p) => p.slug === slug)) return slug;
  const mapped = LEGACY_PRODUCT_SLUG_MAP[slug];
  if (mapped && products.some((p) => p.slug === mapped)) return mapped;
  return null;
}

export function getProductPath(slug: string): string {
  const canonical = resolveCanonicalProductSlug(slug) || slug;
  return `/san-pham/${canonical}`;
}

export interface BannerHotspot {
  to: string;
  ariaLabel: string;
  left: string;
  top: string;
  width: string;
  height: string;
}

export interface BannerSlide {
  src: string;
  srcSet: string;
  fallbackSrc: string;
  href?: string;
  alt: string;
  width: number;
  height: number;
  aspectRatio: string;
  ctaHotspot?: BannerHotspot;
}

export const DESKTOP_BANNERS: BannerSlide[] = [
  {
    src: '/images/opt/banners/campaign-thuan-chay-desktop-1440w.webp',
    srcSet:
      '/images/opt/banners/campaign-thuan-chay-desktop-768w.webp 768w, /images/opt/banners/campaign-thuan-chay-desktop-1440w.webp 1440w, /images/opt/banners/campaign-thuan-chay-desktop-1920w.webp 1920w',
    fallbackSrc: '/images/opt/banners/campaign-thuan-chay-desktop-1440w.jpg',
    alt: 'Banner chiến dịch Vị ngọt thuần chay từ hoa dừa của Sokfarm giới thiệu mật hoa dừa cô đặc Organic',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
    ctaHotspot: {
      to: '/san-pham/mat-hoa-dua-co-dac-huu-co',
      ariaLabel: 'Khám phá sản phẩm mật hoa dừa cô đặc Organic Sokfarm',
      left: '17.1%',
      top: '74.2%',
      width: '19.8%',
      height: '16.6%',
    },
  },
  {
    src: '/images/opt/banners/desktop-1-1440w.webp',
    srcSet: '/images/opt/banners/desktop-1-768w.webp 768w, /images/opt/banners/desktop-1-1440w.webp 1440w',
    fallbackSrc: '/images/opt/banners/desktop-1-1440w.jpg',
    href: '',
    alt: 'Mật hoa dừa hữu cơ Sokfarm chỉ số đường huyết thấp, bổ sung năng lượng, bù khoáng điện giải và nông dân thu mật tại Trà Vinh',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
  },
  {
    src: '/images/opt/banners/desktop-2-1440w.webp',
    srcSet: '/images/opt/banners/desktop-2-768w.webp 768w, /images/opt/banners/desktop-2-1440w.webp 1440w',
    fallbackSrc: '/images/opt/banners/desktop-2-1440w.jpg',
    href: '',
    alt: 'Sokfarm tham gia triển lãm Vietnam Foodexpo 2026 giới thiệu các sản phẩm mật hoa dừa hữu cơ',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
  },
  {
    src: '/images/opt/banners/desktop-3-1440w.webp',
    srcSet: '/images/opt/banners/desktop-3-768w.webp 768w, /images/opt/banners/desktop-3-1440w.webp 1440w',
    fallbackSrc: '/images/opt/banners/desktop-3-1440w.jpg',
    href: '/san-pham/mat-hoa-dua-tuoi-huu-co-330ml',
    alt: 'Mật hoa dừa Sokfarm tái đánh giá chứng nhận hữu cơ quốc tế USDA, EU và JAS lần thứ 5',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
  },
  {
    src: '/images/opt/banners/desktop-4-1440w.webp',
    srcSet: '/images/opt/banners/desktop-4-768w.webp 768w, /images/opt/banners/desktop-4-1440w.webp 1440w',
    fallbackSrc: '/images/opt/banners/desktop-4-1440w.jpg',
    href: '',
    alt: 'Giải pháp nguyên liệu sản xuất công nghiệp từ mật hoa dừa organic Sokfarm',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
  },
  {
    src: '/images/opt/banners/desktop-5-1440w.webp',
    srcSet: '/images/opt/banners/desktop-5-768w.webp 768w, /images/opt/banners/desktop-5-1440w.webp 1440w',
    fallbackSrc: '/images/opt/banners/desktop-5-1440w.jpg',
    href: '',
    alt: 'Các dung tích mật hoa dừa cô đặc organic Sokfarm từ 250g đến can 7kg tiết kiệm hơn',
    width: 1440,
    height: 525,
    aspectRatio: '3840 / 1400',
  },
];

export const MOBILE_BANNERS: BannerSlide[] = [
  {
    src: '/images/opt/banners/campaign-thuan-chay-768w.webp',
    srcSet:
      '/images/opt/banners/campaign-thuan-chay-480w.webp 480w, /images/opt/banners/campaign-thuan-chay-768w.webp 768w, /images/opt/banners/campaign-thuan-chay-1440w.webp 1440w',
    fallbackSrc: '/assets/aistudio/image_f794cdb0.png',
    alt: 'Banner chiến dịch Vị ngọt thuần chay từ hoa dừa của Sokfarm giới thiệu mật hoa dừa cô đặc Organic',
    width: 1897,
    height: 829,
    aspectRatio: '1897 / 829',
    ctaHotspot: {
      to: '/san-pham/mat-hoa-dua-co-dac-huu-co',
      ariaLabel: 'Khám phá sản phẩm mật hoa dừa cô đặc Organic Sokfarm',
      left: '10.6%',
      top: '74.2%',
      width: '23.8%',
      height: '16.6%',
    },
  },
  {
    src: '/images/opt/banners/mobile-1-768w.webp',
    srcSet: '/images/opt/banners/mobile-1-412w.webp 412w, /images/opt/banners/mobile-1-480w.webp 480w, /images/opt/banners/mobile-1-768w.webp 768w',
    fallbackSrc: '/images/opt/banners/mobile-1-768w.jpg',
    alt: 'Mật hoa dừa hữu cơ Sokfarm chỉ số đường huyết thấp, bổ sung năng lượng, bù khoáng điện giải và nông dân thu mật tại Trà Vinh',
    width: 768,
    height: 1430,
    aspectRatio: '1568 / 2920',
  },
  {
    src: '/images/opt/banners/mobile-2-768w.webp',
    srcSet: '/images/opt/banners/mobile-2-412w.webp 412w, /images/opt/banners/mobile-2-480w.webp 480w, /images/opt/banners/mobile-2-768w.webp 768w',
    fallbackSrc: '/images/opt/banners/mobile-2-768w.jpg',
    alt: 'Sokfarm tham gia triển lãm Vietnam Foodexpo 2026 giới thiệu các sản phẩm mật hoa dừa hữu cơ',
    width: 768,
    height: 1430,
    aspectRatio: '1568 / 2920',
  },
  {
    src: '/images/opt/banners/mobile-3-768w.webp',
    srcSet: '/images/opt/banners/mobile-3-412w.webp 412w, /images/opt/banners/mobile-3-480w.webp 480w, /images/opt/banners/mobile-3-768w.webp 768w',
    fallbackSrc: '/images/opt/banners/mobile-3-768w.jpg',
    alt: 'Mật hoa dừa tươi organic Sokfarm đóng hộp giấy 330ml tiện lợi giúp bù khoáng điện giải',
    width: 768,
    height: 1430,
    aspectRatio: '1568 / 2920',
  },
  {
    src: '/images/opt/banners/mobile-4-768w.webp',
    srcSet: '/images/opt/banners/mobile-4-412w.webp 412w, /images/opt/banners/mobile-4-480w.webp 480w, /images/opt/banners/mobile-4-768w.webp 768w',
    fallbackSrc: '/images/opt/banners/mobile-4-768w.jpg',
    alt: 'Giải pháp nguyên liệu sản xuất công nghiệp từ mật hoa dừa organic Sokfarm',
    width: 768,
    height: 1430,
    aspectRatio: '1568 / 2920',
  },
  {
    src: '/images/opt/banners/mobile-5-768w.webp',
    srcSet: '/images/opt/banners/mobile-5-412w.webp 412w, /images/opt/banners/mobile-5-480w.webp 480w, /images/opt/banners/mobile-5-768w.webp 768w',
    fallbackSrc: '/images/opt/banners/mobile-5-768w.jpg',
    alt: 'Các dung tích mật hoa dừa cô đặc organic Sokfarm từ 250g đến can 7kg tiết kiệm hơn',
    width: 768,
    height: 1430,
    aspectRatio: '1568 / 2920',
  },
];

export interface CertificateDetail {
  id: string;
  src: string;
  title: string;
  scope: string;
  summary: string;
  regionLabel: string;
}

export const CERTIFICATES_DETAIL: CertificateDetail[] = [
  {
    id: 'usda-organic',
    src: '/images/opt/chungnhan/cn1.webp',
    title: 'USDA Organic',
    scope: 'Tiêu chuẩn Hữu cơ Bộ Nông nghiệp Hoa Kỳ',
    regionLabel: 'Hoa Kỳ',
    summary:
      'Vùng nguyên liệu dừa hữu cơ và quy trình chế biến của Sokfarm tuân thủ nghiêm ngặt quy định nông nghiệp hữu cơ USDA: không phân bón hóa học, không thuốc trừ sâu tổng hợp và không chất bảo quản.',
  },
  {
    id: 'eu-organic',
    src: '/images/opt/chungnhan/cn2.webp',
    title: 'EU Organic',
    scope: 'Tiêu chuẩn Hữu cơ Liên minh Châu Âu',
    regionLabel: 'Châu Âu',
    summary:
      'Đáp ứng quy chuẩn canh tác và chế biến thực phẩm hữu cơ châu Âu, bảo vệ đa dạng sinh học vùng dừa Trà Vinh và đảm bảo truy xuất nguồn gốc minh bạch từ nông trại đến sản phẩm.',
  },
  {
    id: 'jas-organic',
    src: '/images/opt/chungnhan/cn3.webp',
    title: 'JAS Organic',
    scope: 'Tiêu chuẩn Nông nghiệp Hữu cơ Nhật Bản',
    regionLabel: 'Nhật Bản',
    summary:
      'Chứng nhận đáp ứng yêu cầu kiểm soát chất lượng khắt khe của thị trường Nhật Bản đối với các dòng sản phẩm nông sản hữu cơ chế biến sâu từ mật hoa dừa.',
  },
  {
    id: 'canada-organic',
    src: '/images/opt/chungnhan/cn4.webp',
    title: 'Canada Organic',
    scope: 'Tiêu chuẩn Thực phẩm Hữu cơ Canada',
    regionLabel: 'Canada',
    summary:
      'Xác nhận quy trình trồng trọt hữu cơ và sản xuất mật hoa dừa đáp ứng hệ thống tiêu chuẩn hữu cơ tương thích cho thị trường Bắc Mỹ.',
  },
  {
    id: 'iso-22000',
    src: '/images/opt/chungnhan/cn7.webp',
    title: 'ISO 22000:2018',
    scope: 'Hệ thống Quản lý An toàn Thực phẩm Quốc tế',
    regionLabel: 'Quốc tế',
    summary:
      'Nhà máy chế biến Sokfarm vận hành hệ thống kiểm soát mối nguy an toàn thực phẩm xuyên suốt từ khâu thu mật thủ công, cô đặc chân không nhiệt độ thấp đến đóng gói thành phẩm.',
  },
  {
    id: 'fda',
    src: '/images/opt/chungnhan/cn8.webp',
    title: 'FDA',
    scope: 'Đăng ký cơ sở với Cục Quản lý Thực phẩm & Dược phẩm Hoa Kỳ',
    regionLabel: 'Hoa Kỳ',
    summary:
      'Cơ sở sản xuất của Công ty TNHH Trà Vinh Farm thực hiện đăng ký theo quy định xuất khẩu thực phẩm vào thị trường Hoa Kỳ.',
  },
  {
    id: 'halal',
    src: '/images/opt/chungnhan/halal.webp',
    title: 'HALAL (HCA)',
    scope: 'Chứng nhận phù hợp tiêu chuẩn thực phẩm Halal',
    regionLabel: 'Thị trường Hồi giáo & Quốc tế',
    summary:
      'Nguyên liệu 100% thuần thực vật từ hoa dừa, dây chuyền sản xuất tách biệt sạch sẽ, phù hợp với tiêu chuẩn Halal và người tiêu dùng ăn chay.',
  },
  {
    id: 'ocop-5-sao',
    src: '/images/opt/chungnhan/cn5.webp',
    title: 'OCOP 5 Sao Quốc Gia',
    scope: 'Chương trình Mỗi xã một sản phẩm Việt Nam',
    regionLabel: 'Việt Nam',
    summary:
      'Sản phẩm đặc trưng của vùng dừa Trà Vinh góp phần nâng cao giá trị kinh tế nông nghiệp địa phương và bảo tồn nghề thu mật truyền thống.',
  },
  {
    id: 'great-taste-2023',
    src: '/images/opt/chungnhan/cn6.webp',
    title: 'Great Taste 2023',
    scope: 'Giải thưởng Hương vị Quốc tế tại Vương quốc Anh',
    regionLabel: 'Vương quốc Anh',
    summary:
      'Hương vị tự nhiên đặc trưng của mật hoa dừa Sokfarm được hội đồng chuyên gia ẩm thực quốc tế đánh giá cao tại giải thưởng Great Taste 2023.',
  },
];

export const CERTIFICATES = CERTIFICATES_DETAIL.map((c) => c.src);

export function normalizeTextVi(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd');
}

export type VolumeFilterBucket = 'all' | 'small' | 'medium' | 'large';
export type PriceFilterBucket = 'all' | 'under-100k' | '100k-300k' | 'over-300k';
export type UsageFilterBucket = 'all' | 'ban-chay-nhat' | 'dung-pha-che' | 'dung-nau-an' | 'cho-be' | 'qua-tang';

export function getProductVolumeBuckets(product: Product): Array<Exclude<VolumeFilterBucket, 'all'>> {
  const buckets = new Set<Exclude<VolumeFilterBucket, 'all'>>();
  const attrs = (product.dataProducts || []).map((v) => v.attributes || '');
  const textList = attrs.length > 0 ? attrs : [product.title];

  for (const raw of textList) {
    const t = raw.toLowerCase();
    if (/hộp quà|combo|lốc\s*6|thùng\s*12|can\s*5\s*l|5\s*kg|7\s*kg|1\.4\s*kg|2000\s*ml/.test(t)) {
      buckets.add('large');
    } else if (/300\s*g|330\s*ml|375\s*ml|500\s*ml|685\s*g|1\s*l|1000\s*ml|1\s*kg/.test(t)) {
      buckets.add('medium');
    } else {
      buckets.add('small');
    }
  }
  return Array.from(buckets);
}

export function getProductPriceRange(product: Product): { min: number; max: number } {
  const prices = (product.dataProducts || [])
    .map((v) => Number(v.selling_price || v.price || 0))
    .filter((n) => n > 0);
  if (prices.length > 0) {
    return { min: Math.min(...prices), max: Math.max(...prices) };
  }
  return { min: product.price || 0, max: product.price || 0 };
}

export function matchesPriceBucket(product: Product, bucket: PriceFilterBucket): boolean {
  if (bucket === 'all') return true;
  const { min, max } = getProductPriceRange(product);
  if (max === 0) return false;
  if (bucket === 'under-100k') return min < 100000;
  if (bucket === '100k-300k') return max >= 100000 && min <= 300000;
  if (bucket === 'over-300k') return max > 300000;
  return true;
}

export function matchesUsageBucket(product: Product, usage: UsageFilterBucket): boolean {
  if (usage === 'all') return true;
  if (usage === 'cho-be') {
    return B2C_CATEGORIES.find((c) => c.slug === 'san-pham-cho-be')?.productSlugs?.includes(product.slug) ?? false;
  }
  if (usage === 'qua-tang') {
    return B2C_CATEGORIES.find((c) => c.slug === 'qua-tang')?.productSlugs?.includes(product.slug) ?? false;
  }
  return SECONDARY_COLLECTIONS.find((c) => c.slug === usage)?.productSlugs?.includes(product.slug) ?? false;
}

export const TIKTOK_VIDEOS = [
  {
    id: '7455549597566487826',
    cite: 'https://www.tiktok.com/@ngai_mathoadua_sokfarm/video/7455549597566487826',
    caption: 'Dòng nước tương không từ đậu nành, hữu cơ được sản xuất tại Trà Vinh - Việt Nam nha, mời bạn ! #sokfarm #mathoadua #nongnghiephanhphuc #nongnghiephuuco',
  },
  {
    id: '7502778355184389383',
    cite: 'https://www.tiktok.com/@ngai_mathoadua_sokfarm/video/7502778355184389383',
    caption: 'Ngoài cây mía thì cây dừa cũng có thể làm được đường hoa dừa, cùng theo chân Ngãi khám phá nha. #sokfarm #nongnhiephuuco #duonghoadua #coconutsugar',
  },
  {
    id: '7238594935115533573',
    cite: 'https://www.tiktok.com/@ngai_mathoadua_sokfarm/video/7238594935115533573',
    caption: 'Nước tương Mật hoa dừa Sokfarm 500 ml, chai lớn hơn, dùng đã hơn và tiết kiệm hơn ! #khoinghiep #mathoadua #sokfarm #nongsan',
  },
];

export function formatVnd(amount: number): string {
  return amount.toLocaleString('vi-VN') + 'đ';
}

export function formatVndComma(amount: number): string {
  return amount.toLocaleString('vi-VN') + 'đ';
}

const MONTH_MAP: Record<string, string> = {
  Jan: '01',
  Feb: '02',
  Mar: '03',
  Apr: '04',
  May: '05',
  Jun: '06',
  Jul: '07',
  Aug: '08',
  Sep: '09',
  Oct: '10',
  Nov: '11',
  Dec: '12',
};

export function formatBlogDateVi(dateStr: string): string {
  const m = dateStr.trim().match(/^(\d{1,2})\s+([A-Za-z]{3}),?\s+(\d{4})$/);
  if (!m) return dateStr;
  const dd = m[1].padStart(2, '0');
  const mm = MONTH_MAP[m[2]] || m[2];
  return `${dd}/${mm}/${m[3]}`;
}
