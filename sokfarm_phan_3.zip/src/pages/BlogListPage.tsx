import React, { useState, useEffect } from 'react';
import { Link, useParams, Navigate } from 'react-router-dom';
import {
  latestBlogs,
  loadAllBlogs,
  BLOG_CATEGORIES,
  PARTNER_EXPORT_NEWS_CATEGORY,
  RECRUITMENT_CATEGORY,
  LEGACY_BLOG_CAT_REDIRECT_MAP,
  formatBlogDateVi,
} from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { SeoHead } from '../components/SeoHead';
import { BlogSidebar } from '../components/BlogSidebar';

interface BlogListPageProps {
  mode?: 'explore' | 'export-news' | 'recruitment' | 'legacy';
}

export const BlogListPage: React.FC<BlogListPageProps> = ({ mode = 'explore' }) => {
  const { slug } = useParams<{ slug?: string }>();
  const [blogs, setBlogs] = useState<BlogPost[]>(latestBlogs);
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const perPage = 8;

  useEffect(() => {
    let cancelled = false;
    loadAllBlogs().then((all) => {
      if (!cancelled) setBlogs(all);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    setPage(1);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [slug, mode]);

  if (mode === 'legacy' && slug) {
    const legacyTarget = LEGACY_BLOG_CAT_REDIRECT_MAP[slug];
    if (legacyTarget) {
      return <Navigate to={legacyTarget} replace />;
    }
    if (BLOG_CATEGORIES.some((c) => c.slug === slug)) {
      return <Navigate to={`/goc-kham-pha/${slug}`} replace />;
    }
  }

  const exploreSlugs = new Set(BLOG_CATEGORIES.map((c) => c.slug));

  const activeCategory =
    mode === 'export-news'
      ? PARTNER_EXPORT_NEWS_CATEGORY
      : mode === 'recruitment'
      ? RECRUITMENT_CATEGORY
      : slug
      ? BLOG_CATEGORIES.find((c) => c.slug === slug)
      : null;

  const isInvalidSlug = mode === 'explore' && !!slug && !activeCategory;

  const norm = (s: string) =>
    s
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');

  const filtered = isInvalidSlug
    ? []
    : blogs.filter((b) => {
        const matchesCat = activeCategory
          ? b.catSlug === activeCategory.slug || norm(b.cat) === norm(activeCategory.name)
          : exploreSlugs.has(b.catSlug || '');
        const matchesSearch = searchQuery.trim()
          ? norm(b.title).includes(norm(searchQuery)) ||
            norm(b.excerpt).includes(norm(searchQuery)) ||
            norm(b.cat).includes(norm(searchQuery)) ||
            norm(b.sourceCategory || '').includes(norm(searchQuery))
          : true;
        return matchesCat && matchesSearch;
      });

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice((currentPage - 1) * perPage, currentPage * perPage);
  const recentPosts = blogs.filter((b) => exploreSlugs.has(b.catSlug || '')).slice(0, 5);
  const exploreTotalCount = blogs.filter((b) => exploreSlugs.has(b.catSlug || '')).length;
  const exportNewsCount = blogs.filter((b) => b.catSlug === PARTNER_EXPORT_NEWS_CATEGORY.slug).length;
  const recruitmentCount = blogs.filter((b) => b.catSlug === RECRUITMENT_CATEGORY.slug).length;

  const getPageNumbers = (): Array<number | 'ellipsis-left' | 'ellipsis-right'> => {
    if (totalPages <= 7) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    const pages: Array<number | 'ellipsis-left' | 'ellipsis-right'> = [1];
    const start = Math.max(2, currentPage - 2);
    const end = Math.min(totalPages - 1, currentPage + 2);
    if (start > 2) pages.push('ellipsis-left');
    for (let i = start; i <= end; i++) pages.push(i);
    if (end < totalPages - 1) pages.push('ellipsis-right');
    pages.push(totalPages);
    return pages;
  };

  const canonicalPath =
    mode === 'export-news'
      ? '/doi-tac/tin-xuat-khau'
      : mode === 'recruitment'
      ? '/tuyen-dung'
      : activeCategory
      ? `/goc-kham-pha/${activeCategory.slug}`
      : '/goc-kham-pha';

  const parentSection =
    mode === 'export-news'
      ? { name: 'Đối tác & Xuất khẩu', path: '/export-markets' }
      : mode === 'recruitment'
      ? null
      : { name: 'Góc khám phá', path: '/goc-kham-pha' };

  const breadcrumbs = [
    { name: 'Trang chủ', path: '/' },
    ...(parentSection ? [parentSection] : []),
    ...(activeCategory
      ? [{ name: activeCategory.name, path: canonicalPath }]
      : mode === 'explore' && isInvalidSlug
      ? [{ name: 'Không tìm thấy chuyên mục', path: canonicalPath }]
      : []),
  ];

  const pageHeading = isInvalidSlug
    ? 'Không tìm thấy chuyên mục'
    : activeCategory
    ? activeCategory.name
    : 'Góc khám phá Sokfarm';

  const pageDesc =
    activeCategory?.description ||
    'Kiến thức mật hoa dừa, công thức chế biến, câu chuyện Sokfarm và tin tức & sự kiện mới nhất.';

  return (
    <>
      <SeoHead
        title={`${pageHeading} | Sokfarm`}
        description={pageDesc}
        canonicalPath={canonicalPath}
        breadcrumbs={breadcrumbs}
      />

      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  {breadcrumbs.map((bc, idx) => {
                    const isLast = idx === breadcrumbs.length - 1;
                    return (
                      <li key={bc.path + idx} className={isLast ? 'active' : undefined}>
                        <Link to={bc.path}>
                          {bc.name}
                          {!isLast && <i className="ti-arrow-right"></i>}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="shop-blog grid mt-3 pb-5">
        <div className="container">
          {!isInvalidSlug && (
            <div className="mb-4">
              <h1 className="web-color-origin mb-2" style={{ fontSize: '28px' }}>
                {pageHeading}
              </h1>
              <p className="text-muted mb-2" style={{ fontSize: '15px' }}>
                {pageDesc}
              </p>
              <p className="text-muted mb-3" style={{ fontSize: '13.5px' }}>
                Tổng cộng <strong>{filtered.length}</strong> bài viết
                {totalPages > 1 ? ` — Trang ${currentPage}/${totalPages}` : ''}
              </p>

              {/* Chờ cập nhật 2 bài viết SEO chiến dịch mới (chỉ placeholder, không tự tạo nội dung) */}
              {activeCategory?.hasCampaignPlaceholder && (
                <div
                  className="p-3 rounded mb-3 d-flex align-items-center justify-content-between flex-wrap"
                  style={{
                    background: '#fbf4eb',
                    border: '1px dashed #158247',
                    gap: '10px',
                    fontSize: '14px',
                  }}
                >
                  <div>
                    <strong className="web-color-origin">
                      <i className="fa fa-bookmark-o mr-2"></i>
                      Vị trí chuyên mục sẵn sàng cho bài viết chiến dịch mới ({activeCategory.name})
                    </strong>
                    <span className="text-muted ml-2">
                      — Bài viết chuyên sâu sẽ được cập nhật khi nội dung chính thức được phát hành.
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="row">
            <div className="col-lg-8 col-12">
              <div className="row">
                {isInvalidSlug ? (
                  <div className="col-12 py-5 text-center">
                    <h2 className="web-color-origin mb-3">404 - Không tìm thấy chuyên mục</h2>
                    <p className="mb-4">Chuyên mục bạn đang tìm kiếm không tồn tại hoặc đã được di chuyển.</p>
                    <Link to="/goc-kham-pha" className="btn btn-success text-white">
                      Quay lại Góc khám phá
                    </Link>
                  </div>
                ) : paginated.length === 0 ? (
                  <div className="col-12 py-5 text-center">
                    <p>Chưa có bài viết nào phù hợp với từ khóa tìm kiếm.</p>
                  </div>
                ) : (
                  paginated.map((post) => {
                    const postUrl = post.customPath || `/tin-tuc/${post.slug}`;
                    const showMeta = Boolean(post.date) || post.views > 0;
                    const ctaLabel =
                      activeCategory?.slug === 'cong-thuc-che-bien' || post.customPath
                        ? 'Xem chi tiết'
                        : 'Đọc tiếp...';
                    return (
                      <div
                        key={post.slug}
                        className="col-lg-6 col-md-6 col-12 mb-4"
                        title={post.title}
                        style={{ cursor: 'pointer' }}
                      >
                        <div className="shop-single-blog">
                          <div style={{ height: '250px', position: 'relative' }}>
                            <Link to={postUrl}>
                              <img
                                src={post.img}
                                alt={post.imgAlt || post.title}
                                width={400}
                                height={250}
                                loading="lazy"
                                decoding="async"
                                style={{ width: '100%', height: '250px', objectFit: 'cover' }}
                              />
                              <span
                                className="categories-news-link position-absolute"
                                style={{ left: '10%', bottom: '12%' }}
                              >
                                {post.cat}
                              </span>
                            </Link>
                          </div>
                          <div className="content py-3 px-2">
                            {showMeta && (
                              <p className="date text-justify">
                                {post.date && (
                                  <>
                                    <i className="fa fa-calendar" aria-hidden="true"></i>{' '}
                                    {formatBlogDateVi(post.date)}
                                  </>
                                )}
                                {post.views > 0 && (
                                  <span className="float-right">
                                    <i className="fa fa-eye" aria-hidden="true"></i> {post.views}
                                  </span>
                                )}
                              </p>
                            )}
                            <Link
                              to={postUrl}
                              className="title text-justify line-2"
                            >
                              {post.title}
                            </Link>
                            <p className="text-justify line-2" style={{ height: '50px' }}>
                              {post.excerpt}
                            </p>
                            <Link
                              to={postUrl}
                              className="more-btn text-primary"
                            >
                              {ctaLabel}
                            </Link>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}

                {totalPages > 1 && (
                  <div className="col-12 mt-3">
                    <nav aria-label="Phân trang bài viết">
                      <ul className="pagination d-flex flex-wrap">
                        <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                          <button
                            type="button"
                            className="page-link"
                            aria-label="Trang trước"
                            disabled={currentPage === 1}
                            onClick={() => {
                              setPage((p) => Math.max(1, p - 1));
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                          >
                            &laquo;
                          </button>
                        </li>
                        {getPageNumbers().map((pItem) =>
                          typeof pItem === 'string' ? (
                            <li key={pItem} className="page-item disabled">
                              <span className="page-link">...</span>
                            </li>
                          ) : (
                            <li
                              key={pItem}
                              className={`page-item ${currentPage === pItem ? 'active' : ''}`}
                            >
                              <button
                                type="button"
                                className="page-link"
                                onClick={() => {
                                  setPage(pItem);
                                  window.scrollTo({ top: 0, behavior: 'smooth' });
                                }}
                              >
                                {pItem}
                              </button>
                            </li>
                          )
                        )}
                        <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                          <button
                            type="button"
                            className="page-link"
                            aria-label="Trang sau"
                            disabled={currentPage === totalPages}
                            onClick={() => {
                              setPage((p) => Math.min(totalPages, p + 1));
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                          >
                            &raquo;
                          </button>
                        </li>
                      </ul>
                    </nav>
                  </div>
                )}
              </div>
            </div>

            <BlogSidebar
              recentPosts={recentPosts}
              recentTitle="Tin Mới"
              activeCategorySlug={mode === 'explore' ? slug : undefined}
              showSearch
              searchQuery={searchQuery}
              onSearchChange={(q) => {
                setSearchQuery(q);
                setPage(1);
              }}
              onSearchSubmit={() => setPage(1)}
              showExploreAllLink
              exploreTotalCount={exploreTotalCount}
              categoryCounts={BLOG_CATEGORIES.reduce<Record<string, number>>((acc, bc) => {
                acc[bc.slug] = blogs.filter((b) => b.catSlug === bc.slug).length;
                return acc;
              }, {})}
              showOtherCategories
              exportNewsCount={exportNewsCount}
              recruitmentCount={recruitmentCount}
              onCategorySelect={() => setPage(1)}
            />
          </div>
        </div>
      </section>
    </>
  );
};
