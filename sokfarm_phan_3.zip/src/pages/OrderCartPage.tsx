import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatVndComma, getProductPath } from '../data/siteData';
import orderGroupsRaw from '../data/orderGroups.json';
import type { OrderGroup } from '../types/sokfarm';
import { useApp } from '../context/AppContext';
import { SeoHead } from '../components/SeoHead';

const orderGroups: OrderGroup[] = orderGroupsRaw as OrderGroup[];

export const OrderCartPage: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    updateCartQty,
    setItemQtyInCart,
    removeFromCart,
    notify,
  } = useApp();

  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [newsletterInput, setNewsletterInput] = useState('');

  const toggleGroup = (gid: string) => {
    setExpandedGroups((prev) => ({ ...prev, [gid]: !prev[gid] }));
  };

  const getQtyInCart = (productId: string, code: string) => {
    const found = cart.find((c) => c.productId === productId && c.code === code);
    return found ? found.quantity : 0;
  };

  return (
    <>
      <SeoHead
        title="Đặt hàng & Giỏ hàng | Sokfarm"
        description="Đặt mua nhanh các sản phẩm mật hoa dừa hữu cơ Sokfarm chính hãng."
        canonicalPath="/dat-hang"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Giỏ hàng', path: '/dat-hang' },
        ]}
      />
      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to="/dat-hang">Giỏ hàng</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Shopping Cart */}
      <div className="shopping-cart section" style={{ paddingTop: '50px', paddingBottom: 0 }}>
        {/* Desktop View */}
        <div className="container d-none d-md-block d-lg-block">
          <div className="row">
            <div className="col-md-9 col-lg-9 pb-5">
              {/* Shopping Summary Table */}
              <table className="table shopping-summery" style={{ height: 'auto' }}>
                <thead>
                  <tr className="main-hading">
                    <th>SẢN PHẨM</th>
                    <th>TÊN SẢN PHẨM</th>
                    <th className="text-center">SỐ LƯỢNG</th>
                    <th className="text-center">GIÁ TIỀN</th>
                    <th className="text-center"></th>
                  </tr>
                </thead>
                <tbody id="cart_item_list">
                  {cart.length === 0 ? (
                    <tr className="cart-empty">
                      <td className="text-center" colSpan={5}>
                        Giỏ hàng của bạn trống!{' '}
                        <Link to="/san-pham" style={{ color: 'rgba(0,101,45,1)' }}>
                          Tiếp tục mua hàng.
                        </Link>
                      </td>
                    </tr>
                  ) : (
                    cart.map((item) => (
                      <tr key={`${item.productId}-${item.code}`}>
                        <td className="image" data-title="SẢN PHẨM">
                          <img
                            src={item.img}
                            alt={item.title}
                            width={80}
                            height={80}
                            loading="lazy"
                            decoding="async"
                            style={{ width: '80px', maxHeight: '80px', objectFit: 'contain' }}
                          />
                        </td>
                        <td className="product-des" data-title="TÊN SẢN PHẨM">
                          <p className="product-name">
                            <Link to={getProductPath(item.slug)}>{item.title}</Link>
                          </p>
                          {item.packaging && (
                            <p className="product-des">Phân loại: {item.packaging}</p>
                          )}
                        </td>
                        <td className="qty" data-title="SỐ LƯỢNG">
                          <div className="input-group">
                            <div className="button minus">
                              <button
                                type="button"
                                aria-label={`Giảm số lượng ${item.title}`}
                                className="btn btn-primary btn-number"
                                onClick={() =>
                                  updateCartQty(item.productId, item.code, item.quantity - 1)
                                }
                              >
                                <i className="ti-minus" aria-hidden="true"></i>
                              </button>
                            </div>
                            <input
                              type="text"
                              aria-label={`Số lượng ${item.title}`}
                              className="input-number"
                              value={item.quantity}
                              onChange={(e) => {
                                const val = parseInt(e.target.value, 10);
                                if (!isNaN(val)) updateCartQty(item.productId, item.code, val);
                              }}
                            />
                            <div className="button plus">
                              <button
                                type="button"
                                aria-label={`Tăng số lượng ${item.title}`}
                                className="btn btn-primary btn-number"
                                onClick={() =>
                                  updateCartQty(item.productId, item.code, item.quantity + 1)
                                }
                              >
                                <i className="ti-plus" aria-hidden="true"></i>
                              </button>
                            </div>
                          </div>
                        </td>
                        <td className="total-amount" data-title="GIÁ TIỀN">
                          <span style={{ fontVariantNumeric: 'tabular-nums' }}>
                            {formatVndComma(item.price * item.quantity)}
                          </span>
                        </td>
                        <td className="action">
                          <button
                            type="button"
                            aria-label={`Xóa ${item.title} khỏi giỏ hàng`}
                            className="btn btn-link text-danger"
                            onClick={() => removeFromCart(item.productId, item.code)}
                            title="Xóa"
                          >
                            <i className="ti-trash remove-icon" aria-hidden="true"></i>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              {/* Quick Order Group Products */}
              <div className="list-item mt-3 p-4 border rounded">
                <h2 className="h2-custom mb-3">Danh sách sản phẩm</h2>
                {orderGroups.map((group) => {
                  const isOpen = !!expandedGroups[group.groupId];
                  return (
                    <React.Fragment key={group.groupId}>
                      <div
                        className="row shopping-cart align-items-center"
                        style={{ padding: 0, backgroundColor: '#fff', cursor: 'pointer' }}
                        onClick={() => toggleGroup(group.groupId)}
                      >
                        <div className="col-md-2 col-lg-2 col-2 text-center img-wrapper">
                          <img
                            src={group.img}
                            alt={group.title}
                            width={80}
                            height={80}
                            loading="lazy"
                            decoding="async"
                            style={{ maxHeight: '80px', borderRadius: '4px' }}
                          />
                        </div>
                        <div className="col-md-6 col-lg-6 col-7">
                          <h6>{group.title}</h6>
                        </div>
                        <div className="col-md-4 col-lg-4 col-3 text-right">
                          <b style={{ fontSize: '15px' }}>
                            <span className="show-variant" style={{ color: 'rgba(0,101,45,1)' }}>
                              Chọn{' '}
                              <i
                                className={`fa ${
                                  isOpen ? 'fa-chevron-down' : 'fa-chevron-right'
                                } ml-1`}
                                style={{ fontSize: '14px' }}
                              ></i>
                            </span>
                          </b>
                        </div>
                      </div>

                      {isOpen && (
                        <div id={`variantItem-${group.groupId}`} className="ml-3">
                          {group.variants.map((v) => {
                            const qty = getQtyInCart(v.productId, v.code);
                            return (
                              <React.Fragment key={v.code}>
                                <hr />
                                <div
                                  className="row shopping-cart align-items-center mt-2"
                                  style={{ padding: 0, backgroundColor: '#fff' }}
                                >
                                  <div className="col-md-2 col-lg-2 col-2 text-center img-wrapper">
                                    <Link to={getProductPath(v.slug)}>
                                      <img
                                        src={v.img}
                                        alt={v.title}
                                        width={76}
                                        height={76}
                                        loading="lazy"
                                        decoding="async"
                                        style={{ maxHeight: '76px', borderRadius: '4px' }}
                                      />
                                    </Link>
                                  </div>
                                  <div className="col-md-7 col-lg-7 col-9">
                                    <h6>{v.title}</h6>
                                    <div style={{ fontSize: '90%' }}>Đóng gói: {v.packaging}</div>
                                  </div>
                                  <div className="col-md-3 col-lg-3 col-12">
                                    <div
                                      style={{
                                        color: 'rgba(0,101,45,1)',
                                        fontSize: '18px',
                                        textAlign: 'right',
                                      }}
                                    >
                                      <b>{v.priceStr}</b>
                                    </div>
                                    <div className="qty d-flex align-items-center mt-1">
                                      <div className="input-group">
                                        <div className="button minus">
                                          <button
                                            type="button"
                                            aria-label={`Giảm số lượng ${v.title}`}
                                            className="btn btn-primary btn-number btn-number-minus"
                                            onClick={() =>
                                              setItemQtyInCart(
                                                {
                                                  productId: v.productId,
                                                  code: v.code,
                                                  slug: v.slug,
                                                  title: v.title,
                                                  packaging: v.packaging,
                                                  price: v.price,
                                                  img: v.img,
                                                },
                                                Math.max(0, qty - 1)
                                              )
                                            }
                                          >
                                            <i className="ti-minus" aria-hidden="true"></i>
                                          </button>
                                        </div>
                                        <input
                                          type="number"
                                          aria-label={`Số lượng ${v.title}`}
                                          className="input-number"
                                          value={qty}
                                          onChange={(e) => {
                                            const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                                            setItemQtyInCart(
                                              {
                                                productId: v.productId,
                                                code: v.code,
                                                slug: v.slug,
                                                title: v.title,
                                                packaging: v.packaging,
                                                price: v.price,
                                                img: v.img,
                                              },
                                              val
                                            );
                                          }}
                                        />
                                        <div className="button plus">
                                          <button
                                            type="button"
                                            aria-label={`Tăng số lượng ${v.title}`}
                                            className="btn btn-primary btn-number btn-number-plus"
                                            onClick={() =>
                                              setItemQtyInCart(
                                                {
                                                  productId: v.productId,
                                                  code: v.code,
                                                  slug: v.slug,
                                                  title: v.title,
                                                  packaging: v.packaging,
                                                  price: v.price,
                                                  img: v.img,
                                                },
                                                qty + 1
                                              )
                                            }
                                          >
                                            <i className="ti-plus" aria-hidden="true"></i>
                                          </button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </React.Fragment>
                            );
                          })}
                        </div>
                      )}
                      <hr />
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Right Sidebar */}
            <div className="col-md-3 col-lg-3 sticky-scrollable">
              <div className="total-amount">
                <div className="row">
                  <div className="col-12">
                    <h6 className="text-left m-3 text-uppercase">Thông tin đơn hàng</h6>
                    <ul className="m-3">
                      <li className="order_subtotal">
                        Tạm tính:{' '}
                        <span id="total-price-show">{formatVndComma(cartSubtotal)}</span>
                      </li>
                    </ul>
                    <div className="button5">
                      {cart.length > 0 ? (
                        <Link
                          to="/checkout"
                          className="btn-confirm btn btn-success"
                          style={{ color: '#fff', borderRadius: '4px', padding: '10px', width: '100%' }}
                        >
                          Đặt hàng
                        </Link>
                      ) : (
                        <button
                          type="button"
                          disabled
                          className="btn-confirm btn btn-secondary disabled"
                          style={{ color: '#fff', borderRadius: '4px', padding: '10px', width: '100%' }}
                        >
                          Đặt hàng
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile View */}
        <div
          className="container d-md-none d-sm-block d-lg-none"
          style={{ marginTop: '-20px', backgroundColor: '#fff' }}
        >
          <div className="list-prod-mobile mp-3 pt-3">
            {cart.length === 0 ? (
              <div className="cart-empty text-center">
                Giỏ hàng của bạn trống!.{' '}
                <Link to="/san-pham" style={{ color: 'rgba(0,101,45,1)' }}>
                  Tiếp tục mua hàng.
                </Link>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={`${item.productId}-${item.code}`}
                  className="row align-items-center py-2 border-bottom"
                >
                  <div className="col-3">
                    <img
                      src={item.img}
                      alt={item.title}
                      width={64}
                      height={64}
                      loading="lazy"
                      decoding="async"
                      style={{ maxHeight: '64px' }}
                    />
                  </div>
                  <div className="col-9">
                    <div className="font-weight-bold">{item.title}</div>
                    <div style={{ color: '#158247' }}>
                      {formatVndComma(item.price)} x {item.quantity}
                    </div>
                    <div className="d-flex align-items-center mt-2" style={{ gap: '8px' }}>
                      <button
                        type="button"
                        aria-label={`Giảm số lượng ${item.title}`}
                        className="btn btn-sm btn-outline-success"
                        style={{ minWidth: '38px', minHeight: '38px' }}
                        onClick={() => updateCartQty(item.productId, item.code, item.quantity - 1)}
                      >
                        -
                      </button>
                      <span className="px-1 font-weight-bold">{item.quantity}</span>
                      <button
                        type="button"
                        aria-label={`Tăng số lượng ${item.title}`}
                        className="btn btn-sm btn-outline-success"
                        style={{ minWidth: '38px', minHeight: '38px' }}
                        onClick={() => updateCartQty(item.productId, item.code, item.quantity + 1)}
                      >
                        +
                      </button>
                      <button
                        type="button"
                        aria-label={`Xóa ${item.title} khỏi giỏ hàng`}
                        className="btn btn-sm btn-link text-danger ml-auto"
                        style={{ minWidth: '40px', minHeight: '40px' }}
                        onClick={() => removeFromCart(item.productId, item.code)}
                      >
                        <i className="ti-trash" aria-hidden="true"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          {cart.length === 0 && (
            <div className="cart-empty text-center mt-4">
              <Link
                to="/san-pham"
                className="btn btn-success"
                style={{ borderRadius: '999px', color: '#fff', padding: '10px 24px' }}
              >
                Quay lại mua hàng
              </Link>
            </div>
          )}
          <hr />
        </div>

        {/* Mobile Quick Order Groups */}
        <div id="group-mb" className="list-item mt-3 p-3 p-sm-4 rounded d-block d-lg-none d-md-none">
          <h2 className="h2-custom mb-3">Danh sách sản phẩm</h2>
          {orderGroups.map((group) => {
            const isOpen = !!expandedGroups[`mb-${group.groupId}`];
            return (
              <React.Fragment key={group.groupId}>
                <div
                  className="row shopping-cart align-items-center"
                  style={{ padding: 0, backgroundColor: '#fff', cursor: 'pointer' }}
                  onClick={() => toggleGroup(`mb-${group.groupId}`)}
                >
                  <div className="col-3 text-center img-wrapper">
                    <img
                      src={group.img}
                      alt={group.title}
                      width={70}
                      height={70}
                      loading="lazy"
                      decoding="async"
                      style={{ maxHeight: '70px', borderRadius: '4px' }}
                    />
                  </div>
                  <div className="col-6">
                    <h6>{group.title}</h6>
                  </div>
                  <div className="col-3 text-right">
                    <b style={{ fontSize: '14px', color: 'rgba(0,101,45,1)' }}>
                      Chọn <i className={`fa fa-chevron-${isOpen ? 'down' : 'right'}`}></i>
                    </b>
                  </div>
                </div>
                {isOpen && (
                  <div className="ml-2 mt-2">
                    {group.variants.map((v) => {
                      const qty = getQtyInCart(v.productId, v.code);
                      return (
                        <div key={v.code} className="row align-items-center py-2 border-top">
                          <div className="col-3">
                            <img
                              src={v.img}
                              alt={v.title}
                              width={60}
                              height={60}
                              loading="lazy"
                              decoding="async"
                              style={{ maxHeight: '60px' }}
                            />
                          </div>
                          <div className="col-9">
                            <h6 style={{ fontSize: '13px' }}>{v.title}</h6>
                            <div style={{ fontSize: '12px' }}>Đóng gói: {v.packaging}</div>
                            <div className="d-flex justify-content-between align-items-center mt-2">
                              <b style={{ color: 'rgba(0,101,45,1)' }}>{v.priceStr}</b>
                              <div className="d-flex align-items-center" style={{ gap: '8px' }}>
                                <button
                                  type="button"
                                  aria-label={`Giảm ${v.title}`}
                                  className="btn btn-sm btn-outline-success"
                                  style={{ minWidth: '38px', minHeight: '38px' }}
                                  onClick={() =>
                                    setItemQtyInCart(
                                      {
                                        productId: v.productId,
                                        code: v.code,
                                        slug: v.slug,
                                        title: v.title,
                                        packaging: v.packaging,
                                        price: v.price,
                                        img: v.img,
                                      },
                                      Math.max(0, qty - 1)
                                    )
                                  }
                                >
                                  -
                                </button>
                                <span className="px-1 font-weight-bold">{qty}</span>
                                <button
                                  type="button"
                                  aria-label={`Tăng ${v.title}`}
                                  className="btn btn-sm btn-outline-success"
                                  style={{ minWidth: '38px', minHeight: '38px' }}
                                  onClick={() =>
                                    setItemQtyInCart(
                                      {
                                        productId: v.productId,
                                        code: v.code,
                                        slug: v.slug,
                                        title: v.title,
                                        packaging: v.packaging,
                                        price: v.price,
                                        img: v.img,
                                      },
                                      qty + 1
                                    )
                                  }
                                >
                                  +
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
                <hr />
              </React.Fragment>
            );
          })}
        </div>

        {/* Shop Services Area */}
        <section className="shop-services section d-none d-md-block">
          <div className="container">
            <div className="row">
              <div className="col-lg-3 col-md-6 col-12">
                <div className="single-service">
                  <i className="ti-rocket"></i>
                  <h4>Miễn phí giao hàng</h4>
                  <p>Hoá đơn trên 1.000.000 vnđ</p>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-12">
                <div className="single-service">
                  <i className="ti-reload"></i>
                  <h4>Miễn phí đổi trả</h4>
                  <p>Theo chính sách đổi trả của công ty</p>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-12">
                <div className="single-service">
                  <i className="ti-lock"></i>
                  <h4>Thanh toán bảo mật</h4>
                  <p>100% Thanh toán bảo mật</p>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 col-12">
                <div className="single-service">
                  <i className="ti-tag"></i>
                  <h4>Giá ưu đãi nhất</h4>
                  <p>Giá tốt nhất thị trường</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Mobile Bottom Summary Bar */}
        <div className="d-md-none container action-wrapper py-3 border-top">
          <div className="row align-items-center">
            <div className="col-6">
              <div className="order_subtotal font-weight-bold">
                Tạm tính: <span className="total-price-mb-show">{formatVndComma(cartSubtotal)}</span>
              </div>
            </div>
            <div className="col-6 text-right">
              <Link
                to={cart.length > 0 ? '/checkout' : '/san-pham'}
                className="btn p-2 btn-success"
                style={{ color: '#fff', borderRadius: '5px' }}
              >
                <b>Đặt hàng</b>
              </Link>
            </div>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mb-5">
          <section className="shop-newsletter">
            <div className="container">
              <div className="inner-top">
                <div className="row">
                  <div className="col-lg-8 offset-lg-2 col-12 py-md-0">
                    <div className="inner">
                      <h4 className="mt-5 mt-md-0">
                        ĐĂNG KÝ ĐỂ NHẬN THÔNG TIN KHUYẾN MÃI SỚM NHẤT TỪ SOKFARM
                      </h4>
                      <p></p>
                      <form
                        className="newsletter-inner"
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (newsletterInput.trim()) {
                            notify(
                              'Website chưa kết nối hệ thống đăng ký bản tin tự động. Quý khách vui lòng gửi email về hello@sokfarm.com hoặc theo dõi Zalo OA Sokfarm.',
                              'warning'
                            );
                          }
                        }}
                      >
                        <input
                          name="email"
                          aria-label="Địa chỉ email hoặc số điện thoại nhận thông tin khuyến mãi"
                          placeholder="Địa chỉ email hoặc số điện thoại của bạn"
                          type="text"
                          value={newsletterInput}
                          onChange={(e) => setNewsletterInput(e.target.value)}
                          required
                        />
                        <button className="btn" type="submit">
                          Đăng ký
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
};
