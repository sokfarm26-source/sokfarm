import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import type { BlogPost } from '../types/sokfarm';
import { formatBlogDateVi, latestBlogs, latestRecipes } from '../data/siteData';

interface RelatedArticlesSectionProps {
  currentSlug: string;
  catSlug?: string;
  posts: BlogPost[];
}

export const RelatedArticlesSection: React.FC<RelatedArticlesSectionProps> = ({
  currentSlug,
  catSlug,
  posts,
}) => {
  const localThumbBySlug = useMemo(() => {
    const map = new Map<string, string>();
    for (const item of [...latestRecipes, ...latestBlogs]) {
      if (item.slug && item.img) {
        map.set(item.slug, item.img);
      }
    }
    return map;
  }, []);

  const relatedPosts = useMemo(() => {
    const others = posts.filter((p) => p.slug !== currentSlug);
    if (catSlug) {
      const sameCategory = others.filter((p) => p.catSlug === catSlug);
      if (sameCategory.length >= 3) {
        return sameCategory.slice(0, 3);
      }
      const sameSlugs = new Set(sameCategory.map((p) => p.slug));
      const fallback = others.filter((p) => !sameSlugs.has(p.slug));
      return [...sameCategory, ...fallback].slice(0, 3);
    }
    return others.slice(0, 3);
  }, [posts, currentSlug, catSlug]);

  if (relatedPosts.length === 0) return null;

  return (
    <section className="sokfarm-related-articles mt-5 pt-4 border-top" style={{ borderColor: '#e5ece7' }}>
      <h2 className="sokfarm-section-accent-title mb-4">Bài Viết Liên Quan</h2>
      <div className="row" style={{ rowGap: '18px' }}>
        {relatedPosts.map((item) => {
          const postUrl = item.customPath || `/tin-tuc/${item.slug}`;
          const thumbSrc = localThumbBySlug.get(item.slug) || item.img;
          const hasMeta = Boolean(item.date) || item.views > 0;
          return (
            <div key={item.slug} className="col-12 col-sm-6 col-md-4 d-flex">
              <article className="sokfarm-related-card bg-white rounded border d-flex flex-column w-100 overflow-hidden">
                <Link to={postUrl} className="d-block sokfarm-related-thumb-wrap">
                  <img
                    src={thumbSrc}
                    alt={item.imgAlt || item.title}
                    width={400}
                    height={250}
                    loading="lazy"
                    decoding="async"
                    className="sokfarm-related-thumb"
                  />
                </Link>
                <div className="p-3 d-flex flex-column flex-grow-1 justify-content-between">
                  <div>
                    {hasMeta && (
                      <div
                        className="d-flex flex-wrap align-items-center justify-content-between mb-2"
                        style={{ fontSize: '12.5px', color: '#555', gap: '6px' }}
                      >
                        {item.date && (
                          <span>
                            <i className="fa fa-calendar mr-1" style={{ color: '#158247' }} aria-hidden="true"></i>
                            {formatBlogDateVi(item.date)}
                          </span>
                        )}
                        {item.views > 0 && (
                          <span>
                            <i className="fa fa-eye mr-1" style={{ color: '#158247' }} aria-hidden="true"></i>
                            {item.views}
                          </span>
                        )}
                      </div>
                    )}
                    <h3 className="mb-0" style={{ fontSize: '15px', lineHeight: 1.45, fontWeight: 700 }}>
                      <Link to={postUrl} className="sokfarm-related-title-link">
                        {item.title}
                      </Link>
                    </h3>
                  </div>
                </div>
              </article>
            </div>
          );
        })}
      </div>
    </section>
  );
};
