import React, { useEffect, useState } from 'react';
import { CERTIFICATES_DETAIL, type CertificateDetail } from '../data/siteData';

interface CertificateShowcaseProps {
  compact?: boolean;
  title?: string;
  subtitle?: string;
  sectionId?: string;
}

export const CertificateShowcase: React.FC<CertificateShowcaseProps> = ({
  compact = false,
  title = 'Chứng nhận & Chất lượng',
  subtitle = 'Sản phẩm Sokfarm được sản xuất từ nguồn dừa hữu cơ Trà Vinh theo quy trình kiểm soát chất lượng quốc tế.',
  sectionId = 'chung-nhan-chat-luong',
}) => {
  const [selectedCert, setSelectedCert] = useState<CertificateDetail | null>(null);

  useEffect(() => {
    if (!selectedCert) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedCert(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedCert]);

  return (
    <section
      id={sectionId}
      className={compact ? 'py-4' : 'py-5'}
      style={{ backgroundColor: compact ? 'transparent' : '#ffffff' }}
      aria-labelledby={`${sectionId}-heading`}
    >
      <div className={compact ? '' : 'container'}>
        <div className="d-flex flex-column flex-md-row align-items-md-end justify-content-between mb-4" style={{ gap: '12px' }}>
          <div>
            <h2
              id={`${sectionId}-heading`}
              className="web-color-origin mb-2"
              style={{ fontSize: compact ? '22px' : '28px' }}
            >
              {title}
            </h2>
            <p className="mb-0" style={{ color: '#444', maxWidth: '720px', fontSize: '15px' }}>
              {subtitle}
            </p>
          </div>
          {!compact && (
            <button
              type="button"
              className="btn btn-outline-success btn-sm align-self-start align-self-md-end"
              style={{ borderColor: '#158247', color: '#158247', minHeight: '40px', fontWeight: 600 }}
              onClick={() => setSelectedCert(CERTIFICATES_DETAIL[0])}
            >
              Xem thêm thông tin chứng nhận
            </button>
          )}
        </div>

        <div className="row" style={{ rowGap: '14px' }}>
          {CERTIFICATES_DETAIL.map((cert) => (
            <div
              key={cert.id}
              className={compact ? 'col-4 col-sm-3 col-lg-2' : 'col-6 col-sm-4 col-md-4 col-lg-3'}
            >
              <button
                type="button"
                onClick={() => setSelectedCert(cert)}
                aria-label={`Xem thông tin ${cert.title}`}
                className="w-100 h-100 text-left p-3 rounded d-flex flex-column align-items-center justify-content-between"
                style={{
                  backgroundColor: '#fbf4eb',
                  border: '1px solid #d7e6dc',
                  cursor: 'pointer',
                  transition: 'transform 0.2s ease, box-shadow 0.2s ease',
                }}
              >
                <div
                  className="d-flex align-items-center justify-content-center bg-white rounded mb-2 p-2 w-100"
                  style={{ height: compact ? '78px' : '110px' }}
                >
                  <img
                    src={cert.src}
                    alt={`${cert.title} - ${cert.scope}`}
                    width={96}
                    height={96}
                    loading="lazy"
                    decoding="async"
                    style={{ maxHeight: '100%', maxWidth: '100%', width: 'auto', objectFit: 'contain' }}
                  />
                </div>
                <div className="text-center w-100">
                  <div className="font-weight-bold" style={{ color: '#158247', fontSize: compact ? '12.5px' : '14.5px' }}>
                    {cert.title}
                  </div>
                  {!compact && (
                    <div className="mt-1" style={{ color: '#444', fontSize: '12.5px', lineHeight: 1.35 }}>
                      {cert.scope}
                    </div>
                  )}
                </div>
              </button>
            </div>
          ))}
        </div>

        {!compact && (
          <div
            className="mt-4 p-3 p-md-4 rounded d-flex flex-column flex-md-row align-items-md-center justify-content-between"
            style={{ backgroundColor: '#f3f8f5', border: '1px solid #d7e6dc', gap: '12px' }}
          >
            <div style={{ fontSize: '14.5px', color: '#2b2b2b' }}>
              <strong style={{ color: '#158247' }}>Cam kết vùng nguyên liệu hữu cơ Trà Vinh:</strong>{' '}
              Mật hoa dừa được thu thủ công 100% bằng kỹ thuật mát-xa hoa dừa của người Khmer Nam Bộ và chế biến ở nhiệt độ thấp 55–60°C để giữ trọn khoáng chất tự nhiên.
            </div>
            <button
              type="button"
              onClick={() => setSelectedCert(CERTIFICATES_DETAIL[0])}
              className="btn btn-sm btn-success text-white flex-shrink-0"
              style={{ backgroundColor: '#158247', borderColor: '#158247', minHeight: '40px', fontWeight: 600 }}
            >
              Tra cứu tiêu chuẩn áp dụng
            </button>
          </div>
        )}
      </div>

      {/* Accessible Modal */}
      {selectedCert && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="cert-modal-title"
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            zIndex: 999999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '16px',
          }}
          onClick={() => setSelectedCert(null)}
        >
          <div
            className="bg-white rounded shadow-lg w-100"
            style={{ maxWidth: '640px', maxHeight: '90vh', overflowY: 'auto' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div
              className="d-flex align-items-center justify-content-between p-3 p-md-4 border-bottom"
              style={{ borderColor: '#e5ece7' }}
            >
              <h3 id="cert-modal-title" className="web-color-origin mb-0" style={{ fontSize: '20px' }}>
                {selectedCert.title}
              </h3>
              <button
                type="button"
                aria-label="Đóng thông tin chứng nhận"
                onClick={() => setSelectedCert(null)}
                className="btn btn-sm btn-outline-secondary"
                style={{ minWidth: '40px', minHeight: '40px', fontSize: '18px' }}
              >
                &times;
              </button>
            </div>

            <div className="p-3 p-md-4">
              <div className="d-flex flex-column flex-sm-row align-items-center mb-4" style={{ gap: '18px' }}>
                <div
                  className="p-3 rounded border d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{ width: '130px', height: '130px', backgroundColor: '#fbf4eb', borderColor: '#d7e6dc' }}
                >
                  <img
                    src={selectedCert.src}
                    alt={selectedCert.title}
                    width={100}
                    height={100}
                    style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }}
                  />
                </div>
                <div>
                  <div className="font-weight-bold mb-1" style={{ color: '#158247', fontSize: '16px' }}>
                    {selectedCert.scope}
                  </div>
                  <div className="mb-2" style={{ color: '#555', fontSize: '13.5px' }}>
                    Phạm vi áp dụng: <strong>{selectedCert.regionLabel}</strong>
                  </div>
                  <p className="mb-0" style={{ color: '#333', fontSize: '14.5px', lineHeight: 1.6 }}>
                    {selectedCert.summary}
                  </p>
                </div>
              </div>

              <div className="border-top pt-3">
                <div className="font-weight-bold mb-2" style={{ fontSize: '13.5px', color: '#158247' }}>
                  Chọn tiêu chuẩn khác để xem chi tiết:
                </div>
                <div className="d-flex flex-wrap" style={{ gap: '6px' }}>
                  {CERTIFICATES_DETAIL.map((item) => {
                    const active = item.id === selectedCert.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => setSelectedCert(item)}
                        className="btn btn-sm"
                        style={{
                          border: '1px solid #158247',
                          backgroundColor: active ? '#158247' : '#fff',
                          color: active ? '#fff' : '#158247',
                          fontSize: '12.5px',
                          minHeight: '34px',
                        }}
                      >
                        {item.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="p-3 px-md-4 border-top d-flex justify-content-end" style={{ backgroundColor: '#f8f7f3' }}>
              <button
                type="button"
                onClick={() => setSelectedCert(null)}
                className="btn btn-success text-white"
                style={{ backgroundColor: '#158247', borderColor: '#158247', minHeight: '40px' }}
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
