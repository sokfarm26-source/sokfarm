import React, { useEffect, useId, useRef, useState } from 'react';

interface GrecaptchaApi {
  ready: (cb: () => void) => void;
  render: (
    container: HTMLElement,
    params: {
      sitekey: string;
      callback: (token: string) => void;
      'expired-callback'?: () => void;
      'error-callback'?: () => void;
    }
  ) => number;
  reset: (widgetId?: number) => void;
}

declare global {
  interface Window {
    grecaptcha?: GrecaptchaApi;
  }
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

let recaptchaScriptPromise: Promise<void> | null = null;

function loadRecaptchaScript(): Promise<void> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Window unavailable'));
  }
  if (window.grecaptcha && typeof window.grecaptcha.ready === 'function') {
    return Promise.resolve();
  }
  if (recaptchaScriptPromise) {
    return recaptchaScriptPromise;
  }

  recaptchaScriptPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(
      'script[src^="https://www.google.com/recaptcha/api.js"]'
    );
    if (existing) {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Failed to load reCAPTCHA')), {
        once: true,
      });
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://www.google.com/recaptcha/api.js?render=explicit&hl=vi';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => {
      recaptchaScriptPromise = null;
      reject(new Error('Failed to load reCAPTCHA'));
    };
    document.head.appendChild(script);
  });

  return recaptchaScriptPromise;
}

export const NewsletterSignup: React.FC = () => {
  const emailId = useId();
  const statusId = useId();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const recaptchaContainerRef = useRef<HTMLDivElement | null>(null);
  const widgetIdRef = useRef<number | null>(null);

  const recaptchaSiteKey = (import.meta.env.VITE_RECAPTCHA_SITE_KEY || '').trim();
  const newsletterEndpoint = (import.meta.env.VITE_NEWSLETTER_ENDPOINT || '').trim();
  const hasRecaptchaKey = recaptchaSiteKey.length > 0;

  const [email, setEmail] = useState('');
  const [recaptchaToken, setRecaptchaToken] = useState('');
  const [recaptchaLoadError, setRecaptchaLoadError] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [status, setStatus] = useState<{
    type: 'error' | 'info' | 'success';
    message: string;
  } | null>(null);

  useEffect(() => {
    if (!hasRecaptchaKey || !recaptchaContainerRef.current) return;
    let cancelled = false;

    loadRecaptchaScript()
      .then(() => {
        if (cancelled || !window.grecaptcha || !recaptchaContainerRef.current) return;
        window.grecaptcha.ready(() => {
          if (
            cancelled ||
            !window.grecaptcha ||
            !recaptchaContainerRef.current ||
            widgetIdRef.current !== null
          ) {
            return;
          }
          widgetIdRef.current = window.grecaptcha.render(recaptchaContainerRef.current, {
            sitekey: recaptchaSiteKey,
            callback: (token: string) => {
              setRecaptchaToken(token);
              setStatus((prev) => (prev?.type === 'error' ? null : prev));
            },
            'expired-callback': () => {
              setRecaptchaToken('');
            },
            'error-callback': () => {
              setRecaptchaToken('');
              setRecaptchaLoadError(true);
            },
          });
        });
      })
      .catch(() => {
        if (!cancelled) setRecaptchaLoadError(true);
      });

    return () => {
      cancelled = true;
    };
  }, [hasRecaptchaKey, recaptchaSiteKey]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!hasRecaptchaKey) {
      setStatus({
        type: 'info',
        message: 'Chức năng đăng ký nhận tin đang được hoàn thiện.',
      });
      return;
    }

    const trimmedEmail = email.trim();
    if (!trimmedEmail) {
      setStatus({
        type: 'error',
        message: 'Vui lòng nhập địa chỉ email của bạn.',
      });
      inputRef.current?.focus();
      return;
    }

    if (!EMAIL_PATTERN.test(trimmedEmail)) {
      setStatus({
        type: 'error',
        message: 'Địa chỉ email chưa hợp lệ. Vui lòng kiểm tra lại (ví dụ: ten@email.com).',
      });
      inputRef.current?.focus();
      return;
    }

    if (recaptchaLoadError) {
      setStatus({
        type: 'error',
        message: 'Không thể tải xác minh bảo mật lúc này. Vui lòng tải lại trang và thử lại.',
      });
      return;
    }

    if (!recaptchaToken) {
      setStatus({
        type: 'error',
        message: 'Vui lòng xác nhận “Tôi không phải là người máy” trước khi đăng ký.',
      });
      return;
    }

    if (!newsletterEndpoint) {
      setStatus({
        type: 'info',
        message: 'Chức năng đăng ký nhận tin đang được hoàn thiện.',
      });
      return;
    }

    setSubmitting(true);
    setStatus(null);

    try {
      const response = await fetch(newsletterEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: trimmedEmail,
          recaptchaToken,
          sourcePath: typeof window !== 'undefined' ? window.location.pathname : '',
        }),
      });

      const contentType = response.headers.get('content-type') || '';
      const payload = contentType.includes('application/json')
        ? await response.json().catch(() => null)
        : null;

      if (!response.ok || (payload && payload.success === false)) {
        throw new Error('Request failed');
      }

      setEmail('');
      setRecaptchaToken('');
      if (window.grecaptcha && widgetIdRef.current !== null) {
        window.grecaptcha.reset(widgetIdRef.current);
      }
      setStatus({
        type: 'success',
        message: 'Đăng ký nhận tin thành công! Cảm ơn bạn đã quan tâm đến Sokfarm.',
      });
    } catch {
      setRecaptchaToken('');
      if (window.grecaptcha && widgetIdRef.current !== null) {
        window.grecaptcha.reset(widgetIdRef.current);
      }
      setStatus({
        type: 'error',
        message: 'Không thể hoàn tất đăng ký lúc này. Vui lòng thử lại sau.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      className="single-widget sokfarm-newsletter-widget"
      aria-labelledby={`${emailId}-heading`}
    >
      <div className="sokfarm-newsletter-card">
        <h3 id={`${emailId}-heading`} className="sokfarm-newsletter-title">
          Đăng Ký &amp; Nhận Tin Cập Nhật Mới Nhất
        </h3>

        <form className="sokfarm-newsletter-form" onSubmit={handleSubmit} noValidate>
          <div className="sokfarm-newsletter-field">
            <label htmlFor={emailId} className="sokfarm-newsletter-label">
              Địa chỉ email của bạn
            </label>
            <input
              ref={inputRef}
              id={emailId}
              name="newsletter_email"
              type="email"
              inputMode="email"
              autoComplete="email"
              placeholder="Hãy nhập mail của bạn"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (status?.type === 'error') setStatus(null);
              }}
              aria-invalid={status?.type === 'error' ? true : undefined}
              aria-describedby={status ? statusId : undefined}
              required
            />
          </div>

          {hasRecaptchaKey ? (
            <div className="sokfarm-recaptcha-wrap">
              {recaptchaLoadError ? (
                <div className="sokfarm-newsletter-feedback is-error" role="status">
                  Không thể tải xác minh Google reCAPTCHA. Vui lòng tải lại trang và thử lại.
                </div>
              ) : (
                <div className="sokfarm-recaptcha-frame">
                  <div ref={recaptchaContainerRef} />
                </div>
              )}
            </div>
          ) : (
            <div className="sokfarm-newsletter-pending" role="status">
              <i className="fa fa-info-circle" aria-hidden="true"></i>
              <span>Chức năng đăng ký nhận tin đang được hoàn thiện</span>
            </div>
          )}

          <button
            type="submit"
            className={`sokfarm-newsletter-submit ${submitting ? 'is-submitting' : ''}`}
            disabled={!hasRecaptchaKey || submitting}
            aria-disabled={!hasRecaptchaKey || submitting}
          >
            {submitting ? 'ĐANG XỬ LÝ...' : 'ĐĂNG KÝ'}
          </button>

          {status && (
            <div
              id={statusId}
              role={status.type === 'error' ? 'alert' : 'status'}
              className={`sokfarm-newsletter-feedback is-${status.type}`}
            >
              {status.message}
            </div>
          )}
        </form>
      </div>
    </section>
  );
};
