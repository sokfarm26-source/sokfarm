import React, { useEffect } from 'react';

export interface BreadcrumbSchemaItem {
  name: string;
  path: string;
}

interface SeoHeadProps {
  title: string;
  description?: string;
  canonicalPath: string;
  image?: string;
  ogType?: 'website' | 'article';
  keywords?: string[];
  breadcrumbs?: BreadcrumbSchemaItem[];
  productSchema?: {
    name: string;
    price: number;
    image: string;
    description?: string;
    sku?: string;
  };
  articleSchema?: {
    schemaType?: 'Article' | 'BlogPosting';
    headline: string;
    image: string;
    datePublished?: string;
    description?: string;
  };
}

const SITE_ORIGIN = 'https://sokfarm.com';

export const SeoHead: React.FC<SeoHeadProps> = ({
  title,
  description = 'Sokfarm là nhà sản xuất, kinh doanh và xuất khẩu các sản phẩm từ mật hoa dừa hữu cơ tại Việt Nam.',
  canonicalPath,
  image = `${SITE_ORIGIN}/images/logo_sokfarm2.png`,
  ogType,
  keywords,
  breadcrumbs,
  productSchema,
  articleSchema,
}) => {
  useEffect(() => {
    const cleanPath = canonicalPath.startsWith('/') ? canonicalPath : `/${canonicalPath}`;
    const canonicalUrl = `${SITE_ORIGIN}${cleanPath === '/' ? '/' : cleanPath}`;
    const resolvedImage = image.startsWith('http')
      ? image
      : `${SITE_ORIGIN}${image.startsWith('/') ? image : `/${image}`}`;
    const resolvedOgType = ogType || (articleSchema ? 'article' : 'website');

    document.title = title;

    const setMeta = (selector: string, attrName: 'name' | 'property', key: string, content: string) => {
      let el = document.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attrName, key);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    setMeta('meta[name="description"]', 'name', 'description', description);
    setMeta('meta[property="og:title"]', 'property', 'og:title', title);
    setMeta('meta[property="og:description"]', 'property', 'og:description', description);
    setMeta('meta[property="og:type"]', 'property', 'og:type', resolvedOgType);
    setMeta('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);
    setMeta('meta[property="og:image"]', 'property', 'og:image', resolvedImage);
    setMeta('meta[name="twitter:card"]', 'name', 'twitter:card', 'summary_large_image');
    setMeta('meta[name="twitter:title"]', 'name', 'twitter:title', title);
    setMeta('meta[name="twitter:description"]', 'name', 'twitter:description', description);
    setMeta('meta[name="twitter:image"]', 'name', 'twitter:image', resolvedImage);

    const existingKeywords = document.querySelector('meta[name="keywords"]');
    if (keywords && keywords.length > 0) {
      setMeta('meta[name="keywords"]', 'name', 'keywords', keywords.join(', '));
    } else if (existingKeywords) {
      existingKeywords.remove();
    }

    const existingPublishedTime = document.querySelector('meta[property="article:published_time"]');
    if (articleSchema?.datePublished) {
      setMeta(
        'meta[property="article:published_time"]',
        'property',
        'article:published_time',
        articleSchema.datePublished
      );
    } else if (existingPublishedTime) {
      existingPublishedTime.remove();
    }

    let linkCanonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!linkCanonical) {
      linkCanonical = document.createElement('link');
      linkCanonical.setAttribute('rel', 'canonical');
      document.head.appendChild(linkCanonical);
    }
    linkCanonical.setAttribute('href', canonicalUrl);

    const schemas: Record<string, unknown>[] = [
      {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: 'Công ty TNHH Trà Vinh Farm (Sokfarm)',
        url: SITE_ORIGIN,
        logo: `${SITE_ORIGIN}/images/logo_sokfarm2.png`,
        telephone: '+84-966-243-066',
        email: 'hello@sokfarm.com',
        address: {
          '@type': 'PostalAddress',
          streetAddress: 'Ấp Cây Hẹ, Xã Tiểu Cần',
          addressLocality: 'Tiểu Cần',
          addressRegion: 'Vĩnh Long',
          addressCountry: 'VN',
        },
      },
    ];

    if (breadcrumbs && breadcrumbs.length > 0) {
      schemas.push({
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        itemListElement: breadcrumbs.map((b, idx) => ({
          '@type': 'ListItem',
          position: idx + 1,
          name: b.name,
          item: `${SITE_ORIGIN}${b.path}`,
        })),
      });
    }

    if (productSchema) {
      schemas.push({
        '@context': 'https://schema.org',
        '@type': 'Product',
        name: productSchema.name,
        image: productSchema.image,
        description: productSchema.description || description,
        sku: productSchema.sku,
        brand: {
          '@type': 'Brand',
          name: 'Sokfarm',
        },
        offers:
          productSchema.price > 0
            ? {
                '@type': 'Offer',
                url: canonicalUrl,
                priceCurrency: 'VND',
                price: productSchema.price,
                availability: 'https://schema.org/InStock',
              }
            : {
                '@type': 'Offer',
                url: canonicalUrl,
                priceCurrency: 'VND',
                availability: 'https://schema.org/InStock',
              },
      });
    }

    if (articleSchema) {
      const articleImage = articleSchema.image.startsWith('http')
        ? articleSchema.image
        : `${SITE_ORIGIN}${articleSchema.image.startsWith('/') ? articleSchema.image : `/${articleSchema.image}`}`;
      const articleJsonLd: Record<string, unknown> = {
        '@context': 'https://schema.org',
        '@type': articleSchema.schemaType || 'Article',
        headline: articleSchema.headline,
        image: articleImage,
        description: articleSchema.description || description,
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': canonicalUrl,
        },
        publisher: {
          '@type': 'Organization',
          name: 'Sokfarm',
          logo: {
            '@type': 'ImageObject',
            url: `${SITE_ORIGIN}/images/logo_sokfarm2.png`,
          },
        },
      };
      if (articleSchema.datePublished) {
        articleJsonLd.datePublished = articleSchema.datePublished;
      }
      schemas.push(articleJsonLd);
    }

    let ldScript = document.getElementById('sokfarm-jsonld') as HTMLScriptElement | null;
    if (!ldScript) {
      ldScript = document.createElement('script');
      ldScript.id = 'sokfarm-jsonld';
      ldScript.type = 'application/ld+json';
      document.head.appendChild(ldScript);
    }
    ldScript.textContent = JSON.stringify(schemas);
  }, [title, description, canonicalPath, image, ogType, keywords, breadcrumbs, productSchema, articleSchema]);

  return null;
};
