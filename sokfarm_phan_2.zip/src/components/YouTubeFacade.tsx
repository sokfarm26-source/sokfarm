import React, { useState } from 'react';

interface YouTubeFacadeProps {
  videoId: string;
  title: string;
  height?: number | string;
  className?: string;
}

export const YouTubeFacade: React.FC<YouTubeFacadeProps> = ({
  videoId,
  title,
  height = 500,
  className = '',
}) => {
  const [activated, setActivated] = useState(false);

  if (activated) {
    return (
      <div
        className={className}
        style={{
          position: 'relative',
          width: '100%',
          aspectRatio: '16 / 9',
          maxHeight: typeof height === 'number' ? `${height}px` : height,
          borderRadius: '10px',
          overflow: 'hidden',
          background: '#000',
        }}
      >
        <iframe
          width="100%"
          height="100%"
          style={{ width: '100%', height: '100%', border: 0, display: 'block' }}
          src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
    );
  }

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        width: '100%',
        aspectRatio: '16 / 9',
        maxHeight: typeof height === 'number' ? `${height}px` : height,
        borderRadius: '10px',
        overflow: 'hidden',
        background: '#111',
      }}
    >
      <img
        src={`https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`}
        alt={title}
        width={480}
        height={360}
        loading="lazy"
        decoding="async"
        style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
      />
      <button
        type="button"
        onClick={() => setActivated(true)}
        aria-label={`Phát video: ${title}`}
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          border: 0,
          background: 'rgba(0,0,0,0.28)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
        }}
      >
        <span
          style={{
            width: '72px',
            height: '50px',
            borderRadius: '12px',
            background: '#158247',
            color: '#fff',
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '22px',
            boxShadow: '0 4px 16px rgba(0,0,0,0.35)',
          }}
        >
          <i className="fa fa-play" aria-hidden="true" style={{ marginLeft: '3px' }}></i>
        </span>
      </button>
    </div>
  );
};
