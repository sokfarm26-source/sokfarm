import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { SeoHead } from '../components/SeoHead';
import { latestBlogs, loadAllBlogs } from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { useArticleComments } from '../hooks/useArticleComments';
import { ArticleMetaBar } from '../components/ArticleMetaBar';
import { ArticleCommentsSection } from '../components/ArticleCommentsSection';
import { RelatedArticlesSection } from '../components/RelatedArticlesSection';
import { BlogSidebar } from '../components/BlogSidebar';

const ARTICLE_SLUG = '4-cach-lam-da-me-voi-mat-hoa-dua-co-dac';

const ARTICLE_TITLE = '4 Cách Làm Đá Me Với Mật Hoa Dừa Cô Đặc Sokfarm Tại Nhà';
const ARTICLE_PATH = '/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac';
const META_DESCRIPTION =
  'Khám phá 4 cách làm đá me với mật hoa dừa cô đặc Sokfarm tại nhà. Vị chua thanh của me hòa cùng vị ngọt từ hoa dừa, tạo nên thức uống thuần chay hấp dẫn.';
const COVER_IMAGE = '/images/opt/recipes/da-me/bia-4-cong-thuc-da-me.webp';

const KEYWORDS = [
  'cách làm đá me với mật hoa dừa cô đặc',
  'đá me mật hoa dừa Sokfarm',
  'công thức pha chế mật hoa dừa',
  'đá me hạt đác mật hoa dừa',
  'đá me tắc mật hoa dừa',
  'đá me hạt chia mật hoa dừa',
  'thức uống thuần chay',
];

const TOC_ITEMS = [
  { id: 'nguyen-lieu-mat-hoa-dua', label: 'Vì sao nên pha đá me với mật hoa dừa cô đặc Sokfarm?' },
  { id: 'cong-thuc-1', label: '1. Đá me mật hoa dừa truyền thống' },
  { id: 'cong-thuc-2', label: '2. Đá me hạt đác mật hoa dừa' },
  { id: 'cong-thuc-3', label: '3. Đá me tắc mật hoa dừa' },
  { id: 'cong-thuc-4', label: '4. Đá me hạt chia mật hoa dừa' },
  { id: 'ket-luan', label: 'Bí quyết pha đá me ngon và lời kết' },
];

export const DaMeRecipePage: React.FC = () => {
  const [recentBlogs, setRecentBlogs] = useState<BlogPost[]>(latestBlogs);
  const { comments, addComment } = useArticleComments(ARTICLE_SLUG);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    let cancelled = false;
    loadAllBlogs().then((all) => {
      if (!cancelled) setRecentBlogs(all);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const currentPost = recentBlogs.find((b) => b.slug === ARTICLE_SLUG);

  const relatedRecipes = recentBlogs
    .filter(
      (b) =>
        b.catSlug === 'cong-thuc-che-bien' &&
        b.slug !== ARTICLE_SLUG
    )
    .slice(0, 5);

  const breadcrumbs = [
    { name: 'Trang chủ', path: '/' },
    { name: 'Tin tức & Kiến thức', path: '/goc-kham-pha' },
    { name: 'Công thức chế biến', path: '/goc-kham-pha/cong-thuc-che-bien' },
    { name: ARTICLE_TITLE, path: ARTICLE_PATH },
  ];

  const handleTocClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const el = document.getElementById(targetId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      window.history.replaceState(null, '', `#${targetId}`);
    }
  };

  return (
    <>
      <SeoHead
        title={ARTICLE_TITLE}
        description={META_DESCRIPTION}
        canonicalPath={ARTICLE_PATH}
        image={COVER_IMAGE}
        ogType="article"
        keywords={KEYWORDS}
        breadcrumbs={breadcrumbs}
        articleSchema={{
          schemaType: 'BlogPosting',
          headline: ARTICLE_TITLE,
          image: COVER_IMAGE,
          datePublished: '2026-11-12',
          description: META_DESCRIPTION,
        }}
      />

      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/goc-kham-pha">
                      Tin tức &amp; Kiến thức<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/goc-kham-pha/cong-thuc-che-bien">
                      Công thức chế biến<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <span>{ARTICLE_TITLE}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Article Section */}
      <section className="blog-single section" style={{ paddingTop: '40px', paddingBottom: '70px' }}>
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-12">
              <article className="blog-single-main" style={{ marginTop: 0 }}>
                {/* Cover Image */}
                <figure className="mb-4">
                  <div className="image rounded overflow-hidden">
                    <img
                      src={COVER_IMAGE}
                      alt="4 cách làm đá me với mật hoa dừa cô đặc Sokfarm tại nhà"
                      width={1200}
                      height={844}
                      decoding="async"
                      fetchPriority="high"
                      className="img-fluid w-100"
                      style={{ height: 'auto', display: 'block', borderRadius: '8px' }}
                    />
                  </div>
                  <figcaption
                    className="text-center text-muted mt-2"
                    style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                  >
                    4 gợi ý pha chế đá me kết hợp cùng mật hoa dừa cô đặc Sokfarm tại nhà
                  </figcaption>
                </figure>

                <div className="blog-detail">
                  <div className="mb-3">
                    <Link
                      to="/goc-kham-pha/cong-thuc-che-bien"
                      className="categories-news-link d-inline-block"
                      style={{ padding: '4px 14px', fontSize: '13px', textDecoration: 'none' }}
                    >
                      Công thức chế biến
                    </Link>
                  </div>

                  <h1
                    className="blog-title web-color-origin"
                    style={{
                      fontSize: 'clamp(24px, 4vw, 32px)',
                      lineHeight: 1.35,
                      marginTop: 0,
                      marginBottom: '14px',
                      textTransform: 'none',
                    }}
                  >
                    {ARTICLE_TITLE}
                  </h1>

                  <ArticleMetaBar
                    author={currentPost?.author || 'Admin'}
                    date={currentPost?.date || '12 Nov, 2026'}
                    commentCount={comments.length}
                    dateFormat="raw"
                  />

                  {/* Sapo / Intro */}
                  <p
                    className="mb-4"
                    style={{
                      fontSize: '16px',
                      lineHeight: 1.75,
                      color: '#2b2b2b',
                      borderLeft: '4px solid #158247',
                      paddingLeft: '16px',
                      backgroundColor: '#f8faf8',
                      paddingTop: '12px',
                      paddingBottom: '12px',
                      paddingRight: '14px',
                      borderRadius: '0 6px 6px 0',
                    }}
                  >
                    Đá me là thức uống giải nhiệt quen thuộc với vị chua thanh dễ chịu của me chín
                    hòa quyện cùng vị ngọt dịu mát. Thay vì sử dụng đường tinh luyện, bạn hoàn toàn
                    có thể áp dụng <strong>cách làm đá me với mật hoa dừa cô đặc</strong> Sokfarm để
                    mang lại sắc thái ngọt tự nhiên từ thực vật, phù hợp cho cả người ăn chay lẫn
                    những ai yêu thích đồ uống thanh lành.
                  </p>

                  {/* Table of Contents */}
                  <nav
                    aria-label="Mục lục bài viết"
                    className="p-4 rounded mb-5"
                    style={{
                      backgroundColor: '#fbf4eb',
                      border: '1px solid #eadcc5',
                    }}
                  >
                    <h2
                      className="web-color-origin mb-3"
                      style={{ fontSize: '18px', fontWeight: 700 }}
                    >
                      Mục lục bài viết
                    </h2>
                    <ul
                      className="mb-0"
                      style={{
                        listStyle: 'none',
                        paddingLeft: 0,
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px',
                      }}
                    >
                      {TOC_ITEMS.map((item) => (
                        <li key={item.id}>
                          <a
                            href={`#${item.id}`}
                            onClick={(e) => handleTocClick(e, item.id)}
                            style={{
                              color: '#158247',
                              fontWeight: 600,
                              fontSize: '15px',
                              textDecoration: 'none',
                            }}
                          >
                            <i className="ti-angle-right mr-2" aria-hidden="true"></i>
                            {item.label}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </nav>

                  {/* Intro Section */}
                  <div className="content content-post">
                    <section id="nguyen-lieu-mat-hoa-dua" className="mb-5">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        Vì sao nên pha đá me với mật hoa dừa cô đặc Sokfarm?
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Mật hoa dừa cô đặc Sokfarm</strong> được sản xuất từ 100% mật hoa
                        dừa hữu cơ thu hoạch tại Trà Vinh theo kỹ thuật mát-xa truyền thống, cô đặc
                        chân không ở nhiệt độ thấp 55–60°C để giữ trọn dưỡng chất tự nhiên và hương
                        thơm đặc trưng. Khi kết hợp với cốt me chín, sản phẩm giúp món đá me có hậu
                        vị ngọt dịu, không gắt cổ và dễ dàng hòa tan ngay cả khi khuấy cùng nước mát.
                      </p>
                      <ul
                        className="mb-0 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>
                          <strong>Thuần thực vật 100%:</strong> Phù hợp cho thực đơn thuần chay và
                          gia đình ưu tiên nguyên liệu hữu cơ tự nhiên.
                        </li>
                        <li>
                          <strong>Hậu vị ngọt thanh, hương caramel dừa nhẹ:</strong> Cân bằng tốt
                          vị chua đặc trưng của me chín mà không làm mất đi mùi thơm tự nhiên của me.
                        </li>
                        <li>
                          <strong>Pha chế nhanh gọn tại nhà:</strong> Chỉ cần điều chỉnh 20–30 g mật
                          hoa dừa cô đặc cho mỗi ly 150 ml là đã có ngay thức uống thơm ngon.
                        </li>
                      </ul>
                    </section>

                    {/* Recipe 1 */}
                    <section id="cong-thuc-1" className="mb-5 pb-4 border-bottom">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        1. Đá me mật hoa dừa truyền thống
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Phiên bản truyền thống giữ nguyên nét mộc mạc quen thuộc của ly đá me tuổi
                        thơ nhưng được nâng tầm bằng vị ngọt sánh mịn của mật hoa dừa cô đặc, kết
                        hợp đậu phộng rang và mè rang giòn bùi.
                      </p>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Nguyên liệu chuẩn bị (1 ly)
                      </h3>
                      <ul
                        className="mb-4 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>40 g me chín đã bỏ vỏ</li>
                        <li>20–30 g mật hoa dừa cô đặc Sokfarm</li>
                        <li>150 ml nước lọc (hoặc nước ấm để dầm me nhanh ra cốt)</li>
                        <li>10–15 g đậu phộng rang giã dập và ít mè trắng rang thơm</li>
                        <li>Đá viên vừa đủ</li>
                      </ul>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Cách pha chế
                      </h3>
                      <ol
                        className="mb-4 pl-4"
                        style={{ listStyle: 'decimal', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>
                          Dầm 40 g me chín với 150 ml nước ấm rồi lọc qua rây để thu lấy phần nước
                          cốt me sánh mịn, loại bỏ hạt và xơ me.
                        </li>
                        <li>
                          Cho 20–30 g mật hoa dừa cô đặc Sokfarm vào phần nước cốt me, khuấy đều đến
                          khi mật hòa quyện hoàn toàn.
                        </li>
                        <li>
                          Thêm đá viên đầy ly, rưới hỗn hợp cốt me mật hoa dừa lên trên.
                        </li>
                        <li>
                          Rắc đậu phộng rang và mè trắng rang thơm lên bề mặt rồi thưởng thức ngay.
                        </li>
                      </ol>

                      <figure className="my-4 text-center">
                        <img
                          src="/images/opt/recipes/da-me/thanh-pham-da-me-truyen-thong.webp"
                          alt="Ly đá me truyền thống với mật hoa dừa cô đặc Sokfarm và đậu phộng rang"
                          width={1080}
                          height={1182}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded mx-auto"
                          style={{ maxWidth: '640px', width: '100%', height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Thành phẩm đá me mật hoa dừa truyền thống thơm bùi đậu phộng và mè rang
                        </figcaption>
                      </figure>

                      <blockquote className="mb-0">
                        <i className="fa fa-quote-left" aria-hidden="true"></i>
                        <strong>Hương vị:</strong> Vị chua ngọt hài hòa, kết hợp cùng vị bùi giòn
                        của đậu phộng rang. Mật hoa dừa cô đặc mang đến sắc thái ngọt dịu khác biệt
                        cho món nước quen thuộc.
                      </blockquote>
                    </section>

                    {/* Recipe 2 */}
                    <section id="cong-thuc-2" className="mb-5 pb-4 border-bottom">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        2. Đá me hạt đác mật hoa dừa
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Sự góp mặt của hạt đác dẻo giòn sần sật biến tấu ly đá me thành món giải
                        khát vừa đã khát vừa vui miệng, rất được ưa chuộng trong những ngày nắng
                        nóng.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/recipes/da-me/nguyen-lieu-da-me-hat-dac.webp"
                          alt="Nguyên liệu làm đá me hạt đác với mật hoa dừa cô đặc Sokfarm"
                          width={1080}
                          height={720}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Nguyên liệu chuẩn bị cho món đá me hạt đác mật hoa dừa Sokfarm
                        </figcaption>
                      </figure>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Nguyên liệu chuẩn bị (1 ly)
                      </h3>
                      <ul
                        className="mb-4 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>40 g me chín đã bỏ vỏ</li>
                        <li>20–30 g mật hoa dừa cô đặc Sokfarm</li>
                        <li>30 g hạt đác đã sơ chế và nấu chín</li>
                        <li>150 ml nước lọc</li>
                        <li>Đá viên (có thể thêm đậu phộng rang nếu thích)</li>
                      </ul>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Cách pha chế
                      </h3>
                      <ol
                        className="mb-4 pl-4"
                        style={{ listStyle: 'decimal', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>
                          Dầm 40 g me chín với 150 ml nước lọc ấm, lọc qua rây để lấy nước cốt me
                          mịn.
                        </li>
                        <li>
                          Hòa tan 20–30 g mật hoa dừa cô đặc Sokfarm vào nước cốt me, có thể chừa
                          lại 1 thìa mật để trộn áo đều cho phần hạt đác đã nấu chín thêm đậm vị.
                        </li>
                        <li>
                          Cho đá viên vào ly, rót hỗn hợp nước cốt me mật hoa dừa vào và xếp 30 g
                          hạt đác lên trên.
                        </li>
                        <li>
                          Khuấy đều trước khi thưởng thức để cảm nhận trọn vẹn vị chua ngọt mát lành
                          cùng hạt đác giòn dai.
                        </li>
                      </ol>

                      <figure className="my-4">
                        <img
                          src="/images/opt/recipes/da-me/thanh-pham-da-me-hat-dac.webp"
                          alt="Ly đá me mật hoa dừa cô đặc Sokfarm kết hợp hạt đác"
                          width={1080}
                          height={718}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Đá me hạt đác mật hoa dừa giòn dai, thanh mát giải nhiệt
                        </figcaption>
                      </figure>
                    </section>

                    {/* Recipe 3 */}
                    <section id="cong-thuc-3" className="mb-5 pb-4 border-bottom">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        3. Đá me tắc mật hoa dừa
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Thêm nước cốt và vỏ tắc tươi giúp ly đá me dậy mùi thơm tinh dầu cam chanh
                        sảng khoái, tăng cảm giác thanh mát tức thì mà vẫn giữ được hậu ngọt êm từ
                        mật hoa dừa cô đặc.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/recipes/da-me/nguyen-lieu-da-me-tac.webp"
                          alt="Nguyên liệu làm đá me tắc gồm me chín, tắc, mật hoa dừa cô đặc Sokfarm và đá viên"
                          width={1080}
                          height={720}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Trọn bộ nguyên liệu cho món đá me tắc mật hoa dừa thơm mát
                        </figcaption>
                      </figure>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Nguyên liệu chuẩn bị (1 ly)
                      </h3>
                      <ul
                        className="mb-4 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>40 g me chín đã bỏ vỏ</li>
                        <li>20–30 g mật hoa dừa cô đặc Sokfarm</li>
                        <li>1–2 quả tắc tươi</li>
                        <li>150 ml nước lọc</li>
                        <li>Đá viên và 1–2 lát tắc trang trí</li>
                      </ul>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Cách pha chế
                      </h3>
                      <ol
                        className="mb-4 pl-4"
                        style={{ listStyle: 'decimal', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>
                          Dầm 40 g me chín cùng 150 ml nước lọc ấm, lọc bỏ hạt và bã để lấy phần
                          nước cốt me.
                        </li>
                        <li>
                          Khuấy tan 20–30 g mật hoa dừa cô đặc Sokfarm với nước cốt me.
                        </li>
                        <li>
                          Vắt 1–2 quả tắc lấy nước cốt (bỏ hạt để không bị đắng), cho vào hỗn hợp
                          trên và khuấy đều.
                        </li>
                        <li>
                          Đổ hỗn hợp ra ly đá viên, đặt thêm lát tắc cắt mỏng và lá bạc hà lên trên
                          để tăng hương thơm trước khi thưởng thức.
                        </li>
                      </ol>

                      <figure className="my-4 text-center">
                        <img
                          src="/images/opt/recipes/da-me/thanh-pham-da-me-tac.webp"
                          alt="Ly đá me mật hoa dừa cô đặc Sokfarm trang trí bằng tắc tươi"
                          width={1080}
                          height={1080}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded mx-auto"
                          style={{ maxWidth: '640px', width: '100%', height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Đá me tắc mật hoa dừa thơm dịu hương tắc tươi, sảng khoái ngày nắng
                        </figcaption>
                      </figure>
                    </section>

                    {/* Recipe 4 */}
                    <section id="cong-thuc-4" className="mb-5 pb-4 border-bottom">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        4. Đá me hạt chia mật hoa dừa
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Nếu bạn thích thức uống nhẹ bụng, bổ sung thêm chất xơ thực vật tự nhiên,
                        đá me hạt chia mật hoa dừa là lựa chọn hoàn hảo cho thực đơn thuần chay mỗi
                        ngày.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/recipes/da-me/nguyen-lieu-da-me-hat-chia.webp"
                          alt="Nguyên liệu làm đá me hạt chia với mật hoa dừa cô đặc Sokfarm"
                          width={1080}
                          height={720}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Nguyên liệu thuần chay cho công thức đá me hạt chia mật hoa dừa
                        </figcaption>
                      </figure>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Nguyên liệu chuẩn bị (1 ly)
                      </h3>
                      <ul
                        className="mb-4 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>40 g me chín đã bỏ vỏ</li>
                        <li>20–30 g mật hoa dừa cô đặc Sokfarm</li>
                        <li>1–2 thìa cà phê hạt chia (khoảng 5–10 g)</li>
                        <li>150 ml nước lọc</li>
                        <li>Đá viên</li>
                      </ul>

                      <h3 className="mt-4 mb-2" style={{ fontSize: '18px', color: '#1a1a1a' }}>
                        Cách pha chế
                      </h3>
                      <ol
                        className="mb-4 pl-4"
                        style={{ listStyle: 'decimal', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>
                          Ngâm hạt chia với khoảng 50 ml nước lọc trong 10–15 phút cho đến khi hạt
                          chia nở đều.
                        </li>
                        <li>
                          Dầm 40 g me chín với 100 ml nước ấm còn lại, lọc qua rây để lấy cốt me mịn.
                        </li>
                        <li>
                          Cho 20–30 g mật hoa dừa cô đặc Sokfarm vào nước cốt me, khuấy đều để tạo độ
                          ngọt hài hòa.
                        </li>
                        <li>
                          Cho đá viên vào ly, rót hỗn hợp me mật hoa dừa và thêm phần hạt chia đã
                          ngâm nở lên trên, khuấy nhẹ và thưởng thức.
                        </li>
                      </ol>

                      <figure className="my-4 text-center">
                        <img
                          src="/images/opt/recipes/da-me/thanh-pham-da-me-hat-chia.webp"
                          alt="Ly đá me mật hoa dừa cô đặc Sokfarm kết hợp hạt chia"
                          width={1080}
                          height={1080}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded mx-auto"
                          style={{ maxWidth: '640px', width: '100%', height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Thành phẩm đá me hạt chia mật hoa dừa thanh nhẹ, giàu chất xơ thực vật
                        </figcaption>
                      </figure>
                    </section>

                    {/* Conclusion & CTA */}
                    <section id="ket-luan" className="mb-4">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        Bí quyết pha đá me ngon và lời kết
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Để ly đá me với mật hoa dừa cô đặc giữ được vị chua ngọt cân đối, bạn có thể
                        gia giảm lượng mật từ 20 g đến 30 g tùy độ chua của me chín và khẩu vị gia
                        đình. Nếu thích hương vị đậm đà hơn, hãy chọn me chín dẻo màu nâu sẫm và
                        lưu ý lọc kỹ bã me để thức uống có độ sánh trong hấp dẫn.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Với 4 biến tấu từ truyền thống, hạt đác, tắc đến hạt chia, bạn có thể dễ
                        dàng thay đổi thực đơn giải nhiệt mỗi ngày tại nhà bằng vị ngọt thuần chay
                        từ hoa dừa Trà Vinh.
                      </p>

                      {/* Product CTA Box */}
                      <div
                        className="p-4 rounded mt-4 d-flex flex-column flex-md-row align-items-md-center justify-content-between"
                        style={{
                          backgroundColor: '#f3f9f5',
                          border: '1px solid #cce3d4',
                          gap: '16px',
                        }}
                      >
                        <div>
                          <div
                            className="web-color-origin font-weight-bold mb-1"
                            style={{ fontSize: '18px' }}
                          >
                            Mật hoa dừa cô đặc organic Sokfarm
                          </div>
                          <p className="mb-0" style={{ fontSize: '14.5px', color: '#444' }}>
                            100% nguyên chất từ mật hoa dừa hữu cơ Trà Vinh, vị ngọt tự nhiên thuần
                            chay cho mọi thức uống giải nhiệt và món ngon tại nhà.
                          </p>
                        </div>
                        <Link
                          to="/san-pham/mat-hoa-dua-co-dac-huu-co"
                          className="btn text-white flex-shrink-0"
                          style={{
                            backgroundColor: '#158247',
                            borderColor: '#158247',
                            padding: '12px 22px',
                            fontWeight: 600,
                            borderRadius: '6px',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          Khám phá mật hoa dừa cô đặc Sokfarm
                        </Link>
                      </div>
                    </section>
                  </div>
                </div>
              </article>

              <ArticleCommentsSection comments={comments} onAddComment={addComment} />

              <RelatedArticlesSection
                currentSlug={ARTICLE_SLUG}
                catSlug="cong-thuc-che-bien"
                posts={recentBlogs}
              />
            </div>

            {/* Sidebar */}
            <BlogSidebar
              recentPosts={relatedRecipes}
              recentTitle="Tin Mới"
              activeCategorySlug="cong-thuc-che-bien"
            />
          </div>
        </div>
      </section>
    </>
  );
};
