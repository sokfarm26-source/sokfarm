import React, { useEffect, useState, useMemo } from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import {
  products,
  B2C_CATEGORIES,
  TOP_B2C_CATEGORIES,
  SECONDARY_COLLECTIONS,
  ALL_PRODUCT_GROUPINGS,
  LEGACY_CATEGORY_REDIRECT_MAP,
  getProductsForGrouping,
  getB2CProducts,
  getCategoryPath,
  getProductPath,
  getProductVolumeBuckets,
  getProductPriceRange,
  matchesPriceBucket,
  matchesUsageBucket,
  normalizeTextVi,
  type VolumeFilterBucket,
  type PriceFilterBucket,
  type UsageFilterBucket,
} from '../data/siteData';
import { ProductCard } from '../components/ProductCard';
import { SeoHead } from '../components/SeoHead';

interface ProductCategoryPageProps {
  mode?: 'all' | 'category' | 'collection' | 'horeca' | 'bestseller' | 'legacy';
}

interface ComparisonLineItem {
  slug: string;
  label: string;
  form: string;
  usage: string;
  storage: string;
  packaging: string;
}

const COCONUT_COMPARISON_ITEMS: ComparisonLineItem[] = [
  {
    slug: 'mat-hoa-dua-tuoi-huu-co',
    label: 'Mật hoa dừa tươi',
    form: 'Nước mật dạng lỏng thanh mát (thanh trùng, rót nóng & cấp đông)',
    usage: 'Uống trực tiếp giải khát, bù khoáng điện giải; nấu chè, pha cà phê, nước ép',
    storage: 'Bảo quản ngăn đông (-15°C) hoặc ngăn mát tủ lạnh (5-7°C)',
    packaging: 'Chai 250 ml (HDPE), Chai 250 ml (Thủy tinh), Chai 1 L (và dòng hộp UHT 330ml)',
  },
  {
    slug: 'mat-hoa-dua-co-dac-huu-co',
    label: 'Mật hoa dừa cô đặc',
    form: 'Mật sánh tự nhiên (cô đặc chân không ở nhiệt độ thấp 55-60°C)',
    usage: 'Pha chế đồ uống, nấu ăn, làm bánh; thay thế đường tinh luyện và mật ong',
    storage: 'Nơi khô ráo thoáng mát, tránh ánh nắng; khuyến khích bảo quản ngăn mát sau khi mở nắp (HSD 24 tháng)',
    packaging: 'Hũ 250 g, Gói Stick 15 g x 12 gói, Chai 685 g, Can 1.4 kg, Can 7 kg',
  },
  {
    slug: 'duong-hoa-dua-huu-co',
    label: 'Đường hoa dừa',
    form: 'Đường hạt mịn không tách mật, không qua tinh luyện',
    usage: 'Tạo ngọt trong nấu ăn, làm bánh, pha trà/cà phê hoặc dùng trực tiếp bổ sung năng lượng',
    storage: 'Bảo quản nơi thoáng mát, tránh ánh nắng trực tiếp',
    packaging: 'Hũ 150 g, Túi 300 g, Túi 1 kg, Túi 5 kg',
  },
];

export const ProductCategoryPage: React.FC<ProductCategoryPageProps> = ({ mode = 'category' }) => {
  const { slug } = useParams<{ slug?: string }>();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [volumeFilter, setVolumeFilter] = useState<VolumeFilterBucket>('all');
  const [priceFilter, setPriceFilter] = useState<PriceFilterBucket>('all');
  const [usageFilter, setUsageFilter] = useState<UsageFilterBucket>('all');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc'>('default');

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    setSearchQuery('');
    setSelectedCategoryFilter('all');
    setVolumeFilter('all');
    setPriceFilter('all');
    setUsageFilter('all');
    setSortBy('default');
  }, [slug, mode]);

  if (mode === 'legacy' && slug) {
    const legacyTarget = LEGACY_CATEGORY_REDIRECT_MAP[slug];
    if (legacyTarget) {
      return <Navigate to={legacyTarget} replace />;
    }
    if (ALL_PRODUCT_GROUPINGS.some((g) => g.slug === slug)) {
      return <Navigate to={getCategoryPath(slug)} replace />;
    }
  }

  const effectiveSlug =
    mode === 'bestseller'
      ? 'ban-chay-nhat'
      : mode === 'horeca'
        ? 'nguyen-lieu-horeca'
        : slug;

  const grouping = mode === 'all' ? undefined : ALL_PRODUCT_GROUPINGS.find((c) => c.slug === effectiveSlug);

  if ((mode === 'category' || mode === 'collection') && grouping?.slug === 'ban-chay-nhat') {
    return <Navigate to="/san-pham/ban-chay-nhat" replace />;
  }
  if (mode === 'category' && grouping?.isCollection) {
    return <Navigate to={`/bo-suu-tap/${grouping.slug}`} replace />;
  }
  if (mode === 'collection' && grouping && !grouping.isCollection) {
    return <Navigate to={getCategoryPath(grouping.slug)} replace />;
  }

  const baseProducts = useMemo(() => {
    if (mode === 'all') return getB2CProducts();
    return grouping ? getProductsForGrouping(grouping.slug) : [];
  }, [mode, grouping]);

  const filteredProducts = useMemo(() => {
    const qNorm = normalizeTextVi(searchQuery.trim());
    let result = baseProducts.filter((prod) => {
      if (qNorm) {
        const attrText = (prod.dataProducts || []).map((v) => v.attributes).join(' ');
        const matched =
          normalizeTextVi(prod.title).includes(qNorm) ||
          normalizeTextVi(prod.slug).includes(qNorm) ||
          normalizeTextVi(attrText).includes(qNorm);
        if (!matched) return false;
      }

      if (selectedCategoryFilter !== 'all') {
        const catObj = B2C_CATEGORIES.find((c) => c.slug === selectedCategoryFilter);
        if (catObj && !catObj.productSlugs?.includes(prod.slug)) return false;
      }

      if (volumeFilter !== 'all') {
        if (!getProductVolumeBuckets(prod).includes(volumeFilter)) return false;
      }

      if (!matchesPriceBucket(prod, priceFilter)) return false;

      if (!matchesUsageBucket(prod, usageFilter)) return false;

      return true;
    });

    if (sortBy === 'price-asc') {
      result = [...result].sort((a, b) => getProductPriceRange(a).min - getProductPriceRange(b).min);
    } else if (sortBy === 'price-desc') {
      result = [...result].sort((a, b) => getProductPriceRange(b).min - getProductPriceRange(a).min);
    }
    return result;
  }, [baseProducts, searchQuery, selectedCategoryFilter, volumeFilter, priceFilter, usageFilter, sortBy]);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedCategoryFilter !== 'all' ||
    volumeFilter !== 'all' ||
    priceFilter !== 'all' ||
    usageFilter !== 'all' ||
    sortBy !== 'default';

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategoryFilter('all');
    setVolumeFilter('all');
    setPriceFilter('all');
    setUsageFilter('all');
    setSortBy('default');
  };

  const parentCat = grouping?.parentSlug
    ? B2C_CATEGORIES.find((c) => c.slug === grouping.parentSlug)
    : null;
  const childCats =
    grouping?.childrenSlugs && grouping.childrenSlugs.length > 0
      ? B2C_CATEGORIES.filter((c) => grouping.childrenSlugs?.includes(c.slug))
      : [];

  const canonicalPath = mode === 'all' ? '/san-pham' : grouping ? getCategoryPath(grouping.slug) : '/san-pham';

  const headingTitle =
    mode === 'all'
      ? 'Tất cả sản phẩm mật hoa dừa hữu cơ Sokfarm'
      : mode === 'bestseller'
        ? 'Sản phẩm bán chạy nhất'
        : grouping?.name || 'Không tìm thấy danh mục';

  const pageTitle =
    mode === 'all'
      ? 'Tất cả sản phẩm | Sokfarm'
      : grouping
        ? `${headingTitle} | Sokfarm`
        : 'Không tìm thấy danh mục | Sokfarm';

  const breadcrumbList =
    mode === 'all'
      ? [
          { name: 'Trang chủ', path: '/' },
          { name: 'Sản phẩm', path: '/san-pham' },
        ]
      : [
          { name: 'Trang chủ', path: '/' },
          ...(mode === 'horeca' || grouping?.isB2B
            ? [{ name: 'Đối tác & Xuất khẩu', path: '/export-markets' }]
            : [{ name: 'Sản phẩm', path: '/san-pham' }]),
          ...(parentCat ? [{ name: parentCat.name, path: getCategoryPath(parentCat.slug) }] : []),
          ...(grouping ? [{ name: grouping.name, path: canonicalPath }] : []),
        ];

  const isValidView = mode === 'all' || Boolean(grouping);

  return (
    <>
      <SeoHead
        title={pageTitle}
        description={
          grouping?.description ||
          'Khám phá toàn bộ sản phẩm mật hoa dừa hữu cơ Sokfarm: Mật hoa dừa tươi, cô đặc, đường hoa dừa, đồ uống, gia vị hữu cơ, sản phẩm cho bé và quà tặng.'
        }
        canonicalPath={canonicalPath}
        breadcrumbs={breadcrumbList}
      />

      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  {breadcrumbList.map((bc, idx) => {
                    const isLast = idx === breadcrumbList.length - 1;
                    return (
                      <li key={bc.path} className={isLast ? 'active' : undefined}>
                        <Link to={bc.path}>
                          {bc.name}
                          {!isLast && <i className="ti-arrow-right" aria-hidden="true"></i>}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="product-area shop-sidebar shop-list shop section py-4">
        <div className="container">
          {isValidView ? (
            <>
              {/* Category Header & Intro */}
              <div className="mb-4">
                <h1 className="web-color-origin mb-2" style={{ fontSize: '30px' }}>
                  {headingTitle}
                </h1>
                <p className="mb-3" style={{ fontSize: '15px', color: '#444', maxWidth: '860px' }}>
                  {mode === 'all'
                    ? 'Sản phẩm mật hoa dừa hữu cơ Trà Vinh đạt chuẩn quốc tế USDA, EU, JAS, Canada Organic, ISO 22000:2018 và OCOP 5 Sao.'
                    : grouping?.description}
                </p>

                {/* Quick Category Links on /san-pham */}
                {mode === 'all' && (
                  <div className="d-flex flex-wrap align-items-center mb-3" style={{ gap: '8px' }}>
                    <Link
                      to="/san-pham/ban-chay-nhat"
                      className="category-title-list m-0"
                      style={{ textDecoration: 'none' }}
                    >
                      Bán chạy nhất
                    </Link>
                    {TOP_B2C_CATEGORIES.map((cat) => (
                      <Link
                        key={cat.slug}
                        to={getCategoryPath(cat.slug)}
                        className="category-title-list m-0"
                        style={{ textDecoration: 'none' }}
                      >
                        {cat.name}
                      </Link>
                    ))}
                  </div>
                )}

                {/* Child Category Tabs */}
                {childCats.length > 0 && (
                  <div className="d-flex flex-wrap align-items-center mb-3" style={{ gap: '8px' }}>
                    <span className="font-weight-bold web-color-origin mr-1">Phân loại trực thuộc:</span>
                    {childCats.map((cc) => (
                      <Link
                        key={cc.slug}
                        to={getCategoryPath(cc.slug)}
                        className="category-title-list m-0"
                        style={{ textDecoration: 'none' }}
                      >
                        {cc.name}
                      </Link>
                    ))}
                  </div>
                )}

                {/* Parent link if on child category */}
                {parentCat && (
                  <div className="d-flex flex-wrap align-items-center mb-3" style={{ gap: '8px' }}>
                    <Link
                      to={getCategoryPath(parentCat.slug)}
                      className="btn btn-sm btn-outline-success"
                    >
                      <i className="ti-arrow-left mr-1" aria-hidden="true"></i>Xem toàn bộ {parentCat.name}
                    </Link>
                    {B2C_CATEGORIES.filter(
                      (c) => c.parentSlug === parentCat.slug && c.slug !== grouping?.slug
                    ).map((sibling) => (
                      <Link
                        key={sibling.slug}
                        to={getCategoryPath(sibling.slug)}
                        className="btn btn-sm btn-outline-secondary"
                      >
                        {sibling.name}
                      </Link>
                    ))}
                  </div>
                )}

                {/* HORECA B2B Callout */}
                {(mode === 'horeca' || grouping?.isB2B) && (
                  <div
                    className="p-3 p-md-4 rounded mb-4"
                    style={{ background: '#fbf4eb', border: '1px solid #d7e6dc' }}
                  >
                    <div
                      className="d-flex flex-column flex-md-row align-items-md-center justify-content-between"
                      style={{ gap: '12px' }}
                    >
                      <div>
                        <h2 className="web-color-origin mb-1" style={{ fontSize: '19px' }}>
                          Giải pháp nguyên liệu quy cách lớn cho Nhà hàng, Khách sạn, Quán cà phê &amp; Nhà máy F&amp;B
                        </h2>
                        <p className="mb-0" style={{ color: '#444' }}>
                          Các sản phẩm quy cách công nghiệp (can, túi lớn, thùng) được phân phối qua kênh Đối tác &amp; HORECA của Sokfarm.
                        </p>
                      </div>
                      <div className="d-flex flex-wrap" style={{ gap: '8px', flexShrink: 0 }}>
                        <Link to="/nguyen-lieu" className="btn btn-outline-success">
                          Tìm hiểu Nguyên liệu
                        </Link>
                        <Link to="/export-markets#bao-gia-xuat-khau" className="btn btn-success text-white">
                          Yêu cầu báo giá B2B
                        </Link>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Real Working Search + Multi-Filter Toolbar */}
              {!(mode === 'horeca' || grouping?.isB2B) && (
                <section
                  aria-label="Tìm kiếm và bộ lọc sản phẩm"
                  className="p-3 p-md-4 rounded mb-4"
                  style={{ backgroundColor: '#fbf4eb', border: '1px solid #d7e6dc' }}
                >
                  <div className="row" style={{ rowGap: '12px' }}>
                    <div className="col-12 col-md-4">
                      <label
                        htmlFor="catalog-search-input"
                        className="font-weight-bold mb-1 d-block"
                        style={{ fontSize: '13px', color: '#158247' }}
                      >
                        Tìm theo tên hoặc quy cách
                      </label>
                      <input
                        id="catalog-search-input"
                        type="text"
                        className="form-control"
                        placeholder="VD: Mật cô đặc, 330ml, Teriyaki..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        style={{ height: '42px', borderRadius: '6px', borderColor: '#cddbd2' }}
                      />
                    </div>

                    {(mode === 'all' || mode === 'bestseller' || mode === 'collection') && (
                      <div className="col-6 col-md-2">
                        <label
                          htmlFor="catalog-filter-category"
                          className="font-weight-bold mb-1 d-block"
                          style={{ fontSize: '13px', color: '#158247' }}
                        >
                          Loại sản phẩm
                        </label>
                        <select
                          id="catalog-filter-category"
                          className="form-control"
                          value={selectedCategoryFilter}
                          onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                          style={{ height: '42px', borderRadius: '6px', borderColor: '#cddbd2', fontSize: '13.5px' }}
                        >
                          <option value="all">Tất cả loại</option>
                          {B2C_CATEGORIES.filter((c) => c.slug !== 'mat-hoa-dua').map((c) => (
                            <option key={c.slug} value={c.slug}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div className="col-6 col-md-2">
                      <label
                        htmlFor="catalog-filter-volume"
                        className="font-weight-bold mb-1 d-block"
                        style={{ fontSize: '13px', color: '#158247' }}
                      >
                        Dung tích / Quy cách
                      </label>
                      <select
                        id="catalog-filter-volume"
                        className="form-control"
                        value={volumeFilter}
                        onChange={(e) => setVolumeFilter(e.target.value as VolumeFilterBucket)}
                        style={{ height: '42px', borderRadius: '6px', borderColor: '#cddbd2', fontSize: '13.5px' }}
                      >
                        <option value="all">Tất cả dung tích</option>
                        <option value="small">Nhỏ (&lt; 300ml / 300g)</option>
                        <option value="medium">Vừa (300ml – 1L / 1kg)</option>
                        <option value="large">Lớn / Combo / Quà</option>
                      </select>
                    </div>

                    <div className="col-6 col-md-2">
                      <label
                        htmlFor="catalog-filter-price"
                        className="font-weight-bold mb-1 d-block"
                        style={{ fontSize: '13px', color: '#158247' }}
                      >
                        Khoảng giá
                      </label>
                      <select
                        id="catalog-filter-price"
                        className="form-control"
                        value={priceFilter}
                        onChange={(e) => setPriceFilter(e.target.value as PriceFilterBucket)}
                        style={{ height: '42px', borderRadius: '6px', borderColor: '#cddbd2', fontSize: '13.5px' }}
                      >
                        <option value="all">Tất cả mức giá</option>
                        <option value="under-100k">Dưới 100.000đ</option>
                        <option value="100k-300k">100.000đ – 300.000đ</option>
                        <option value="over-300k">Trên 300.000đ</option>
                      </select>
                    </div>

                    <div className="col-6 col-md-2">
                      <label
                        htmlFor="catalog-filter-usage"
                        className="font-weight-bold mb-1 d-block"
                        style={{ fontSize: '13px', color: '#158247' }}
                      >
                        Nhu cầu sử dụng
                      </label>
                      <select
                        id="catalog-filter-usage"
                        className="form-control"
                        value={usageFilter}
                        onChange={(e) => setUsageFilter(e.target.value as UsageFilterBucket)}
                        style={{ height: '42px', borderRadius: '6px', borderColor: '#cddbd2', fontSize: '13.5px' }}
                      >
                        <option value="all">Mọi nhu cầu</option>
                        <option value="ban-chay-nhat">Bán chạy nhất</option>
                        <option value="dung-pha-che">Dùng pha chế</option>
                        <option value="dung-nau-an">Dùng nấu ăn</option>
                        <option value="cho-be">Cho bé</option>
                        <option value="qua-tang">Làm quà tặng</option>
                      </select>
                    </div>
                  </div>

                  <div
                    className="d-flex flex-wrap align-items-center justify-content-between pt-3 mt-3 border-top"
                    style={{ borderColor: '#dce3de', gap: '10px' }}
                  >
                    <div style={{ fontSize: '14px', color: '#2b2b2b' }}>
                      Đang hiển thị <strong>{filteredProducts.length}</strong> / {baseProducts.length} sản phẩm
                    </div>
                    <div className="d-flex flex-wrap align-items-center" style={{ gap: '8px' }}>
                      <label htmlFor="catalog-sort" className="mb-0" style={{ fontSize: '13.5px', color: '#444' }}>
                        Sắp xếp:
                      </label>
                      <select
                        id="catalog-sort"
                        className="form-control form-control-sm"
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as 'default' | 'price-asc' | 'price-desc')}
                        style={{ width: 'auto', minHeight: '36px', borderColor: '#cddbd2' }}
                      >
                        <option value="default">Mặc định</option>
                        <option value="price-asc">Giá thấp đến cao</option>
                        <option value="price-desc">Giá cao đến thấp</option>
                      </select>
                      {hasActiveFilters && (
                        <button
                          type="button"
                          onClick={resetFilters}
                          className="btn btn-sm btn-outline-success"
                          style={{ borderColor: '#158247', color: '#158247', minHeight: '36px', fontWeight: 600 }}
                        >
                          Xóa bộ lọc
                        </button>
                      )}
                    </div>
                  </div>
                </section>
              )}

              {/* Bảng so sánh chuyên biệt trên trang danh mục MẬT HOA DỪA */}
              {grouping?.slug === 'mat-hoa-dua' && (
                <section
                  aria-label="Phân biệt các dòng sản phẩm từ hoa dừa Sokfarm"
                  className="mb-5 p-3 p-md-4 rounded"
                  style={{ background: '#fbf4eb', border: '1px solid #d7e6dc' }}
                >
                  <div className="mb-3">
                    <h2 className="web-color-origin mb-1" style={{ fontSize: '22px' }}>
                      PHÂN BIỆT CÁC DÒNG SẢN PHẨM TỪ HOA DỪA SOKFARM
                    </h2>
                    <p className="mb-0" style={{ fontSize: '14px', color: '#444' }}>
                      So sánh nhanh 3 dòng sản phẩm đặc trưng thu từ hoa dừa hữu cơ Trà Vinh để chọn đúng loại phù hợp nhu cầu sử dụng.
                    </p>
                  </div>

                  <div className="table-responsive d-none d-md-block">
                    <table className="table table-bordered bg-white mb-0 sokfarm-compare-table">
                      <thead>
                        <tr style={{ background: '#158247', color: '#fff' }}>
                          <th style={{ width: '16%' }}>Tiêu chí so sánh</th>
                          {COCONUT_COMPARISON_ITEMS.map((item) => {
                            const prod = products.find((p) => p.slug === item.slug);
                            return (
                              <th key={item.slug} className="text-center" style={{ width: '28%' }}>
                                {prod && (
                                  <img
                                    src={prod.defaultImg}
                                    alt={item.label}
                                    width={96}
                                    height={96}
                                    loading="lazy"
                                    style={{
                                      width: '88px',
                                      height: '88px',
                                      objectFit: 'contain',
                                      background: '#fff',
                                      borderRadius: '8px',
                                      padding: '4px',
                                      marginBottom: '8px',
                                    }}
                                  />
                                )}
                                <div style={{ fontSize: '16px' }}>{item.label}</div>
                              </th>
                            );
                          })}
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="font-weight-bold web-color-origin">Dạng sản phẩm</td>
                          {COCONUT_COMPARISON_ITEMS.map((item) => (
                            <td key={item.slug}>{item.form}</td>
                          ))}
                        </tr>
                        <tr>
                          <td className="font-weight-bold web-color-origin">Mục đích sử dụng</td>
                          {COCONUT_COMPARISON_ITEMS.map((item) => (
                            <td key={item.slug}>{item.usage}</td>
                          ))}
                        </tr>
                        <tr>
                          <td className="font-weight-bold web-color-origin">Cách bảo quản</td>
                          {COCONUT_COMPARISON_ITEMS.map((item) => (
                            <td key={item.slug}>{item.storage}</td>
                          ))}
                        </tr>
                        <tr>
                          <td className="font-weight-bold web-color-origin">Quy cách đóng gói</td>
                          {COCONUT_COMPARISON_ITEMS.map((item) => (
                            <td key={item.slug}>{item.packaging}</td>
                          ))}
                        </tr>
                        <tr>
                          <td className="font-weight-bold web-color-origin">Chi tiết sản phẩm</td>
                          {COCONUT_COMPARISON_ITEMS.map((item) => (
                            <td key={item.slug} className="text-center">
                              <Link
                                to={getProductPath(item.slug)}
                                className="btn btn-sm btn-success text-white px-3 py-2"
                              >
                                Xem chi tiết
                              </Link>
                            </td>
                          ))}
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="d-md-none">
                    <div className="row" style={{ rowGap: '12px' }}>
                      {COCONUT_COMPARISON_ITEMS.map((item) => {
                        const prod = products.find((p) => p.slug === item.slug);
                        return (
                          <div key={item.slug} className="col-12">
                            <div className="bg-white p-3 rounded border" style={{ borderColor: '#d7e6dc' }}>
                              <div className="d-flex align-items-center mb-3" style={{ gap: '12px' }}>
                                {prod && (
                                  <img
                                    src={prod.defaultImg}
                                    alt={item.label}
                                    width={72}
                                    height={72}
                                    loading="lazy"
                                    style={{ width: '72px', height: '72px', objectFit: 'contain' }}
                                  />
                                )}
                                <div>
                                  <h3 className="web-color-origin mb-1" style={{ fontSize: '17px' }}>
                                    {item.label}
                                  </h3>
                                  <Link
                                    to={getProductPath(item.slug)}
                                    className="btn btn-sm btn-success text-white"
                                  >
                                    Xem chi tiết
                                  </Link>
                                </div>
                              </div>
                              <ul className="mb-0" style={{ fontSize: '13.5px', lineHeight: 1.6 }}>
                                <li className="mb-1">
                                  <strong>Dạng sản phẩm:</strong> {item.form}
                                </li>
                                <li className="mb-1">
                                  <strong>Mục đích sử dụng:</strong> {item.usage}
                                </li>
                                <li className="mb-1">
                                  <strong>Cách bảo quản:</strong> {item.storage}
                                </li>
                                <li>
                                  <strong>Quy cách đóng gói:</strong> {item.packaging}
                                </li>
                              </ul>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </section>
              )}

              {/* Product Grid or Friendly Empty State */}
              {filteredProducts.length === 0 ? (
                <div className="p-5 text-center rounded border bg-white my-4" style={{ borderColor: '#d7e6dc' }}>
                  <h2 className="web-color-origin mb-2" style={{ fontSize: '20px' }}>
                    Không tìm thấy sản phẩm phù hợp với bộ lọc
                  </h2>
                  <p className="mb-3" style={{ color: '#555' }}>
                    Thử điều chỉnh từ khóa hoặc xóa bộ lọc hiện tại để xem đầy đủ sản phẩm Sokfarm.
                  </p>
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="btn btn-success text-white px-4 py-2"
                    style={{ backgroundColor: '#158247', borderColor: '#158247' }}
                  >
                    Xem lại tất cả ({baseProducts.length} sản phẩm)
                  </button>
                </div>
              ) : (
                <div className="row">
                  {filteredProducts.map((prod) => (
                    <ProductCard
                      key={prod.slug}
                      product={prod}
                      variant="grid"
                      showSpecsAndActions={true}
                    />
                  ))}
                </div>
              )}

              {/* Secondary Usage Collections Bar */}
              {!grouping?.isB2B && (
                <div className="mt-4 pt-4 border-top">
                  <div className="d-flex flex-wrap align-items-center justify-content-between" style={{ gap: '10px' }}>
                    <span className="font-weight-bold web-color-origin">
                      Gợi ý bộ sưu tập theo nhu cầu sử dụng:
                    </span>
                    <div className="d-flex flex-wrap" style={{ gap: '8px' }}>
                      {SECONDARY_COLLECTIONS.map((col) => (
                        <Link
                          key={col.slug}
                          to={getCategoryPath(col.slug)}
                          className={`category-title-list m-0 ${grouping?.slug === col.slug ? 'active' : ''}`}
                          style={{ textDecoration: 'none' }}
                        >
                          {col.name}
                        </Link>
                      ))}
                      {mode !== 'all' && (
                        <Link
                          to="/san-pham"
                          className="btn btn-outline-success btn-sm align-self-center"
                        >
                          Xem tất cả sản phẩm
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-5">
              <h1 className="web-color-origin mb-3" style={{ fontSize: '28px' }}>
                404 - Không tìm thấy danh mục sản phẩm
              </h1>
              <p className="mb-4">Danh mục bạn đang tìm kiếm không tồn tại hoặc đã được thay đổi.</p>
              <Link to="/san-pham" className="btn btn-success text-white">
                Xem tất cả sản phẩm Sokfarm
              </Link>
            </div>
          )}
        </div>
      </section>
    </>
  );
};
