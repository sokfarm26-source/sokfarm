import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { SeoHead } from '../components/SeoHead';

export const AuthPage: React.FC<{ mode: 'login' | 'register' }> = ({ mode }) => {
  const { loginDemo, notify } = useApp();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rawRedirect = searchParams.get('redirect') || '';
  const safeRedirect =
    rawRedirect.startsWith('/') && !rawRedirect.startsWith('//') ? rawRedirect : '/';
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'register') {
      if (password !== confirmPassword) {
        notify('Mật khẩu xác nhận không khớp!', 'error');
        return;
      }
      loginDemo(email, name);
      navigate(safeRedirect);
      return;
    }
    loginDemo(email);
    navigate(safeRedirect);
  };

  return (
    <>
      <SeoHead
        title={mode === 'login' ? 'Đăng nhập | Sokfarm' : 'Đăng ký tài khoản | Sokfarm'}
        description="Đăng nhập hoặc tạo tài khoản khách hàng Sokfarm."
        canonicalPath={mode === 'login' ? '/user/login' : '/user/register'}
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          {
            name: mode === 'login' ? 'Đăng nhập' : 'Đăng ký',
            path: mode === 'login' ? '/user/login' : '/user/register',
          },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to={mode === 'login' ? '/user/login' : '/user/register'}>
                      {mode === 'login' ? 'Đăng nhập' : 'Đăng ký'}
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="shop login section">
        <div className="container">
          <div className="row">
            <div className="col-lg-6 offset-lg-3 col-12">
              <div className="login-form">
                <h1 style={{ fontSize: '28px' }}>{mode === 'login' ? 'ĐĂNG NHẬP' : 'ĐĂNG KÝ'}</h1>
                <p>
                  {mode === 'login'
                    ? 'Đăng nhập bằng phiên lưu cục bộ trên trình duyệt của bạn'
                    : 'Tạo phiên tài khoản khách hàng Sokfarm trên trình duyệt này'}
                </p>
                <form className="form" onSubmit={handleSubmit}>
                  <div className="row">
                    {mode === 'register' && (
                      <div className="col-12">
                        <div className="form-group">
                          <label htmlFor="authName">
                            Tên của bạn<span>*</span>
                          </label>
                          <input
                            id="authName"
                            type="text"
                            name="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                          />
                        </div>
                      </div>
                    )}
                    <div className="col-12">
                      <div className="form-group">
                        <label htmlFor="authEmail">
                          Email<span>*</span>
                        </label>
                        <input
                          id="authEmail"
                          type="email"
                          name="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                    <div className="col-12">
                      <div className="form-group">
                        <label htmlFor="authPassword">
                          Mật khẩu<span>*</span>
                        </label>
                        <input
                          id="authPassword"
                          type="password"
                          name="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                    {mode === 'register' && (
                      <div className="col-12">
                        <div className="form-group">
                          <label htmlFor="authConfirmPassword">
                            Xác nhận mật khẩu<span>*</span>
                          </label>
                          <input
                            id="authConfirmPassword"
                            type="password"
                            name="password_confirmation"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                          />
                        </div>
                      </div>
                    )}
                    <div className="col-12">
                      <div className="form-group login-btn">
                        <button className="btn btn-success" type="submit">
                          {mode === 'login' ? 'ĐĂNG NHẬP' : 'ĐĂNG KÝ'}
                        </button>
                        {mode === 'login' ? (
                          <Link
                            to={
                              rawRedirect && safeRedirect !== '/'
                                ? `/user/register?redirect=${encodeURIComponent(safeRedirect)}`
                                : '/user/register'
                            }
                            className="btn btn-warning ml-2"
                          >
                            ĐĂNG KÝ
                          </Link>
                        ) : (
                          <Link
                            to={
                              rawRedirect && safeRedirect !== '/'
                                ? `/user/login?redirect=${encodeURIComponent(safeRedirect)}`
                                : '/user/login'
                            }
                            className="btn btn-warning ml-2"
                          >
                            ĐĂNG NHẬP
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
