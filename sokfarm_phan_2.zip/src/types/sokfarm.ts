export interface ProductVariant {
  code: string;
  price: string;
  stock: string;
  images: string[];
  attributes: string;
  selling_price: string;
}

export interface Product {
  slug: string;
  cats: string[];
  defaultImg: string;
  hoverImg: string;
  title: string;
  priceText: string;
  id: string;
  price: number;
  hasCartBtn: boolean;
  gallery: string[];
  dataProducts: ProductVariant[];
  shortHtml: string;
  descHtml: string;
  reviewCount: number;
  relatedSlugs: string[];
}

export interface OrderVariantItem {
  slug: string;
  img: string;
  title: string;
  packaging: string;
  code: string;
  productId: string;
  priceStr: string;
  price: number;
}

export interface OrderGroup {
  groupId: string;
  title: string;
  img: string;
  variants: OrderVariantItem[];
}

export interface BlogPostHeadingOutline {
  h1: string;
  h2: string[];
  h3: string[];
  h4?: string[];
}

export interface BlogPostImageMeta {
  src: string;
  alt: string;
}

export interface BlogPost {
  slug: string;
  customPath?: string;
  sourceUrl?: string;
  sourceCategory?: string;
  img: string;
  imgAlt?: string;
  cat: string;
  catSlug?: string;
  author?: string;
  date: string;
  views: number;
  title: string;
  excerpt: string;
  contentHtml?: string;
  headings?: BlogPostHeadingOutline;
  images?: BlogPostImageMeta[];
  internalLinks?: string[];
}

export interface StoreItem {
  img: string;
  name: string;
  address: string;
  extra: string[];
  href: string;
  phone?: string;
  mapsUrl?: string;
}

export interface StoreDistrict {
  district: string;
  stores: StoreItem[];
}

export type StoreRegionKey = 'hcm_stores' | 'hn_stores' | 'other_stores' | 'online';

export interface StoreRegionMeta {
  key: StoreRegionKey;
  label: string;
}

export type StoreDirectory = Record<StoreRegionKey, StoreDistrict[]>;

export interface PolicyItem {
  slug: string;
  title: string;
  contentHtml: string;
}

export interface CartItem {
  productId: string;
  code: string;
  slug: string;
  title: string;
  packaging?: string;
  price: number;
  img: string;
  quantity: number;
}

export interface WishlistItem {
  productId: string;
  code: string;
  slug: string;
  title: string;
  price: number;
  img: string;
}

export interface DemoUser {
  name: string;
  email: string;
}

export interface ToastMessage {
  id: number;
  type: 'success' | 'warning' | 'error';
  text: string;
}
