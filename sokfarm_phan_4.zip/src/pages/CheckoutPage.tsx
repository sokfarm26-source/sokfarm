import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { formatVndComma } from '../data/siteData';
import { SeoHead } from '../components/SeoHead';

type PaymentMethod = 'cod' | 'bank';

const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  cod: 'Thanh toán khi nhận hàng (COD)',
  bank: 'Chuyển khoản ngân hàng (Sacombank)',
};

export const CheckoutPage: React.FC = () => {
  const { cart, cartSubtotal, clearCart, notify } = useApp();
  const [form, setForm] = useState({
    fullName: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    note: '',
    payment: 'cod' as PaymentMethod,
  });
  const [orderDraft, setOrderDraft] = useState<{
    refCode: string;
    total: number;
    payment: PaymentMethod;
    itemsSnapshot: typeof cart;
    customerSnapshot: typeof form;
  } | null>(null);

  const shippingFee = cartSubtotal >= 1000000 || cartSubtotal === 0 ? 0 : 30000;
  const grandTotal = cartSubtotal + shippingFee;

  const buildOrderSummaryText = (draft: NonNullable<typeof orderDraft>) => {
    const lines = [
      `PHIẾU ĐẶT HÀNG SOKFARM - MÃ THAM CHIẾU: ${draft.refCode}`,
      `Khách hàng: ${draft.customerSnapshot.fullName}`,
      `Số điện thoại: ${draft.customerSnapshot.phone}`,
      draft.customerSnapshot.email ? `Email: ${draft.customerSnapshot.email}` : '',
      `Địa chỉ giao hàng: ${draft.customerSnapshot.address}${
        draft.customerSnapshot.city ? `, ${draft.customerSnapshot.city}` : ''
      }`,
      draft.customerSnapshot.note ? `Ghi chú: ${draft.customerSnapshot.note}` : '',
      `Phương thức thanh toán: ${PAYMENT_LABELS[draft.payment]}`,
      '',
      'Chi tiết sản phẩm:',
      ...draft.itemsSnapshot.map(
        (item) =>
          `- ${item.title}${item.packaging ? ` (${item.packaging})` : ''} x ${item.quantity}: ${formatVndComma(
            item.price * item.quantity
          )}`
      ),
      `Phí vận chuyển dự kiến: ${shippingFee === 0 ? 'Miễn phí' : formatVndComma(shippingFee)}`,
      `Tổng cộng: ${formatVndComma(draft.total)}`,
    ].filter(Boolean);
    return lines.join('\n');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName.trim() || !form.phone.trim() || !form.address.trim()) {
      notify('Vui lòng điền đầy đủ họ tên, số điện thoại và địa chỉ giao hàng', 'warning');
      return;
    }
    const refCode = 'SF-' + Date.now().toString().slice(-6);
    setOrderDraft({
      refCode,
      total: grandTotal,
      payment: form.payment,
      itemsSnapshot: [...cart],
      customerSnapshot: { ...form },
    });
    notify('Đã tạo phiếu đặt hàng. Vui lòng chọn kênh gửi đơn tới Sokfarm.', 'success');
  };

  const handleCopyOrder = async () => {
    if (!orderDraft) return;
    try {
      await navigator.clipboard.writeText(buildOrderSummaryText(orderDraft));
      notify('Đã sao chép chi tiết đơn hàng vào bộ nhớ tạm.', 'success');
    } catch {
      notify('Không thể tự động sao chép, vui lòng bôi đen nội dung hoặc gửi qua Email.', 'warning');
    }
  };

  return (
    <>
      <SeoHead
        title="Thanh toán đơn hàng | Sokfarm"
        description="Hoàn tất thông tin giao hàng và chọn phương thức thanh toán đơn hàng Sokfarm."
        canonicalPath="/checkout"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Giỏ hàng', path: '/dat-hang' },
          { name: 'Thanh toán', path: '/checkout' },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/dat-hang">
                      Giỏ hàng<i className="ti-arrow-right" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <span>Thanh toán</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="shop checkout section py-5">
        <div className="container">
          {orderDraft ? (
            <div className="p-4 p-md-5 border rounded bg-white">
              <div className="text-center mb-4">
                <i className="fa fa-file-text-o" aria-hidden="true" style={{ fontSize: '42px', color: '#158247' }}></i>
                <h1 className="web-color-origin mt-3 mb-2" style={{ fontSize: '26px' }}>
                  Phiếu đặt hàng dự kiến ({orderDraft.refCode})
                </h1>
                <p className="mb-0" style={{ color: '#4a554e' }}>
                  Website hiện chưa kết nối cổng gửi đơn tự động về máy chủ. Vui lòng gửi phiếu đơn hàng này tới Sokfarm qua Email, Zalo hoặc gọi Hotline để nhân viên xác nhận giao hàng.
                </p>
              </div>

              <div className="row">
                <div className="col-lg-6 mb-3">
                  <div className="p-3 rounded border h-100" style={{ backgroundColor: '#fbf4eb' }}>
                    <h2 style={{ fontSize: '17px', color: '#158247' }} className="mb-2">
                      Thông tin người nhận
                    </h2>
                    <p className="mb-1"><strong>Họ và tên:</strong> {orderDraft.customerSnapshot.fullName}</p>
                    <p className="mb-1"><strong>Số điện thoại:</strong> {orderDraft.customerSnapshot.phone}</p>
                    {orderDraft.customerSnapshot.email && (
                      <p className="mb-1"><strong>Email:</strong> {orderDraft.customerSnapshot.email}</p>
                    )}
                    <p className="mb-1">
                      <strong>Địa chỉ:</strong> {orderDraft.customerSnapshot.address}
                      {orderDraft.customerSnapshot.city ? `, ${orderDraft.customerSnapshot.city}` : ''}
                    </p>
                    <p className="mb-0">
                      <strong>Thanh toán:</strong> {PAYMENT_LABELS[orderDraft.payment]}
                    </p>
                    {orderDraft.payment === 'bank' && (
                      <div className="p-2 mt-3 rounded border bg-white" style={{ fontSize: '13px', lineHeight: 1.55 }}>
                        <div><strong>Chủ tài khoản:</strong> CÔNG TY TNHH TRÀ VINH FARM</div>
                        <div><strong>Ngân hàng:</strong> Sacombank - PGD Tiểu Cần</div>
                        <div><strong>Số tài khoản:</strong> 0701 2016 8248</div>
                        <div><strong>Nội dung chuyển khoản:</strong> {orderDraft.refCode} - {orderDraft.customerSnapshot.phone}</div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="col-lg-6 mb-3">
                  <div className="p-3 rounded border h-100" style={{ backgroundColor: '#f8faf8' }}>
                    <h2 style={{ fontSize: '17px', color: '#158247' }} className="mb-2">
                      Chi tiết đơn hàng
                    </h2>
                    <ul className="list-unstyled mb-2">
                      {orderDraft.itemsSnapshot.map((item) => (
                        <li key={`${item.productId}-${item.code}`} className="d-flex justify-content-between py-1 border-bottom">
                          <span>
                            {item.title} {item.packaging ? `(${item.packaging})` : ''} &times; {item.quantity}
                          </span>
                          <strong style={{ fontVariantNumeric: 'tabular-nums' }}>
                            {formatVndComma(item.price * item.quantity)}
                          </strong>
                        </li>
                      ))}
                    </ul>
                    <div className="d-flex justify-content-between pt-2">
                      <strong>Tổng thanh toán dự kiến:</strong>
                      <strong style={{ color: '#158247', fontSize: '18px', fontVariantNumeric: 'tabular-nums' }}>
                        {formatVndComma(orderDraft.total)}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              <div className="d-flex flex-wrap justify-content-center mt-4" style={{ gap: '10px' }}>
                <a
                  href={`mailto:hello@sokfarm.com?subject=${encodeURIComponent(
                    `[Đặt hàng Sokfarm] ${orderDraft.refCode} - ${orderDraft.customerSnapshot.fullName}`
                  )}&body=${encodeURIComponent(buildOrderSummaryText(orderDraft))}`}
                  className="btn btn-success text-white px-4 py-2"
                  style={{ backgroundColor: '#158247', borderColor: '#158247' }}
                >
                  <i className="fa fa-envelope mr-2" aria-hidden="true"></i>
                  Gửi đơn qua Email Sokfarm
                </a>
                <button
                  type="button"
                  onClick={handleCopyOrder}
                  className="btn btn-outline-success px-4 py-2"
                  style={{ borderColor: '#158247', color: '#158247' }}
                >
                  <i className="fa fa-copy mr-2" aria-hidden="true"></i>
                  Sao chép đơn hàng
                </button>
                <a
                  href="tel:0966243066"
                  className="btn btn-outline-dark px-4 py-2"
                >
                  <i className="fa fa-phone mr-2" aria-hidden="true"></i>
                  Hotline: 0966 243 066
                </a>
                <a
                  href="https://zalo.me/sokfarm"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-outline-primary px-4 py-2"
                >
                  Nhắn qua Zalo OA Sokfarm
                </a>
              </div>

              <div className="d-flex flex-wrap justify-content-center mt-4 pt-3 border-top" style={{ gap: '12px' }}>
                <button
                  type="button"
                  onClick={() => setOrderDraft(null)}
                  className="btn btn-light border px-3 py-2"
                >
                  Quay lại chỉnh sửa đơn
                </button>
                <button
                  type="button"
                  onClick={() => {
                    clearCart();
                    setOrderDraft(null);
                    notify('Đã làm mới giỏ hàng sau khi bạn ghi nhận đơn.', 'success');
                  }}
                  className="btn btn-link text-muted px-3 py-2"
                >
                  Làm trống giỏ hàng
                </button>
              </div>
            </div>
          ) : cart.length === 0 ? (
            <div className="p-5 border rounded bg-white text-center">
              <h1 style={{ fontSize: '24px' }}>Giỏ hàng của bạn đang trống</h1>
              <p className="mt-2">Vui lòng chọn sản phẩm trước khi tiến hành đặt hàng.</p>
              <Link to="/san-pham" className="btn btn-success mt-3 text-white px-4 py-2" style={{ backgroundColor: '#158247', borderColor: '#158247' }}>
                Xem sản phẩm Sokfarm
              </Link>
            </div>
          ) : (
            <form className="form" onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-lg-8 col-12">
                  <div className="checkout-form">
                    <h1 style={{ fontSize: '26px', color: '#158247' }} className="mb-2">
                      Thông tin giao hàng
                    </h1>
                    <p className="mb-4">
                      Vui lòng điền thông tin nhận hàng chính xác để Sokfarm hỗ trợ giao hàng nhanh chóng.
                    </p>
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutFullName">
                            Họ và Tên<span>*</span>
                          </label>
                          <input
                            id="checkoutFullName"
                            type="text"
                            placeholder="Nguyễn Văn A"
                            value={form.fullName}
                            onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6 col-md-6 col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutPhone">
                            Số điện thoại<span>*</span>
                          </label>
                          <input
                            id="checkoutPhone"
                            type="tel"
                            placeholder="09xx xxx xxx"
                            value={form.phone}
                            onChange={(e) => setForm({ ...form, phone: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-lg-6 col-md-6 col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutCity">Tỉnh / Thành phố</label>
                          <input
                            id="checkoutCity"
                            type="text"
                            placeholder="VD: TP. Hồ Chí Minh, Hà Nội..."
                            value={form.city}
                            onChange={(e) => setForm({ ...form, city: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="col-lg-6 col-md-6 col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutEmail">Email (Không bắt buộc)</label>
                          <input
                            id="checkoutEmail"
                            type="email"
                            placeholder="email@domain.com"
                            value={form.email}
                            onChange={(e) => setForm({ ...form, email: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutAddress">
                            Địa chỉ chi tiết<span>*</span>
                          </label>
                          <input
                            id="checkoutAddress"
                            type="text"
                            placeholder="Số nhà, tên đường, phường/xã..."
                            value={form.address}
                            onChange={(e) => setForm({ ...form, address: e.target.value })}
                            required
                          />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label htmlFor="checkoutNote">Ghi chú đơn hàng</label>
                          <input
                            id="checkoutNote"
                            type="text"
                            placeholder="Khung giờ nhận hàng, xuất hóa đơn VAT..."
                            value={form.note}
                            onChange={(e) => setForm({ ...form, note: e.target.value })}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-lg-4 col-12">
                  <div className="order-details">
                    <div className="single-widget">
                      <h2>TÓM TẮT ĐƠN HÀNG</h2>
                      <div className="content">
                        <ul>
                          {cart.map((item) => (
                            <li key={`${item.productId}-${item.code}`}>
                              {item.title} x {item.quantity}
                              <span style={{ fontVariantNumeric: 'tabular-nums' }}>
                                {formatVndComma(item.price * item.quantity)}
                              </span>
                            </li>
                          ))}
                          <li>
                            Tạm tính
                            <span style={{ fontVariantNumeric: 'tabular-nums' }}>
                              {formatVndComma(cartSubtotal)}
                            </span>
                          </li>
                          <li>
                            Phí vận chuyển (Miễn phí đơn &ge; 1.000.000đ)
                            <span style={{ fontVariantNumeric: 'tabular-nums' }}>
                              {shippingFee === 0 ? 'Miễn phí' : formatVndComma(shippingFee)}
                            </span>
                          </li>
                          <li className="last">
                            Tổng cộng
                            <span style={{ fontVariantNumeric: 'tabular-nums' }}>
                              {formatVndComma(grandTotal)}
                            </span>
                          </li>
                        </ul>
                      </div>
                    </div>

                    <div className="single-widget">
                      <h2>Phương thức thanh toán</h2>
                      <div className="content px-4 py-2">
                        <div className="mb-2">
                          <label className="d-flex align-items-center" style={{ gap: '8px', cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="payment"
                              checked={form.payment === 'cod'}
                              onChange={() => setForm({ ...form, payment: 'cod' })}
                            />
                            <span>Thanh toán khi nhận hàng (COD)</span>
                          </label>
                        </div>
                        <div>
                          <label className="d-flex align-items-center" style={{ gap: '8px', cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="payment"
                              checked={form.payment === 'bank'}
                              onChange={() => setForm({ ...form, payment: 'bank' })}
                            />
                            <span>Chuyển khoản ngân hàng (Sacombank)</span>
                          </label>
                          {form.payment === 'bank' && (
                            <div
                              className="p-2 mt-2 rounded border"
                              style={{ fontSize: '13px', backgroundColor: '#f7fbf8', lineHeight: 1.5 }}
                            >
                              <div><b>Đơn vị thụ hưởng:</b> CÔNG TY TNHH TRÀ VINH FARM</div>
                              <div><b>Địa chỉ:</b> Ấp Cây Hẹ, Xã Tiểu Cần, Tỉnh Vĩnh Long, Việt Nam</div>
                              <div><b>Ngân hàng:</b> Sacombank - Phòng Giao Dịch Tiểu Cần</div>
                              <div><b>Số tài khoản:</b> 0701 2016 8248</div>
                              <div><b>Nội dung CK:</b> Tên + Số điện thoại</div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="single-widget get-button">
                      <div className="content">
                        <div className="button">
                          <button type="submit" className="btn">
                            TẠO PHIẾU ĐẶT HÀNG
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </section>
    </>
  );
};
