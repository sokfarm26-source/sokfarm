import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { SeoHead } from '../components/SeoHead';

export const ContactPage: React.FC = () => {
  const { notify } = useApp();
  const [searchParams] = useSearchParams();
  const [form, setForm] = useState({
    name: '',
    subject: '',
    email: '',
    phone: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const subjParam = searchParams.get('subject');
    if (subjParam === 'Dang-ky-dai-ly') {
      setForm((prev) => ({
        ...prev,
        subject: prev.subject || 'Đăng ký làm đại lý / nhà phân phối Sokfarm',
      }));
    }
  }, [searchParams]);

  const buildMessageSummary = () =>
    [
      `Họ và tên: ${form.name}`,
      `Tiêu đề: ${form.subject}`,
      `Email: ${form.email}`,
      `Số điện thoại: ${form.phone}`,
      '',
      'Nội dung liên hệ:',
      form.message,
    ].join('\n');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.phone.trim() || !form.message.trim()) {
      notify('Vui lòng điền đầy đủ thông tin bắt buộc', 'warning');
      return;
    }
    setSubmitted(true);
    notify('Nội dung liên hệ đã sẵn sàng gửi tới Sokfarm qua Email hoặc Zalo.', 'success');
  };

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(buildMessageSummary());
      notify('Đã sao chép nội dung liên hệ.', 'success');
    } catch {
      notify('Không thể tự động sao chép, vui lòng sử dụng nút gửi Email.', 'warning');
    }
  };

  return (
    <>
      <SeoHead
        title="Liên hệ | Sokfarm"
        description="Liên hệ Công ty TNHH Trà Vinh Farm (Sokfarm) - Ấp Cây Hẹ, Xã Tiểu Cần, Tỉnh Vĩnh Long. Hotline: 0974 018 946 - 0966 243 066."
        canonicalPath="/contact"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Liên hệ', path: '/contact' },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <span>Liên hệ</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section id="contact-us" className="contact-us section p-3 p-md-5" style={{ padding: '50px 0' }}>
        <div className="container">
          <div className="contact-head">
            <div className="row">
              <div className="col-lg-6 text-center">
                <div className="title-top text-left">
                  <h1 className="mb-3" style={{ color: '#158247', fontSize: '28px' }}>
                    Liên hệ với Sokfarm
                  </h1>
                  <p className="mb-3" style={{ color: '#333' }}>
                    Nếu quý khách có nhu cầu tư vấn sản phẩm, hợp tác đại lý hoặc hỗ trợ đơn hàng, vui lòng liên hệ trực tiếp với Công ty TNHH Trà Vinh Farm theo thông tin dưới đây.
                  </p>
                  <div className="row mt-3">
                    <div className="col-lg-6 col-sm-12">
                      <div className="media my-2">
                        <div className="media-body">
                          <h2 className="mt-0" style={{ color: '#158247', fontSize: '15px' }}>
                            CÔNG TY TNHH TRÀ VINH FARM
                          </h2>
                          <p>Địa chỉ: Ấp Cây Hẹ, Xã Tiểu Cần, Tỉnh Vĩnh Long, Việt Nam</p>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-6 col-sm-12">
                      <div className="media my-2">
                        <div className="media-body">
                          <h2 className="mt-0" style={{ color: '#158247', fontSize: '15px' }}>
                            Thông tin doanh nghiệp
                          </h2>
                          <p>Mã số thuế: 2100647732</p>
                          <p>Hotline: 0974 018 946 – 0974 038 946</p>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-5 col-sm-12">
                      <div className="media my-2">
                        <div className="media-body">
                          <h2 className="mt-0" style={{ color: '#158247', fontSize: '15px' }}>
                            Kênh hỗ trợ trực tiếp
                          </h2>
                          <p>
                            Số điện thoại:{' '}
                            <a href="tel:0966243066" style={{ color: '#158247', fontWeight: 600 }}>
                              0966 243 066
                            </a>
                          </p>
                          <p>
                            Email:{' '}
                            <a href="mailto:hello@sokfarm.com" style={{ color: '#158247', fontWeight: 600 }}>
                              hello@sokfarm.com
                            </a>
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-lg-7 col-sm-12 my-auto">
                      <a
                        href="https://drive.google.com/file/d/1m63pJPStYhNKvi0gLNq9DhvRiY8PzIv5/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="d-inline-block mb-2 mr-2"
                        style={{
                          padding: '10px 14px',
                          border: '1px solid #158247',
                          borderRadius: '10px',
                          color: '#158247',
                          fontWeight: 600,
                        }}
                      >
                        Hồ sơ công ty <i className="fa fa-download" aria-hidden="true"></i>
                      </a>
                      <a
                        href="https://drive.google.com/file/d/1FzH5QT5cV6g6VUWxStTfiqTrHZZf3I4A/view?usp=sharing"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="d-inline-block mb-2"
                        style={{
                          padding: '10px 14px',
                          border: '1px solid #158247',
                          borderRadius: '10px',
                          color: '#158247',
                          fontWeight: 600,
                        }}
                      >
                        Company Profile <i className="fa fa-download" aria-hidden="true"></i>
                      </a>
                    </div>
                  </div>
                </div>
                <img
                  src="/images/opt/sub/contact1.webp"
                  className="w-50 w-md-100 mt-3"
                  alt="Liên hệ Sokfarm"
                  width={360}
                  height={240}
                  loading="lazy"
                  decoding="async"
                />
              </div>

              <div className="col-lg-6">
                <div className="form-main">
                  <div className="title">
                    <h2 style={{ color: '#158247', fontSize: '22px' }}>Gửi thông tin liên hệ</h2>
                  </div>

                  {submitted ? (
                    <div className="p-4 mt-3 rounded border" style={{ backgroundColor: '#f7fbf8', borderColor: '#cce2d2' }}>
                      <h3 style={{ fontSize: '18px', color: '#158247' }} className="mb-2">
                        Nội dung liên hệ đã sẵn sàng gửi tới Sokfarm
                      </h3>
                      <p className="mb-3" style={{ fontSize: '14px', color: '#333' }}>
                        Biểu mẫu trực tuyến chưa kết nối máy chủ gửi tự động. Vui lòng nhấn gửi Email trực tiếp hoặc sao chép thông tin bên dưới gửi về Sokfarm:
                      </p>
                      <div className="p-3 bg-white border rounded mb-3" style={{ fontSize: '13.5px', lineHeight: 1.6 }}>
                        <div><strong>Họ tên:</strong> {form.name}</div>
                        <div><strong>Chủ đề:</strong> {form.subject}</div>
                        <div><strong>Email:</strong> {form.email} | <strong>SĐT:</strong> {form.phone}</div>
                        <div className="mt-1"><strong>Lời nhắn:</strong> {form.message}</div>
                      </div>
                      <div className="d-flex flex-wrap" style={{ gap: '8px' }}>
                        <a
                          href={`mailto:hello@sokfarm.com?subject=${encodeURIComponent(
                            `[Liên hệ Sokfarm] ${form.subject}`
                          )}&body=${encodeURIComponent(buildMessageSummary())}`}
                          className="btn btn-success text-white"
                          style={{ backgroundColor: '#158247', borderColor: '#158247' }}
                        >
                          Gửi qua Email (hello@sokfarm.com)
                        </a>
                        <button
                          type="button"
                          onClick={handleCopyMessage}
                          className="btn btn-outline-success"
                          style={{ borderColor: '#158247', color: '#158247' }}
                        >
                          Sao chép nội dung
                        </button>
                        <a
                          href="https://zalo.me/sokfarm"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="btn btn-outline-primary"
                        >
                          Zalo OA Sokfarm
                        </a>
                        <button
                          type="button"
                          onClick={() => setSubmitted(false)}
                          className="btn btn-light border"
                        >
                          Chỉnh sửa lại
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form className="form-contact form contact_form" onSubmit={handleSubmit} id="contactForm">
                      <div className="row">
                        <div className="col-lg-6 col-12">
                          <div className="form-group">
                            <label htmlFor="contactName">
                              Tên của bạn<span>*</span>
                            </label>
                            <input
                              name="name"
                              id="contactName"
                              type="text"
                              placeholder="Họ & Tên"
                              value={form.name}
                              onChange={(e) => setForm({ ...form, name: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div className="col-lg-6 col-12">
                          <div className="form-group">
                            <label htmlFor="contactSubject">
                              Tiêu đề<span>*</span>
                            </label>
                            <input
                              name="subject"
                              type="text"
                              id="contactSubject"
                              placeholder="Tiêu đề liên hệ"
                              value={form.subject}
                              onChange={(e) => setForm({ ...form, subject: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div className="col-lg-6 col-12">
                          <div className="form-group">
                            <label htmlFor="contactEmail">
                              Email<span>*</span>
                            </label>
                            <input
                              name="email"
                              type="email"
                              id="contactEmail"
                              placeholder="Email của bạn"
                              value={form.email}
                              onChange={(e) => setForm({ ...form, email: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div className="col-lg-6 col-12">
                          <div className="form-group">
                            <label htmlFor="contactPhone">
                              Số điện thoại<span>*</span>
                            </label>
                            <input
                              id="contactPhone"
                              name="phone"
                              type="tel"
                              placeholder="Số điện thoại"
                              value={form.phone}
                              onChange={(e) => setForm({ ...form, phone: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group message">
                            <label htmlFor="contactMessage">
                              Lời nhắn<span>*</span>
                            </label>
                            <textarea
                              name="message"
                              id="contactMessage"
                              cols={30}
                              rows={6}
                              placeholder="Nhập nội dung lời nhắn..."
                              value={form.message}
                              onChange={(e) => setForm({ ...form, message: e.target.value })}
                              required
                            ></textarea>
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group button">
                            <button type="submit" className="btn">
                              Chuẩn bị gửi liên hệ
                            </button>
                          </div>
                        </div>
                      </div>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
