import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useParams, Link } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CookieConsentAndWidgets } from './components/CookieConsent';
import { SeoHead } from './components/SeoHead';
import { HomePage } from './pages/HomePage';
import { resolveCanonicalProductSlug } from './data/siteData';

const SubpageWrapper = lazy(() => import('./pages/SubpageWrapper').then((m) => ({ default: m.SubpageWrapper })));
const ProductCategoryPage = lazy(() => import('./pages/ProductCategoryPage').then((m) => ({ default: m.ProductCategoryPage })));
const ProductDetailPage = lazy(() => import('./pages/ProductDetailPage').then((m) => ({ default: m.ProductDetailPage })));
const SearchPage = lazy(() => import('./pages/SearchPage').then((m) => ({ default: m.SearchPage })));
const OrderCartPage = lazy(() => import('./pages/OrderCartPage').then((m) => ({ default: m.OrderCartPage })));
const CheckoutPage = lazy(() => import('./pages/CheckoutPage').then((m) => ({ default: m.CheckoutPage })));
const BlogListPage = lazy(() => import('./pages/BlogListPage').then((m) => ({ default: m.BlogListPage })));
const BlogDetailPage = lazy(() => import('./pages/BlogDetailPage').then((m) => ({ default: m.BlogDetailPage })));
const ContactPage = lazy(() => import('./pages/ContactPage').then((m) => ({ default: m.ContactPage })));
const StoreListPage = lazy(() => import('./pages/StoreListPage').then((m) => ({ default: m.StoreListPage })));
const AuthPage = lazy(() => import('./pages/AuthPage').then((m) => ({ default: m.AuthPage })));
const WishlistPage = lazy(() => import('./pages/WishlistPage').then((m) => ({ default: m.WishlistPage })));
const PolicyPage = lazy(() => import('./pages/PolicyPage').then((m) => ({ default: m.PolicyPage })));
const DaMeRecipePage = lazy(() => import('./pages/DaMeRecipePage').then((m) => ({ default: m.DaMeRecipePage })));
const ViNgotThuanChayPage = lazy(() => import('./pages/ViNgotThuanChayPage').then((m) => ({ default: m.ViNgotThuanChayPage })));

function LegacyProductRedirect() {
  const { slug } = useParams<{ slug: string }>();
  const target = (slug && resolveCanonicalProductSlug(slug)) || slug || '';
  return <Navigate to={target ? `/san-pham/${target}` : '/san-pham'} replace />;
}

function NotFoundPage() {
  return (
    <>
      <SeoHead
        title="404 - Không tìm thấy trang | Sokfarm"
        description="Trang bạn đang truy cập không tồn tại hoặc đã được thay đổi."
        canonicalPath="/404"
      />
      <section className="section py-5">
        <div className="container text-center py-4">
          <h1 className="web-color-origin mb-3" style={{ fontSize: '36px' }}>
            404 - Không tìm thấy trang
          </h1>
          <p className="mb-4">Đường dẫn bạn truy cập không tồn tại hoặc đã được chuyển sang địa chỉ mới.</p>
          <div className="d-flex justify-content-center flex-wrap" style={{ gap: '12px' }}>
            <Link to="/" className="btn btn-success text-white">
              Về trang chủ
            </Link>
            <Link to="/san-pham" className="btn btn-outline-success">
              Xem tất cả sản phẩm
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Header />
        <main>
          <Suspense fallback={<div style={{ minHeight: '60vh' }} />}>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/about-us" element={<SubpageWrapper pageKey="about" />} />
              <Route path="/phat-trien-ben-vung" element={<SubpageWrapper pageKey="sustainable" />} />

              {/* Sản phẩm & Danh mục B2C chuẩn hóa */}
              <Route path="/san-pham" element={<ProductCategoryPage mode="all" />} />
              <Route path="/san-pham/ban-chay-nhat" element={<ProductCategoryPage mode="bestseller" />} />
              <Route path="/danh-muc/:slug" element={<ProductCategoryPage mode="category" />} />
              <Route path="/bo-suu-tap/:slug" element={<ProductCategoryPage mode="collection" />} />
              <Route path="/san-pham/:slug" element={<ProductDetailPage />} />

              {/* Chuyển hướng URL cũ sang URL SEO mới */}
              <Route path="/product-list" element={<Navigate to="/san-pham" replace />} />
              <Route path="/product-cat/:slug" element={<ProductCategoryPage mode="legacy" />} />
              <Route path="/product-detail/:slug" element={<LegacyProductRedirect />} />
              <Route path="/product/search" element={<SearchPage />} />

              {/* Đối tác, Nguyên liệu & HORECA */}
              <Route path="/nguyen-lieu" element={<SubpageWrapper pageKey="nguyen_lieu" />} />
              <Route path="/giai-phap-horeca" element={<ProductCategoryPage mode="horeca" />} />
              <Route path="/export-markets" element={<SubpageWrapper pageKey="export_markets" />} />
              <Route path="/doi-tac/tin-xuat-khau" element={<BlogListPage mode="export-news" />} />

              {/* Góc Khám Phá (đổi từ Tin tức) + giữ URL bài viết /tin-tuc/:slug */}
              <Route path="/goc-kham-pha" element={<BlogListPage mode="explore" />} />
              <Route path="/goc-kham-pha/:slug" element={<BlogListPage mode="explore" />} />
              <Route path="/tin-tuc" element={<Navigate to="/goc-kham-pha" replace />} />
              <Route path="/blog-cat/:slug" element={<BlogListPage mode="legacy" />} />
              <Route
                path="/tin-tuc/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac"
                element={<Navigate to="/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac" replace />}
              />
              <Route path="/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac" element={<DaMeRecipePage />} />
              <Route
                path="/tin-tuc/vi-ngot-cho-nguoi-an-thuan-chay"
                element={<Navigate to="/vi-ngot-cho-nguoi-an-thuan-chay" replace />}
              />
              <Route path="/vi-ngot-cho-nguoi-an-thuan-chay" element={<ViNgotThuanChayPage />} />
              <Route path="/tin-tuc/:slug" element={<BlogDetailPage />} />

              {/* Liên hệ, Cửa hàng & Tuyển dụng */}
              <Route path="/tuyen-dung" element={<BlogListPage mode="recruitment" />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/he-thong-cua-hang" element={<StoreListPage />} />
              <Route path="/list-store" element={<Navigate to="/he-thong-cua-hang" replace />} />

              {/* Giỏ hàng, Đặt hàng & Tài khoản */}
              <Route path="/dat-hang" element={<OrderCartPage />} />
              <Route path="/cart" element={<OrderCartPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/user/login" element={<AuthPage mode="login" />} />
              <Route path="/user/register" element={<AuthPage mode="register" />} />
              <Route path="/wishlist" element={<WishlistPage />} />
              <Route path="/policy-and-information/:slug" element={<PolicyPage />} />
              <Route path="/user-data-request" element={<SubpageWrapper pageKey="dsar" />} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
        <CookieConsentAndWidgets />
      </BrowserRouter>
    </AppProvider>
  );
}
