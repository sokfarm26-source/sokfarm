import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import type { ArticleComment } from '../hooks/useArticleComments';

interface ArticleCommentsSectionProps {
  comments: ArticleComment[];
  onAddComment: (author: string, text: string) => boolean;
}

export const ArticleCommentsSection: React.FC<ArticleCommentsSectionProps> = ({
  comments,
  onAddComment,
}) => {
  const { user, notify } = useApp();
  const location = useLocation();
  const [commentText, setCommentText] = useState('');

  const redirectTarget = encodeURIComponent(`${location.pathname}#comments`);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!commentText.trim()) return;
    const saved = onAddComment(user.name || user.email, commentText);
    if (saved) {
      setCommentText('');
      notify('Đã gửi bình luận thành công!', 'success');
    }
  };

  return (
    <div id="comments" className="sokfarm-article-comments-wrap mt-5">
      {/* A. Đăng nhập hoặc đăng ký để bình luận */}
      <div className="reply">
        <div className="reply-head">
          {!user ? (
            <div
              className="p-4 rounded"
              style={{
                backgroundColor: '#f8faf8',
                border: '1px solid #d7e6dc',
              }}
            >
              <p className="mb-0" style={{ fontSize: '15px', color: '#2b2b2b', lineHeight: 1.65 }}>
                <i className="fa fa-comment-o mr-2" style={{ color: '#158247' }} aria-hidden="true"></i>
                Bạn cần{' '}
                <Link
                  to={`/user/login?redirect=${redirectTarget}`}
                  style={{ color: '#158247', fontWeight: 700, textDecoration: 'underline' }}
                >
                  Đăng nhập
                </Link>{' '}
                hoặc{' '}
                <Link
                  to={`/user/register?redirect=${redirectTarget}`}
                  style={{ color: '#158247', fontWeight: 700, textDecoration: 'underline' }}
                >
                  Đăng ký
                </Link>{' '}
                để bình luận.
              </p>
            </div>
          ) : (
            <form className="form" onSubmit={handleSubmit}>
              <h2 className="reply-title sokfarm-section-accent-title mb-3">Để Lại Bình Luận</h2>
              <p className="mb-3" style={{ fontSize: '13.5px', color: '#555' }}>
                Đang bình luận với tài khoản:{' '}
                <strong style={{ color: '#158247' }}>{user.name || user.email}</strong>
              </p>
              <div className="row">
                <div className="col-12">
                  <div className="form-group">
                    <label htmlFor="articleCommentText">Nội dung bình luận</label>
                    <textarea
                      id="articleCommentText"
                      rows={4}
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Chia sẻ cảm nhận hoặc thắc mắc của bạn về bài viết..."
                      required
                    ></textarea>
                  </div>
                </div>
                <div className="col-12">
                  <div className="form-group button">
                    <button
                      type="submit"
                      className="btn text-white"
                      style={{
                        backgroundColor: '#158247',
                        borderColor: '#158247',
                        borderRadius: '6px',
                        padding: '0 24px',
                        fontWeight: 600,
                      }}
                    >
                      Gửi bình luận
                    </button>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* B. Danh Sách Bình Luận */}
      <div className="comments mt-4">
        <h2 className="comment-title sokfarm-section-accent-title">
          Danh Sách Bình Luận ({comments.length})
        </h2>

        {comments.length === 0 ? (
          <div
            className="p-3 rounded"
            style={{
              backgroundColor: '#fafafa',
              border: '1px dashed #dce3de',
              color: '#555',
              fontSize: '14.5px',
            }}
          >
            Chưa có bình luận nào cho bài viết này.
          </div>
        ) : (
          <div className="d-flex flex-column" style={{ gap: '14px' }}>
            {comments.map((c) => (
              <div
                key={c.id}
                className="single-comment p-3 rounded"
                style={{
                  paddingLeft: '16px',
                  marginBottom: 0,
                  border: '1px solid #e5ece7',
                  backgroundColor: '#fff',
                }}
              >
                <div className="content">
                  <h4 style={{ marginBottom: '8px', fontSize: '15.5px', fontWeight: 700, color: '#158247' }}>
                    {c.author}
                    <span style={{ fontSize: '12.5px', color: '#666', fontWeight: 400, marginTop: '3px' }}>
                      {c.createdAt}
                    </span>
                  </h4>
                  <p style={{ marginBottom: 0, color: '#333', fontSize: '14.5px', lineHeight: 1.65 }}>
                    {c.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
