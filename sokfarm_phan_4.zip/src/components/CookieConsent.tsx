import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export const CookieConsentAndWidgets: React.FC = () => {
  const {
    toasts,
    cmpBannerVisible,
    cmpModalOpen,
    openCmpModal,
    closeCmpModal,
    saveCmpConsent,
  } = useApp();

  const [analytics, setAnalytics] = useState(true);
  const [personalization, setPersonalization] = useState(true);
  const [marketing, setMarketing] = useState(true);
  const [showScrollUp, setShowScrollUp] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setShowScrollUp(window.scrollY > 300);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <>
      {/* Toast Notifications */}
      <div className="sokfarm-toast-container">
        {toasts.map((t) => (
          <div key={t.id} className={`sokfarm-toast ${t.type}`}>
            <i
              className={`fa ${
                t.type === 'success'
                  ? 'fa-check-circle'
                  : t.type === 'warning'
                  ? 'fa-exclamation-triangle'
                  : 'fa-times-circle'
              }`}
            ></i>
            <span>{t.text}</span>
          </div>
        ))}
      </div>

      {/* ScrollUp Button */}
      {showScrollUp && (
        <button
          id="scrollUp"
          type="button"
          aria-label="Scroll to top"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          <span>
            <i className="fa fa-angle-up"></i>
          </span>
        </button>
      )}

      {/* Sokfarm Cookie & Consent Management UI Component */}
      <div id="sokfarm-cmp-container">
        <div
          id="sokfarm-cmp-banner"
          className={`sokfarm-cmp-banner ${cmpBannerVisible ? 'sokfarm-cmp-visible' : ''}`}
          role="dialog"
          aria-modal="false"
          aria-label="Cài đặt Cookie & Quyền riêng tư"
          aria-hidden={!cmpBannerVisible}
        >
          <div className="sokfarm-cmp-banner-inner">
            <div className="sokfarm-cmp-banner-content">
              <div className="sokfarm-cmp-banner-header">
                <div className="sokfarm-cmp-banner-icon">
                  <i className="fa fa-shield"></i>
                </div>
                <h3 className="sokfarm-cmp-banner-title">Cài đặt Cookie &amp; Quyền riêng tư</h3>
              </div>
              <p className="sokfarm-cmp-banner-text">
                Chúng tôi sử dụng cookie cần thiết để đảm bảo website hoạt động ổn định và an toàn. Với sự đồng ý của bạn, chúng tôi sử dụng thêm cookie để phân tích lưu lượng và nâng cao trải nghiệm hỗ trợ khách hàng. Bạn có toàn quyền quản lý hoặc thay đổi lựa chọn bất cứ lúc nào.
              </p>
              <div className="sokfarm-cmp-banner-links">
                <Link
                  to="/policy-and-information/chinh-sach-bao-ve-thong-tin-ca-nhan-cua-nguoi-tieu-dung"
                  className="sokfarm-cmp-link"
                >
                  <i className="fa fa-angle-right"></i> Chính sách bảo vệ dữ liệu cá nhân
                </Link>
              </div>
            </div>
            <div className="sokfarm-cmp-banner-actions">
              <button
                type="button"
                className="sokfarm-cmp-btn sokfarm-cmp-btn-primary"
                onClick={saveCmpConsent}
              >
                <i className="fa fa-check-circle mr-1"></i> Chấp nhận tất cả
              </button>
              <button
                type="button"
                className="sokfarm-cmp-btn sokfarm-cmp-btn-secondary"
                onClick={() => {
                  setAnalytics(false);
                  setPersonalization(false);
                  setMarketing(false);
                  saveCmpConsent();
                }}
              >
                <i className="fa fa-times-circle mr-1"></i> Từ chối cookie không cần thiết
              </button>
              <button
                type="button"
                className="sokfarm-cmp-btn sokfarm-cmp-btn-outline"
                onClick={openCmpModal}
              >
                <i className="fa fa-sliders mr-1"></i> Tùy chỉnh
              </button>
            </div>
          </div>
        </div>

        {cmpModalOpen && (
          <div
            id="sokfarm-cmp-modal"
            className="sokfarm-cmp-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="sokfarm-cmp-modal-title"
          >
            <div className="sokfarm-cmp-modal-backdrop" onClick={closeCmpModal}></div>
            <div className="sokfarm-cmp-modal-dialog">
              <div className="sokfarm-cmp-modal-content">
                <div className="sokfarm-cmp-modal-header">
                  <div className="d-flex align-items-center">
                    <div className="sokfarm-cmp-modal-icon mr-3">
                      <i className="fa fa-lock"></i>
                    </div>
                    <div>
                      <h4 id="sokfarm-cmp-modal-title" className="sokfarm-cmp-modal-title mb-1">
                        Trung tâm Tùy chọn Quyền riêng tư &amp; Cookie
                      </h4>
                      <p className="sokfarm-cmp-modal-subtitle mb-0">
                        Bạn có thể tùy chỉnh các loại cookie và công nghệ theo dõi được phép kích hoạt trên trình duyệt này.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="sokfarm-cmp-modal-close"
                    onClick={closeCmpModal}
                    aria-label="Close"
                  >
                    &times;
                  </button>
                </div>

                <div className="sokfarm-cmp-modal-body">
                  <div className="sokfarm-cmp-category-card">
                    <div className="sokfarm-cmp-category-header">
                      <div className="sokfarm-cmp-category-info">
                        <h5 className="sokfarm-cmp-category-name">Cookie Cần thiết</h5>
                        <span className="sokfarm-cmp-badge sokfarm-cmp-badge-locked">
                          <i className="fa fa-lock mr-1"></i> Luôn bật
                        </span>
                      </div>
                    </div>
                    <p className="sokfarm-cmp-category-desc">
                      Những cookie này là bắt buộc để duy trì các chức năng cơ bản của website như bảo mật phiên làm việc, giỏ hàng, thanh toán và chống spam (reCAPTCHA). Không thể tắt mục này.
                    </p>
                  </div>

                  <div className="sokfarm-cmp-category-card">
                    <div className="sokfarm-cmp-category-header">
                      <div className="sokfarm-cmp-category-info">
                        <h5 className="sokfarm-cmp-category-name">Phân tích &amp; Đo lường</h5>
                        <label className="sokfarm-cmp-switch" htmlFor="sokfarm-cmp-switch-analytics">
                          <input
                            type="checkbox"
                            id="sokfarm-cmp-switch-analytics"
                            checked={analytics}
                            onChange={(e) => setAnalytics(e.target.checked)}
                          />
                          <span className="sokfarm-cmp-slider"></span>
                        </label>
                      </div>
                    </div>
                    <p className="sokfarm-cmp-category-desc">
                      Cho phép chúng tôi thống kê lượt truy cập, lưu lượng và hành vi duyệt web (thông qua Google Analytics 4) nhằm nâng cao chất lượng dịch vụ và trải nghiệm người dùng. Dữ liệu được thu thập dưới dạng ẩn danh.
                    </p>
                  </div>

                  <div className="sokfarm-cmp-category-card">
                    <div className="sokfarm-cmp-category-header">
                      <div className="sokfarm-cmp-category-info">
                        <h5 className="sokfarm-cmp-category-name">Cá nhân hóa</h5>
                        <label className="sokfarm-cmp-switch" htmlFor="sokfarm-cmp-switch-personalization">
                          <input
                            type="checkbox"
                            id="sokfarm-cmp-switch-personalization"
                            checked={personalization}
                            onChange={(e) => setPersonalization(e.target.checked)}
                          />
                          <span className="sokfarm-cmp-slider"></span>
                        </label>
                      </div>
                    </div>
                    <p className="sokfarm-cmp-category-desc">
                      Cho phép website ghi nhớ các tùy chọn cá nhân nâng cao của bạn để mang lại trải nghiệm phù hợp hơn.
                    </p>
                  </div>

                  <div className="sokfarm-cmp-category-card">
                    <div className="sokfarm-cmp-category-header">
                      <div className="sokfarm-cmp-category-info">
                        <h5 className="sokfarm-cmp-category-name">Quảng cáo &amp; Tiếp thị</h5>
                        <label className="sokfarm-cmp-switch" htmlFor="sokfarm-cmp-switch-marketing">
                          <input
                            type="checkbox"
                            id="sokfarm-cmp-switch-marketing"
                            checked={marketing}
                            onChange={(e) => setMarketing(e.target.checked)}
                          />
                          <span className="sokfarm-cmp-slider"></span>
                        </label>
                      </div>
                    </div>
                    <p className="sokfarm-cmp-category-desc">
                      Cho phép kích hoạt các tiện ích hỗ trợ trực tuyến như Facebook và Zalo Chat Widget để kết nối bạn với tư vấn viên của Sokfarm.
                    </p>
                  </div>

                  <div className="sokfarm-cmp-dsar-notice">
                    <i className="fa fa-info-circle text-success mr-2"></i>
                    <span>
                      Bạn có nhu cầu xuất, sửa hoặc xóa dữ liệu cá nhân theo Nghị định 13/2023/NĐ-CP?{' '}
                      <Link
                        to="/user-data-request"
                        onClick={closeCmpModal}
                        className="font-weight-bold text-success text-underline"
                      >
                        Yêu cầu về dữ liệu cá nhân (DSAR)
                      </Link>
                    </span>
                  </div>
                </div>

                <div className="sokfarm-cmp-modal-footer">
                  <div className="sokfarm-cmp-modal-footer-links">
                    <Link
                      to="/policy-and-information/chinh-sach-bao-ve-thong-tin-ca-nhan-cua-nguoi-tieu-dung"
                      onClick={closeCmpModal}
                      className="sokfarm-cmp-link"
                    >
                      Chính sách bảo vệ dữ liệu cá nhân
                    </Link>
                  </div>
                  <div className="sokfarm-cmp-modal-footer-actions">
                    <button
                      type="button"
                      className="sokfarm-cmp-btn sokfarm-cmp-btn-primary"
                      onClick={saveCmpConsent}
                    >
                      <i className="fa fa-check mr-1"></i> Lưu lựa chọn của tôi
                    </button>
                    <button
                      type="button"
                      className="sokfarm-cmp-btn sokfarm-cmp-btn-outline"
                      onClick={() => {
                        setAnalytics(true);
                        setPersonalization(true);
                        setMarketing(true);
                        saveCmpConsent();
                      }}
                    >
                      Chấp nhận tất cả
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
