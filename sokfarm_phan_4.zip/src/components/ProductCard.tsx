import React from 'react';
import { Link } from 'react-router-dom';
import type { Product } from '../types/sokfarm';
import { useApp } from '../context/AppContext';
import { getProductPath, getPrimaryCategoryForProduct, isB2BProduct } from '../data/siteData';

interface ProductCardProps {
  product: Product;
  variant?: 'home' | 'grid';
  showSpecsAndActions?: boolean;
}

function buildProductSrcSet(src: string): string | undefined {
  if (src.startsWith('/images/opt/products/') && src.endsWith('-600w.webp')) {
    const base = src.slice(0, -'-600w.webp'.length);
    return `${base}-320w.webp 320w, ${base}-600w.webp 600w`;
  }
  return undefined;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  variant = 'home',
  showSpecsAndActions = false,
}) => {
  const { addToCart } = useApp();
  const productUrl = getProductPath(product.slug);
  const srcSet = buildProductSrcSet(product.defaultImg);
  const hasDistinctHover = Boolean(product.hoverImg && product.hoverImg !== product.defaultImg);
  const hoverSrcSet = hasDistinctHover ? buildProductSrcSet(product.hoverImg) : undefined;
  const primaryCat = getPrimaryCategoryForProduct(product);
  const isB2B = isB2BProduct(product);

  const handleQuickAdd = () => {
    const firstVariant = product.dataProducts?.[0];
    const price = product.price || Number(firstVariant?.selling_price || firstVariant?.price || 0);
    const code = firstVariant?.code || product.id || product.slug;
    addToCart(
      {
        productId: product.id || code,
        code,
        slug: product.slug,
        title: product.title,
        packaging: firstVariant?.attributes,
        price,
        img: product.defaultImg,
      },
      1
    );
  };

  const specsText = (product.dataProducts || [])
    .map((v) => v.attributes?.trim())
    .filter(Boolean)
    .slice(0, 3)
    .join(' · ');

  if (variant === 'grid') {
    return (
      <div className="col-sm-6 col-md-6 col-lg-4 mb-4 isotope-item">
        <article className="single-product h-100 d-flex flex-column justify-content-between bg-white p-3 rounded border" style={{ borderColor: '#e6ece8' }}>
          <div>
            <div className="product-img mb-3" style={{ backgroundColor: '#fbf4eb', borderRadius: '8px', padding: '10px' }}>
              <Link to={productUrl} className="sokfarm-product-thumb-link">
                <img
                  className="default-img w-100 sokfarm-product-thumb"
                  width={303}
                  height={303}
                  loading="lazy"
                  decoding="async"
                  src={product.defaultImg}
                  srcSet={srcSet}
                  sizes="(max-width: 575.98px) 92vw, (max-width: 991.98px) 46vw, 303px"
                  alt={product.title}
                />
                {hasDistinctHover && (
                  <img
                    className="hover-img w-100 sokfarm-product-thumb d-none d-md-block"
                    width={303}
                    height={303}
                    loading="lazy"
                    decoding="async"
                    src={product.hoverImg}
                    srcSet={hoverSrcSet}
                    sizes="303px"
                    alt={product.title}
                  />
                )}
              </Link>
            </div>
            <div className="product-content text-left mt-0">
              {primaryCat && (
                <div
                  className="text-uppercase mb-1"
                  style={{ fontSize: '11.5px', fontWeight: 600, color: '#556058', letterSpacing: '0.04em' }}
                >
                  {primaryCat.name}
                </div>
              )}
              <h3 style={{ fontSize: '16px', lineHeight: 1.4, minHeight: '44px', marginBottom: '6px' }}>
                <Link to={productUrl} style={{ fontSize: '16px', color: '#222', fontWeight: 600 }}>
                  {product.title}
                </Link>
              </h3>
              {(showSpecsAndActions || specsText) && specsText && (
                <div
                  className="mb-2"
                  style={{ fontSize: '13px', lineHeight: 1.4, color: '#555' }}
                >
                  Quy cách: {specsText}
                </div>
              )}
              <div className="product-price mb-2">
                <span className="web-color-origin" style={{ fontSize: '16px', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                  {product.priceText}
                </span>
              </div>
            </div>
          </div>

          <div
            className="d-flex align-items-center justify-content-between flex-wrap pt-2 mt-2 border-top"
            style={{ gap: '8px', borderColor: '#eef2ef' }}
          >
            <Link
              to={productUrl}
              className="btn btn-sm btn-outline-success"
              style={{
                borderColor: '#158247',
                color: '#158247',
                minHeight: '40px',
                display: 'inline-flex',
                alignItems: 'center',
                fontWeight: 600,
                flex: '1 1 auto',
                justifyContent: 'center',
              }}
            >
              Xem chi tiết
            </Link>
            {isB2B || !product.hasCartBtn || product.price === 0 ? (
              <Link
                to="/export-markets#bao-gia-xuat-khau"
                className="btn btn-sm btn-success text-white"
                style={{
                  backgroundColor: '#158247',
                  borderColor: '#158247',
                  minHeight: '40px',
                  display: 'inline-flex',
                  alignItems: 'center',
                  fontWeight: 600,
                  flex: '1 1 auto',
                  justifyContent: 'center',
                }}
              >
                Nhận báo giá
              </Link>
            ) : (
              <button
                type="button"
                className="btn btn-sm btn-add-to-cart-item"
                style={{
                  padding: '8px 12px',
                  fontSize: '13px',
                  minHeight: '40px',
                  flex: '1 1 auto',
                  display: 'inline-flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                onClick={handleQuickAdd}
                aria-label={`Thêm ${product.title} vào giỏ hàng`}
              >
                <i className="ti-shopping-cart mr-1" aria-hidden="true"></i>Thêm giỏ hàng
              </button>
            )}
          </div>
        </article>
      </div>
    );
  }

  return (
    <div className="col-sm-6 col-md-3 mb-4 isotope-item">
      <article className="single-product h-100 d-flex flex-column justify-content-between bg-white p-3 rounded border" style={{ borderColor: '#e6ece8' }}>
        <div>
          <div className="product-img mb-3" style={{ backgroundColor: '#fbf4eb', borderRadius: '8px', padding: '8px' }}>
            <Link to={productUrl} className="sokfarm-product-thumb-link">
              <img
                className="default-img w-100 sokfarm-product-thumb"
                width={303}
                height={303}
                loading="lazy"
                decoding="async"
                src={product.defaultImg}
                srcSet={srcSet}
                sizes="(max-width: 575.98px) 92vw, (max-width: 767.98px) 46vw, 255px"
                alt={product.title}
              />
              {hasDistinctHover && (
                <img
                  className="hover-img w-100 sokfarm-product-thumb d-none d-md-block"
                  width={303}
                  height={303}
                  loading="lazy"
                  decoding="async"
                  src={product.hoverImg}
                  srcSet={hoverSrcSet}
                  sizes="255px"
                  alt={product.title}
                />
              )}
            </Link>
          </div>
          <div className="product-content mt-0">
            {primaryCat && (
              <div
                className="text-uppercase mb-1"
                style={{ fontSize: '11px', fontWeight: 600, color: '#556058', letterSpacing: '0.04em' }}
              >
                {primaryCat.name}
              </div>
            )}
            <h3 className="mb-2" style={{ fontSize: '15.5px', lineHeight: 1.4, minHeight: '44px' }}>
              <Link to={productUrl} style={{ fontSize: '15.5px', color: '#222', fontWeight: 600 }}>
                {product.title}
              </Link>
            </h3>
            <div className="product-price mb-2">
              <span className="web-color-origin" style={{ fontSize: '15.5px', fontWeight: 700, fontVariantNumeric: 'tabular-nums' }}>
                {product.priceText}
              </span>
            </div>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center pt-2 border-top" style={{ gap: '8px', borderColor: '#eef2ef' }}>
          <Link
            to={productUrl}
            className="btn btn-sm btn-outline-success"
            style={{
              borderColor: '#158247',
              color: '#158247',
              minHeight: '42px',
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 600,
              flex: '1 1 auto',
            }}
          >
            Xem chi tiết
          </Link>
          {product.hasCartBtn && !isB2B && (
            <button
              type="button"
              className="btn btn-add-to-cart-item"
              style={{ minWidth: '44px', minHeight: '42px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
              onClick={handleQuickAdd}
              aria-label={`Thêm ${product.title} vào giỏ hàng`}
              title="Thêm vào giỏ hàng"
            >
              <i style={{ fontSize: '18px' }} className="ti-shopping-cart" aria-hidden="true"></i>
            </button>
          )}
        </div>
      </article>
    </div>
  );
};
