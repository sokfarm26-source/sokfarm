import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { B2C_CATEGORIES, TOP_B2C_CATEGORIES, BLOG_CATEGORIES } from '../data/siteData';

export const Header: React.FC = () => {
  const { cartTotalCount, wishlist, user, logoutDemo, lang, setLang, notify } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileProdOpen, setMobileProdOpen] = useState(false);
  const [mobileAboutOpen, setMobileAboutOpen] = useState(false);
  const [mobilePartnerOpen, setMobilePartnerOpen] = useState(false);
  const [mobileExploreOpen, setMobileExploreOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const isEn = lang === 'en';

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    if (!mobileMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileMenuOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [mobileMenuOpen]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchTerm.trim();
    navigate(`/product/search?searchInfo=${encodeURIComponent(q)}`);
    setMobileMenuOpen(false);
  };

  const handleLanguageSwitch = (target: 'vi' | 'en') => {
    setLang(target);
    notify(
      target === 'en'
        ? 'Switched display labels to English (EN)'
        : 'Đã chuyển ngôn ngữ hiển thị sang Tiếng Việt',
      'success'
    );
  };

  const closeMobile = () => setMobileMenuOpen(false);

  const isGroupActive = (prefixes: string[]) =>
    prefixes.some((p) => location.pathname.startsWith(p)) ? 'active' : '';

  const prodActive = isGroupActive(['/san-pham', '/danh-muc', '/bo-suu-tap', '/product']);
  const aboutActive = isGroupActive([
    '/about-us',
    '/phat-trien-ben-vung',
    '/goc-kham-pha/cau-chuyen-sokfarm',
    '/he-thong-cua-hang',
    '/list-store',
  ]);
  const partnerActive = isGroupActive([
    '/nguyen-lieu',
    '/giai-phap-horeca',
    '/export-markets',
    '/doi-tac',
  ]);
  const newsActive =
    (location.pathname.startsWith('/goc-kham-pha') &&
      !location.pathname.startsWith('/goc-kham-pha/cau-chuyen-sokfarm')) ||
    location.pathname.startsWith('/tin-tuc') ||
    location.pathname === '/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac' ||
    location.pathname === '/vi-ngot-cho-nguoi-an-thuan-chay'
      ? 'active'
      : '';
  const contactActive = isGroupActive(['/contact']);

  const coconutNectarChildren = B2C_CATEGORIES.filter((c) => c.parentSlug === 'mat-hoa-dua');

  return (
    <header className="header shop">
      {/* Topbar */}
      <div className="topbar d-none d-md-block d-lg-block d-xl-block">
        <div className="container" style={{ fontFamily: "'Be Vietnam'" }}>
          <div className="row">
            <div className="col-lg-5 col-md-5">
              <div className="top-left">
                <ul className="list-main">
                  <li>
                    <i className="ti-headphone-alt" aria-hidden="true"></i>
                    <a href="tel:0966243066" style={{ color: 'inherit' }}>
                      0966 243 066
                    </a>
                  </li>
                  <li>
                    <i className="ti-email" aria-hidden="true"></i>
                    <a href="mailto:hello@sokfarm.com" style={{ color: 'inherit' }}>
                      hello@sokfarm.com
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-7 col-md-7">
              <div className="right-content">
                <ul className="list-main">
                  {user ? (
                    <li>
                      <i className="ti-user" aria-hidden="true"></i>
                      <span className="mr-2">{user.name}</span>
                      <button
                        type="button"
                        onClick={() => logoutDemo()}
                        style={{
                          background: 'none',
                          border: 0,
                          padding: 0,
                          color: 'inherit',
                          font: 'inherit',
                          cursor: 'pointer',
                        }}
                      >
                        {isEn ? 'Logout' : 'Đăng xuất'}
                      </button>
                    </li>
                  ) : (
                    <li>
                      <i className="ti-power-off" aria-hidden="true"></i>
                      <Link to="/user/login">{isEn ? 'Login /' : 'Đăng nhập /'}</Link>{' '}
                      <Link to="/user/register">{isEn ? 'Register' : 'Đăng ký'}</Link>
                    </li>
                  )}
                  <li>
                    <button
                      type="button"
                      onClick={() => handleLanguageSwitch('en')}
                      title="English"
                      aria-label="Switch language to English"
                      style={{
                        background: 'none',
                        border: 0,
                        padding: '0 4px 0 0',
                        cursor: 'pointer',
                      }}
                    >
                      <img src="/frontend/img/en_US.png" width={18} height={12} alt="" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleLanguageSwitch('vi')}
                      title="Tiếng Việt"
                      aria-label="Chuyển ngôn ngữ sang Tiếng Việt"
                      style={{
                        background: 'none',
                        border: 0,
                        padding: 0,
                        cursor: 'pointer',
                      }}
                    >
                      <img src="/frontend/img/vi.png" width={18} height={12} alt="" />
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* End Topbar */}

      <div className="middle-inner" style={{ padding: '10px 0' }}>
        <div className="container" style={{ borderBottom: '#80808042 1px solid', paddingBottom: '10px' }}>
          <div className="row middle-top-bar align-items-center">
            {/* Desktop Logo Left + Brand Subtitle */}
            <div className="col-md-4 d-none d-md-flex align-items-center" style={{ gap: '12px' }}>
              <Link
                to="/"
                className="d-inline-flex align-items-center"
                aria-label="Sokfarm - Về trang chủ"
                title="Về trang chủ Sokfarm"
                style={{ gap: '10px', textDecoration: 'none' }}
              >
                <img
                  src="/images/opt/ui/logo_sokfarm2.webp"
                  width={84}
                  height={84}
                  style={{ width: '84px', height: '84px', objectFit: 'contain', flexShrink: 0 }}
                  alt="Logo Sokfarm"
                />
                <div className="d-none d-lg-block text-left">
                  <div className="font-weight-bold" style={{ color: '#158247', fontSize: '14px', lineHeight: 1.3 }}>
                    SOKFARM TRÀ VINH
                  </div>
                  <div style={{ color: '#4a554e', fontSize: '12px', lineHeight: 1.35 }}>
                    Mật Hoa Dừa Hữu Cơ Quốc Tế
                  </div>
                </div>
              </Link>
            </div>

            {/* Mobile Top Bar (320px - 767px flex bar, zero overlap/overflow) */}
            <div className="col-12 d-block d-md-none">
              <div className="sokfarm-mobile-header">
                <div className="sokfarm-mobile-header-row">
                  <Link
                    to="/"
                    className="sokfarm-mobile-logo"
                    aria-label="Sokfarm - Về trang chủ"
                    title="Về trang chủ Sokfarm"
                  >
                    <img
                      src="/images/opt/ui/Sokfarm_English_xanh.webp"
                      width={56}
                      height={56}
                      alt="Logo Sokfarm"
                    />
                  </Link>

                  <form onSubmit={handleSearchSubmit} className="sokfarm-mobile-search">
                    <div className="input-group flex-nowrap">
                      <input
                        type="text"
                        className="form-control sokfarm-mobile-search-input"
                        aria-label={isEn ? 'Search products' : 'Tìm kiếm sản phẩm'}
                        placeholder={isEn ? 'Search...' : 'Tìm sản phẩm...'}
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                      <button
                        value="search"
                        type="submit"
                        aria-label={isEn ? 'Search' : 'Tìm kiếm'}
                        className="btn btn-success sokfarm-mobile-search-btn"
                      >
                        <i className="ti-search" aria-hidden="true"></i>
                      </button>
                    </div>
                  </form>

                  <div className="sokfarm-mobile-actions">
                    <Link
                      to="/dat-hang"
                      className="sokfarm-mobile-icon-btn"
                      aria-label="Giỏ hàng và đặt hàng"
                    >
                      <i className="ti-bag" aria-hidden="true"></i>
                      <span className="total-count cart-total-count sokfarm-mobile-badge">
                        {cartTotalCount}
                      </span>
                    </Link>

                    <Link
                      to="/wishlist"
                      className="sokfarm-mobile-icon-btn"
                      aria-label="Danh sách yêu thích"
                    >
                      <i className="fa fa-heart-o" aria-hidden="true"></i>
                      <span className="total-count sokfarm-mobile-badge">{wishlist.length}</span>
                    </Link>

                    <button
                      type="button"
                      aria-haspopup="true"
                      aria-expanded={mobileMenuOpen}
                      aria-controls="sokfarm-mobile-drawer"
                      aria-label={mobileMenuOpen ? 'Đóng menu điều hướng' : 'Mở menu điều hướng'}
                      className={`sokfarm-mobile-hamburger ${mobileMenuOpen ? 'is-open' : ''}`}
                      onClick={() => setMobileMenuOpen((v) => !v)}
                    >
                      <span className="slicknav_icon-bar"></span>
                      <span className="slicknav_icon-bar"></span>
                      <span className="slicknav_icon-bar"></span>
                    </button>
                  </div>
                </div>

                {/* Mobile Accordion Menu (Đúng 5 mục chính + nút Đóng rõ ràng) */}
                {mobileMenuOpen && (
                  <nav
                    id="sokfarm-mobile-drawer"
                    aria-label="Menu điều hướng di động"
                    className="sokfarm-mobile-nav-drawer text-left"
                  >
                    <div
                      className="d-flex align-items-center justify-content-between pb-2 mb-2 border-bottom"
                      style={{ borderColor: '#e0e8e2' }}
                    >
                      <span className="font-weight-bold" style={{ color: '#158247', fontSize: '14px' }}>
                        {isEn ? 'Navigation Menu' : 'Danh mục điều hướng'}
                      </span>
                      <button
                        type="button"
                        onClick={closeMobile}
                        aria-label="Đóng menu điều hướng"
                        className="btn btn-sm btn-outline-success"
                        style={{
                          minHeight: '38px',
                          minWidth: '72px',
                          borderColor: '#158247',
                          color: '#158247',
                          fontWeight: 600,
                        }}
                      >
                        Đóng &times;
                      </button>
                    </div>

                    <ul className="slicknav_nav">
                      {/* 1. VỀ SOKFARM */}
                      <li className={`slicknav_parent ${aboutActive}`}>
                        <div className="d-flex justify-content-between align-items-center">
                          <Link
                            to="/about-us"
                            onClick={closeMobile}
                            className="sokfarm-mobile-nav-link"
                            style={aboutActive ? { color: '#158247', fontWeight: 700 } : undefined}
                          >
                            {isEn ? 'About Sokfarm' : 'Về Sokfarm'}
                          </Link>
                          <button
                            type="button"
                            aria-label="Mở danh mục con Về Sokfarm"
                            aria-expanded={mobileAboutOpen}
                            className="btn sokfarm-mobile-expand-btn"
                            onClick={() => setMobileAboutOpen((v) => !v)}
                          >
                            <i className={`ti-angle-${mobileAboutOpen ? 'up' : 'down'}`} aria-hidden="true"></i>
                          </button>
                        </div>
                        {mobileAboutOpen && (
                          <ul className="pl-3">
                            <li>
                              <Link to="/about-us" onClick={closeMobile}>
                                {isEn ? 'About Sokfarm' : 'Giới thiệu Sokfarm'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/phat-trien-ben-vung" onClick={closeMobile}>
                                {isEn ? 'Sustainable Development' : 'Phát triển bền vững'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/goc-kham-pha/cau-chuyen-sokfarm" onClick={closeMobile}>
                                {isEn ? 'Sokfarm Story' : 'Câu chuyện Sokfarm'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/he-thong-cua-hang" onClick={closeMobile}>
                                {isEn ? 'Store System' : 'Hệ thống cửa hàng'}
                              </Link>
                            </li>
                          </ul>
                        )}
                      </li>

                      {/* 2. SẢN PHẨM */}
                      <li className={`slicknav_parent ${prodActive}`}>
                        <div className="d-flex justify-content-between align-items-center">
                          <Link
                            to="/san-pham"
                            onClick={closeMobile}
                            className="sokfarm-mobile-nav-link"
                            style={prodActive ? { color: '#158247', fontWeight: 700 } : undefined}
                          >
                            {isEn ? 'Products' : 'Sản phẩm'}
                          </Link>
                          <button
                            type="button"
                            aria-label="Mở danh mục con Sản phẩm"
                            aria-expanded={mobileProdOpen}
                            className="btn sokfarm-mobile-expand-btn"
                            onClick={() => setMobileProdOpen((v) => !v)}
                          >
                            <i className={`ti-angle-${mobileProdOpen ? 'up' : 'down'}`} aria-hidden="true"></i>
                          </button>
                        </div>
                        {mobileProdOpen && (
                          <ul className="pl-3">
                            <li>
                              <Link to="/san-pham" onClick={closeMobile}>
                                {isEn ? 'All Products' : 'Tất cả sản phẩm'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/san-pham/ban-chay-nhat" onClick={closeMobile}>
                                {isEn ? 'Best Sellers' : 'Sản phẩm bán chạy nhất'}
                              </Link>
                            </li>
                            {TOP_B2C_CATEGORIES.map((cat) => (
                              <li key={cat.slug}>
                                <Link to={`/danh-muc/${cat.slug}`} onClick={closeMobile}>
                                  {isEn ? cat.nameEn : cat.name}
                                </Link>
                                {cat.slug === 'mat-hoa-dua' && (
                                  <ul className="pl-3">
                                    {coconutNectarChildren.map((child) => (
                                      <li key={child.slug}>
                                        <Link to={`/danh-muc/${child.slug}`} onClick={closeMobile}>
                                          {isEn ? child.nameEn : child.name}
                                        </Link>
                                      </li>
                                    ))}
                                  </ul>
                                )}
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>

                      {/* 3. TIN TỨC & KIẾN THỨC */}
                      <li className={`slicknav_parent ${newsActive}`}>
                        <div className="d-flex justify-content-between align-items-center">
                          <Link
                            to="/goc-kham-pha"
                            onClick={closeMobile}
                            className="sokfarm-mobile-nav-link"
                            style={newsActive ? { color: '#158247', fontWeight: 700 } : undefined}
                          >
                            {isEn ? 'News & Knowledge' : 'Tin tức & Kiến thức'}
                          </Link>
                          <button
                            type="button"
                            aria-label="Mở danh mục con Tin tức & Kiến thức"
                            aria-expanded={mobileExploreOpen}
                            className="btn sokfarm-mobile-expand-btn"
                            onClick={() => setMobileExploreOpen((v) => !v)}
                          >
                            <i className={`ti-angle-${mobileExploreOpen ? 'up' : 'down'}`} aria-hidden="true"></i>
                          </button>
                        </div>
                        {mobileExploreOpen && (
                          <ul className="pl-3">
                            <li>
                              <Link to="/goc-kham-pha" onClick={closeMobile}>
                                {isEn ? 'All Articles' : 'Tất cả bài viết'}
                              </Link>
                            </li>
                            {BLOG_CATEGORIES.map((bc) => (
                              <li key={bc.slug}>
                                <Link to={`/goc-kham-pha/${bc.slug}`} onClick={closeMobile}>
                                  {bc.name}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>

                      {/* 4. ĐỐI TÁC & XUẤT KHẨU */}
                      <li className={`slicknav_parent ${partnerActive}`}>
                        <div className="d-flex justify-content-between align-items-center">
                          <Link
                            to="/export-markets"
                            onClick={closeMobile}
                            className="sokfarm-mobile-nav-link"
                            style={partnerActive ? { color: '#158247', fontWeight: 700 } : undefined}
                          >
                            {isEn ? 'Partners & Export' : 'Đối tác & Xuất khẩu'}
                          </Link>
                          <button
                            type="button"
                            aria-label="Mở danh mục con Đối tác & Xuất khẩu"
                            aria-expanded={mobilePartnerOpen}
                            className="btn sokfarm-mobile-expand-btn"
                            onClick={() => setMobilePartnerOpen((v) => !v)}
                          >
                            <i className={`ti-angle-${mobilePartnerOpen ? 'up' : 'down'}`} aria-hidden="true"></i>
                          </button>
                        </div>
                        {mobilePartnerOpen && (
                          <ul className="pl-3">
                            <li>
                              <Link to="/nguyen-lieu" onClick={closeMobile}>
                                {isEn ? 'Ingredients' : 'Nguyên liệu'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/giai-phap-horeca" onClick={closeMobile}>
                                {isEn ? 'HORECA Solutions' : 'Giải pháp HORECA'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/export-markets#thi-truong-xuat-khau" onClick={closeMobile}>
                                {isEn ? 'Export Markets' : 'Thị trường xuất khẩu'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/export-markets#san-pham-xuat-khau" onClick={closeMobile}>
                                {isEn ? 'Export Products' : 'Sản phẩm xuất khẩu'}
                              </Link>
                            </li>
                            <li>
                              <Link to="/export-markets#bao-gia-xuat-khau" onClick={closeMobile}>
                                {isEn ? 'Request a Quote' : 'Yêu cầu báo giá'}
                              </Link>
                            </li>
                          </ul>
                        )}
                      </li>

                      {/* 5. LIÊN HỆ */}
                      <li className={contactActive}>
                        <Link
                          to="/contact"
                          onClick={closeMobile}
                          className="sokfarm-mobile-nav-link"
                          style={contactActive ? { color: '#158247', fontWeight: 700 } : undefined}
                        >
                          {isEn ? 'Contact' : 'Liên hệ'}
                        </Link>
                      </li>

                      {!user && (
                        <>
                          <li>
                            <Link to="/user/login" onClick={closeMobile} className="sokfarm-mobile-nav-link">
                              {isEn ? 'Login' : 'Đăng nhập'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/user/register" onClick={closeMobile} className="sokfarm-mobile-nav-link">
                              {isEn ? 'Register' : 'Đăng ký'}
                            </Link>
                          </li>
                        </>
                      )}
                      <li className="py-2 d-flex align-items-center" style={{ gap: '12px' }}>
                        <button
                          type="button"
                          aria-label="Switch language to English"
                          className="sokfarm-mobile-lang-btn"
                          onClick={() => {
                            handleLanguageSwitch('en');
                            closeMobile();
                          }}
                        >
                          <img src="/frontend/img/en_US.png" width={22} height={15} alt="" />
                        </button>
                        <button
                          type="button"
                          aria-label="Chuyển ngôn ngữ sang Tiếng Việt"
                          className="sokfarm-mobile-lang-btn"
                          onClick={() => {
                            handleLanguageSwitch('vi');
                            closeMobile();
                          }}
                        >
                          <img src="/frontend/img/vi.png" width={22} height={15} alt="" />
                        </button>
                      </li>
                    </ul>
                  </nav>
                )}
              </div>
            </div>

            {/* Desktop Right Utility Area: Search + Wishlist + Cart */}
            <div className="col-md-8 d-none d-md-flex align-items-center justify-content-end" style={{ gap: '18px' }}>
              <form
                onSubmit={handleSearchSubmit}
                className="sokfarm-desktop-right-search"
                role="search"
                aria-label="Tìm kiếm sản phẩm"
              >
                <div className="input-group">
                  <input
                    type="text"
                    name="searchInfo"
                    id="infoSearchInput"
                    className="form-control"
                    aria-label={isEn ? 'Search products' : 'Tìm kiếm sản phẩm'}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={isEn ? 'Search organic nectar products...' : 'Tìm sản phẩm mật hoa dừa...'}
                    style={{
                      height: '42px',
                      borderRadius: '6px 0 0 6px',
                      border: '1px solid #cddbd2',
                      fontSize: '14px',
                      minWidth: '240px',
                    }}
                  />
                  <div className="input-group-append">
                    <button
                      type="submit"
                      className="btn btn-success text-white px-3"
                      aria-label={isEn ? 'Search' : 'Tìm kiếm'}
                      style={{
                        height: '42px',
                        borderRadius: '0 6px 6px 0',
                        backgroundColor: '#158247',
                        borderColor: '#158247',
                        fontWeight: 600,
                        fontSize: '14px',
                      }}
                    >
                      <i className="ti-search mr-1" aria-hidden="true"></i>
                      {isEn ? 'Search' : 'Tìm kiếm'}
                    </button>
                  </div>
                </div>
              </form>

              <div className="right-bar d-flex align-items-center" style={{ position: 'static', top: '0px', gap: '16px' }}>
                <div className="sinlge-bar shopping m-0">
                  <Link
                    to="/wishlist"
                    className="single-icon"
                    aria-label="Danh sách yêu thích"
                    title="Danh sách yêu thích"
                    style={{ minWidth: '40px', minHeight: '40px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
                  >
                    <i className="fa fa-heart-o" aria-hidden="true"></i>
                    <span className="total-count">{wishlist.length}</span>
                  </Link>
                </div>
                <div className="sinlge-bar shopping m-0">
                  <Link
                    to="/dat-hang"
                    className="single-icon"
                    aria-label="Giỏ hàng và đặt hàng"
                    title="Giỏ hàng"
                    style={{ minWidth: '40px', minHeight: '40px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
                  >
                    <i className="ti-bag" aria-hidden="true"></i>
                    <span className="total-count cart-total-count">{cartTotalCount}</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Header Inner: Đúng 5 mục menu chính */}
      <div className="header-inner">
        <div className="container p-0">
          <div className="cat-nav-head">
            <div className="menu-area">
              <nav className="navbar navbar-expand-lg" aria-label="Điều hướng chính">
                <div className="navbar-collapse">
                  <div className="nav-inner w-100">
                    <ul className="nav main-menu menu navbar-nav justify-content-between w-100">
                      {/* 1. VỀ SOKFARM */}
                      <li className={aboutActive}>
                        <Link to="/about-us">
                          {isEn ? 'About Sokfarm' : 'Về Sokfarm'}
                          <i className="ti-angle-down" aria-hidden="true"></i>
                        </Link>
                        <ul className="dropdown border-0 shadow">
                          <li>
                            <Link to="/about-us">
                              {isEn ? 'About Sokfarm' : 'Giới thiệu Sokfarm'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/phat-trien-ben-vung">
                              {isEn ? 'Sustainable Development' : 'Phát triển bền vững'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/goc-kham-pha/cau-chuyen-sokfarm">
                              {isEn ? 'Sokfarm Story' : 'Câu chuyện Sokfarm'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/he-thong-cua-hang">
                              {isEn ? 'Store System' : 'Hệ thống cửa hàng'}
                            </Link>
                          </li>
                        </ul>
                      </li>

                      {/* 2. SẢN PHẨM */}
                      <li className={prodActive}>
                        <Link to="/san-pham">
                          {isEn ? 'Products' : 'Sản phẩm'}
                          <i className="ti-angle-down" aria-hidden="true"></i>
                        </Link>
                        <ul className="dropdown border-0 shadow">
                          <li>
                            <Link to="/san-pham">
                              {isEn ? 'All Products' : 'Tất cả sản phẩm'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/san-pham/ban-chay-nhat">
                              {isEn ? 'Best Sellers' : 'Sản phẩm bán chạy nhất'}
                            </Link>
                          </li>
                          {TOP_B2C_CATEGORIES.map((cat) => (
                            <li key={cat.slug}>
                              <Link
                                to={`/danh-muc/${cat.slug}`}
                                className={
                                  cat.slug === 'mat-hoa-dua'
                                    ? 'd-flex align-items-center justify-content-between'
                                    : undefined
                                }
                              >
                                <span>{isEn ? cat.nameEn : cat.name}</span>
                                {cat.slug === 'mat-hoa-dua' && <i className="ti-angle-right" aria-hidden="true"></i>}
                              </Link>
                              {cat.slug === 'mat-hoa-dua' && (
                                <ul className="dropdown sub-dropdown border-0 shadow">
                                  {coconutNectarChildren.map((child) => (
                                    <li key={child.slug}>
                                      <Link to={`/danh-muc/${child.slug}`}>
                                        {isEn ? child.nameEn : child.name}
                                      </Link>
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </li>
                          ))}
                        </ul>
                      </li>

                      {/* 3. TIN TỨC & KIẾN THỨC */}
                      <li className={newsActive}>
                        <Link to="/goc-kham-pha">
                          {isEn ? 'News & Knowledge' : 'Tin tức & Kiến thức'}
                          <i className="ti-angle-down" aria-hidden="true"></i>
                        </Link>
                        <ul className="dropdown border-0 shadow">
                          <li>
                            <Link to="/goc-kham-pha">
                              {isEn ? 'All Articles' : 'Tất cả bài viết'}
                            </Link>
                          </li>
                          {BLOG_CATEGORIES.map((bc) => (
                            <li key={bc.slug}>
                              <Link to={`/goc-kham-pha/${bc.slug}`}>{bc.name}</Link>
                            </li>
                          ))}
                        </ul>
                      </li>

                      {/* 4. ĐỐI TÁC & XUẤT KHẨU */}
                      <li className={partnerActive}>
                        <Link to="/export-markets">
                          {isEn ? 'Partners & Export' : 'Đối tác & Xuất khẩu'}
                          <i className="ti-angle-down" aria-hidden="true"></i>
                        </Link>
                        <ul className="dropdown border-0 shadow">
                          <li>
                            <Link to="/nguyen-lieu">{isEn ? 'Ingredients' : 'Nguyên liệu'}</Link>
                          </li>
                          <li>
                            <Link to="/giai-phap-horeca">
                              {isEn ? 'HORECA Solutions' : 'Giải pháp HORECA'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/export-markets#thi-truong-xuat-khau">
                              {isEn ? 'Export Markets' : 'Thị trường xuất khẩu'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/export-markets#san-pham-xuat-khau">
                              {isEn ? 'Export Products' : 'Sản phẩm xuất khẩu'}
                            </Link>
                          </li>
                          <li>
                            <Link to="/export-markets#bao-gia-xuat-khau">
                              {isEn ? 'Request a Quote' : 'Yêu cầu báo giá'}
                            </Link>
                          </li>
                        </ul>
                      </li>

                      {/* 5. LIÊN HỆ */}
                      <li className={contactActive}>
                        <Link to="/contact">{isEn ? 'Contact' : 'Liên hệ'}</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
      {/* End Header Inner */}
    </header>
  );
};
