import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const SOCIAL_LINKS = [
  {
    href: 'https://www.facebook.com/sokfarmfanpage',
    label: 'Facebook Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-01.webp',
    alt: 'Facebook Sokfarm',
  },
  {
    href: 'https://www.youtube.com/channel/UCPmRc9EIScKbJBcf33pwFmA',
    label: 'YouTube Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-02.webp',
    alt: 'YouTube Sokfarm',
  },
  {
    href: 'https://www.instagram.com/sokfarmvietnam/',
    label: 'Instagram Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-03.webp',
    alt: 'Instagram Sokfarm',
  },
  {
    href: 'https://www.tiktok.com/@ngai_mathoadua_sokfarm',
    label: 'TikTok Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-04.webp',
    alt: 'TikTok Sokfarm',
  },
  {
    href: 'https://www.linkedin.com/company/sokfarm-coconut-flower-nectar/',
    label: 'LinkedIn Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-05.webp',
    alt: 'LinkedIn Sokfarm',
  },
  {
    href: 'https://wa.me/+84974038946',
    label: 'WhatsApp Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-07.webp',
    alt: 'WhatsApp Sokfarm',
  },
  {
    href: 'https://zalo.me/sokfarm',
    label: 'Zalo OA Sokfarm (mở tab mới)',
    icon: '/images/opt/social/icon-08.webp',
    alt: 'Zalo OA Sokfarm',
  },
];

export const Footer: React.FC = () => {
  const { openCmpModal } = useApp();

  return (
    <footer className="sokfarm-footer" aria-label="Thông tin chân trang Sokfarm">
      {/* Footer Top */}
      <div className="footer-top section sokfarm-footer-inner">
        <div className="container">
          {/* Contact & Social Quick Bar */}
          <div className="row sokfarm-footer-contact-bar align-items-start align-items-lg-center">
            <div className="col-12 col-md-6 col-lg-5">
              <div className="sokfarm-footer-contact-item">
                <img
                  className="rounded-circle flex-shrink-0"
                  src="/images/address_icon_footer.png"
                  width={36}
                  height={36}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '36px', height: '36px', objectFit: 'contain' }}
                  alt=""
                />
                <div className="text-left sokfarm-footer-contact-text">
                  <strong className="sokfarm-footer-contact-label">Địa chỉ nhà máy &amp; văn phòng:</strong>
                  <span>Ấp Cây Hẹ, Xã Tiểu Cần, Tỉnh Vĩnh Long, Việt Nam</span>
                </div>
              </div>
            </div>

            <div className="col-12 col-md-6 col-lg-4">
              <div className="sokfarm-footer-contact-item">
                <img
                  className="rounded-circle flex-shrink-0"
                  src="/images/hotlline_icon_footer.png"
                  width={36}
                  height={36}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '36px', height: '36px', objectFit: 'contain' }}
                  alt=""
                />
                <div className="text-left sokfarm-footer-contact-text">
                  <strong className="sokfarm-footer-contact-label">Hotline &amp; Email:</strong>
                  <div className="sokfarm-footer-phone-row">
                    <a href="tel:0966243066" aria-label="Gọi hotline 0966 243 066">
                      0966 243 066
                    </a>
                    <span aria-hidden="true">·</span>
                    <a href="tel:0974038946" aria-label="Gọi hotline 0974 038 946">
                      0974 038 946
                    </a>
                  </div>
                  <a
                    href="mailto:hello@sokfarm.com"
                    className="sokfarm-footer-email-link"
                    aria-label="Gửi email tới hello@sokfarm.com"
                  >
                    hello@sokfarm.com
                  </a>
                </div>
              </div>
            </div>

            <div className="col-12 col-lg-3">
              <nav aria-label="Mạng xã hội Sokfarm" className="sokfarm-footer-social-list">
                {SOCIAL_LINKS.map((item) => (
                  <a
                    key={item.href}
                    className="sokfarm-footer-social-link"
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={item.label}
                  >
                    <img
                      src={item.icon}
                      alt={item.alt}
                      width={30}
                      height={30}
                      loading="lazy"
                      decoding="async"
                      style={{ width: '30px', height: '30px', objectFit: 'contain' }}
                    />
                  </a>
                ))}
              </nav>
            </div>
          </div>

          <hr className="sokfarm-footer-divider" />

          {/* 5 Structured Footer Groups */}
          <div className="sokfarm-footer-groups-grid">
            {/* Nhóm 1: Công ty TNHH Trà Vinh Farm */}
            <div className="single-footer sokfarm-footer-company">
              <Link to="/" className="sokfarm-footer-company-title-link">
                <h2 className="sokfarm-footer-heading mb-2">CÔNG TY TNHH TRÀ VINH FARM</h2>
              </Link>
              <p className="sokfarm-footer-company-desc mb-2">
                Sok trong tiếng Khmer có nghĩa là HẠNH PHÚC và SOKFARM có nghĩa là Nông Nghiệp Hạnh Phúc.
              </p>
              <p className="sokfarm-footer-tax mb-3">
                Mã số thuế: <strong>2100647732</strong>
              </p>
              <div className="sokfarm-footer-badges">
                <img
                  src="/images/opt/ui/footer_img.webp"
                  width={220}
                  height={104}
                  loading="lazy"
                  decoding="async"
                  style={{ width: '100%', maxWidth: '196px', height: 'auto' }}
                  alt="Logo Sokfarm Nông nghiệp Hạnh phúc"
                />
                <a
                  href="http://online.gov.vn/Home/WebDetails/81552"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Thông tin doanh nghiệp đã thông báo Bộ Công Thương (mở tab mới)"
                  className="d-inline-block"
                >
                  <img
                    loading="lazy"
                    decoding="async"
                    width={150}
                    height={57}
                    style={{ width: '100%', maxWidth: '142px', height: 'auto' }}
                    src="/images/opt/ui/logoSaleNoti.webp"
                    alt="Đã thông báo Bộ Công Thương"
                  />
                </a>
              </div>
            </div>

            {/* Nhóm 2: Sản phẩm */}
            <nav className="single-footer links sokfarm-footer-group" aria-labelledby="footer-heading-products">
              <h2 id="footer-heading-products" className="sokfarm-footer-heading">
                Sản phẩm
              </h2>
              <ul className="sokfarm-footer-list">
                <li>
                  <Link to="/san-pham">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Tất cả sản phẩm</span>
                  </Link>
                </li>
                <li>
                  <Link to="/san-pham/ban-chay-nhat">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Bán chạy nhất</span>
                  </Link>
                </li>
                <li>
                  <Link to="/danh-muc/mat-hoa-dua">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Mật hoa dừa</span>
                  </Link>
                </li>
                <li>
                  <Link to="/danh-muc/duong-hoa-dua">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Đường hoa dừa</span>
                  </Link>
                </li>
                <li>
                  <Link to="/danh-muc/do-uong">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Đồ uống</span>
                  </Link>
                </li>
                <li>
                  <Link to="/danh-muc/gia-vi">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Gia vị hữu cơ</span>
                  </Link>
                </li>
              </ul>
            </nav>

            {/* Nhóm 3: Về Sokfarm */}
            <nav className="single-footer links sokfarm-footer-group" aria-labelledby="footer-heading-about">
              <h2 id="footer-heading-about" className="sokfarm-footer-heading">
                Về Sokfarm
              </h2>
              <ul className="sokfarm-footer-list">
                <li>
                  <Link to="/about-us">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Giới thiệu Sokfarm</span>
                  </Link>
                </li>
                <li>
                  <Link to="/goc-kham-pha/cau-chuyen-sokfarm">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Câu chuyện Sokfarm</span>
                  </Link>
                </li>
                <li>
                  <Link to="/phat-trien-ben-vung">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Phát triển bền vững</span>
                  </Link>
                </li>
                <li>
                  <Link to="/he-thong-cua-hang">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Hệ thống cửa hàng</span>
                  </Link>
                </li>
                <li>
                  <Link to="/tuyen-dung">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Tuyển dụng</span>
                  </Link>
                </li>
              </ul>
            </nav>

            {/* Nhóm 4: Đối tác & Xuất khẩu */}
            <nav className="single-footer links sokfarm-footer-group" aria-labelledby="footer-heading-partners">
              <h2 id="footer-heading-partners" className="sokfarm-footer-heading">
                Đối tác &amp; Xuất khẩu
              </h2>
              <ul className="sokfarm-footer-list">
                <li>
                  <Link to="/nguyen-lieu">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Nguyên liệu B2B</span>
                  </Link>
                </li>
                <li>
                  <Link to="/giai-phap-horeca">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Giải pháp HORECA</span>
                  </Link>
                </li>
                <li>
                  <Link to="/export-markets">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Thị trường xuất khẩu</span>
                  </Link>
                </li>
                <li>
                  <Link to="/export-markets#bao-gia-xuat-khau">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Yêu cầu báo giá</span>
                  </Link>
                </li>
                <li>
                  <Link to="/doi-tac/tin-xuat-khau">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Tin Xuất khẩu</span>
                  </Link>
                </li>
              </ul>
            </nav>

            {/* Nhóm 5: Hỗ trợ khách hàng */}
            <nav className="single-footer links sokfarm-footer-group" aria-labelledby="footer-heading-support">
              <h2 id="footer-heading-support" className="sokfarm-footer-heading">
                Hỗ trợ khách hàng
              </h2>
              <ul className="sokfarm-footer-list">
                <li>
                  <Link to="/policy-and-information/chinh-sach-van-chuyen">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Chính sách vận chuyển</span>
                  </Link>
                </li>
                <li>
                  <Link to="/policy-and-information/chinh-sach-doi-tra">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Chính sách đổi trả</span>
                  </Link>
                </li>
                <li>
                  <Link to="/policy-and-information/chinh-sach-thanh-toan">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Chính sách thanh toán</span>
                  </Link>
                </li>
                <li>
                  <Link to="/policy-and-information/chinh-sach-bao-mat">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Chính sách bảo mật</span>
                  </Link>
                </li>
                <li>
                  <Link to="/policy-and-information/chinh-sach-bao-ve-thong-tin-ca-nhan-cua-nguoi-tieu-dung">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Bảo vệ dữ liệu cá nhân</span>
                  </Link>
                </li>
                <li>
                  <Link to="/policy-and-information/quy-dinh-su-dung">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Quy định sử dụng</span>
                  </Link>
                </li>
                <li>
                  <Link to="/contact">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Liên hệ Sokfarm</span>
                  </Link>
                </li>
                <li>
                  <Link to="/user-data-request">
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Yêu cầu dữ liệu cá nhân</span>
                  </Link>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => openCmpModal()}
                    className="sokfarm-footer-privacy-btn"
                  >
                    <i className="ti-angle-right" aria-hidden="true"></i>
                    <span>Cài đặt quyền riêng tư</span>
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>

      {/* Copyright Bar */}
      <div className="copyright sokfarm-footer-copyright">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-12 col-md-7 text-center text-md-left">
              <p className="text-white mb-0">
                Công ty TNHH Trà Vinh Farm (Sokfarm) — Nâng cao giá trị nông sản Việt
              </p>
            </div>
            <div className="col-12 col-md-5 text-center text-md-right mt-1 mt-md-0">
              <p className="text-white mb-0">
                Copyright &copy; 2026 Sokfarm - All Rights Reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
