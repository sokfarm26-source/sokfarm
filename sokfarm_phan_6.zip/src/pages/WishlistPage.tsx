import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { formatVnd, getProductPath } from '../data/siteData';
import { SeoHead } from '../components/SeoHead';

export const WishlistPage: React.FC = () => {
  const { wishlist, addToCart, removeFromWishlist } = useApp();

  return (
    <>
      <SeoHead
        title="Danh sách yêu thích | Sokfarm"
        description="Các sản phẩm mật hoa dừa hữu cơ Sokfarm bạn đã yêu thích."
        canonicalPath="/wishlist"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Danh sách yêu thích', path: '/wishlist' },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to="/wishlist">Danh sách yêu thích</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="shopping-cart section py-5">
        <div className="container">
          {wishlist.length === 0 ? (
            <div className="text-center py-5">
              <h4>Danh sách yêu thích của bạn đang trống!</h4>
              <Link to="/san-pham" className="btn btn-success mt-3 text-white">
                Khám phá sản phẩm Sokfarm
              </Link>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table shopping-summery">
                <thead>
                  <tr className="main-hading">
                    <th>SẢN PHẨM</th>
                    <th>TÊN SẢN PHẨM</th>
                    <th className="text-center">GIÁ</th>
                    <th className="text-center">THÊM GIỎ HÀNG</th>
                    <th className="text-center">XÓA</th>
                  </tr>
                </thead>
                <tbody>
                  {wishlist.map((item) => (
                    <tr key={item.code}>
                      <td className="image">
                        <img
                          src={item.img}
                          alt={item.title}
                          width={80}
                          height={80}
                          loading="lazy"
                          decoding="async"
                          style={{ width: '80px', maxHeight: '80px', objectFit: 'contain' }}
                        />
                      </td>
                      <td className="product-des">
                        <p className="product-name">
                          <Link to={getProductPath(item.slug)}>{item.title}</Link>
                        </p>
                      </td>
                      <td className="price text-center">
                        <span>{formatVnd(item.price)}</span>
                      </td>
                      <td className="text-center">
                        <button
                          type="button"
                          className="btn btn-success text-white"
                          onClick={() =>
                            addToCart({
                              productId: item.productId,
                              code: item.code,
                              slug: item.slug,
                              title: item.title,
                              price: item.price,
                              img: item.img,
                            })
                          }
                        >
                          Thêm vào giỏ
                        </button>
                      </td>
                      <td className="action text-center">
                        <button
                          type="button"
                          className="btn btn-link text-danger"
                          onClick={() => removeFromWishlist(item.code)}
                        >
                          <i className="ti-trash remove-icon"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </>
  );
};
