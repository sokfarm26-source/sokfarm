import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import Swiper from 'swiper';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import { products, getProductPath, resolveCanonicalProductSlug } from '../data/siteData';
import subpagesRaw from '../data/subpages.json';
import { useApp } from '../context/AppContext';
import { SeoHead } from '../components/SeoHead';

const subpages = subpagesRaw as Record<
  'about' | 'sustainable' | 'nguyen_lieu' | 'export_markets' | 'product_list' | 'dsar',
  { html: string; css: string }
>;
type SubpageKey = keyof typeof subpages;

interface SubpageWrapperProps {
  pageKey: SubpageKey;
}

const SUBPAGE_META: Record<
  SubpageKey,
  { title: string; description: string; path: string; breadcrumb: string }
> = {
  about: {
    title: 'Giới thiệu Sokfarm & Câu chuyện thương hiệu | Sokfarm',
    description:
      'Khám phá câu chuyện Công ty TNHH Trà Vinh Farm (Sokfarm) và nghề thu mật hoa dừa truyền thống của người Khmer Trà Vinh.',
    path: '/about-us',
    breadcrumb: 'Giới thiệu Sokfarm',
  },
  sustainable: {
    title: 'Phát triển bền vững (ESG) | Sokfarm',
    description:
      'Mô hình nông nghiệp hạnh phúc, thích nghi biến đổi khí hậu và định hướng phát triển bền vững ESG của Sokfarm.',
    path: '/phat-trien-ben-vung',
    breadcrumb: 'Phát triển bền vững',
  },
  nguyen_lieu: {
    title: 'Nguyên liệu mật hoa dừa hữu cơ & HORECA | Sokfarm',
    description:
      'Cung cấp sỉ nguyên liệu mật hoa dừa hữu cơ, đường hoa dừa, nước tương và giấm mật hoa dừa cho sản xuất F&B và HORECA.',
    path: '/nguyen-lieu',
    breadcrumb: 'Nguyên liệu',
  },
  export_markets: {
    title: 'Đối tác & Thị trường xuất khẩu | Sokfarm',
    description:
      'Sản phẩm mật hoa dừa hữu cơ Sokfarm đạt chuẩn quốc tế và xuất khẩu sang Nhật Bản, Mỹ, châu Âu, Úc, Hàn Quốc.',
    path: '/export-markets',
    breadcrumb: 'Đối tác & Xuất khẩu',
  },
  product_list: {
    title: 'Tất cả sản phẩm mật hoa dừa hữu cơ | Sokfarm',
    description:
      'Khám phá trọn bộ sản phẩm mật hoa dừa hữu cơ Sokfarm: Mật hoa dừa, đường hoa dừa, đồ uống, gia vị hữu cơ, sản phẩm cho bé và quà tặng.',
    path: '/san-pham',
    breadcrumb: 'Sản phẩm',
  },
  dsar: {
    title: 'Yêu cầu quyền dữ liệu cá nhân | Sokfarm',
    description:
      'Biểu mẫu tiếp nhận yêu cầu truy cập, chỉnh sửa và bảo vệ dữ liệu cá nhân khách hàng tại Sokfarm.',
    path: '/user-data-request',
    breadcrumb: 'Yêu cầu dữ liệu cá nhân',
  },
};

const EXPORT_PRODUCT_OPTIONS = [
  'Mật hoa dừa cô đặc hữu cơ Sokfarm',
  'Mật hoa dừa tươi hữu cơ Sokfarm',
  'Đường hoa dừa hữu cơ Sokfarm',
  'Nước tương mật hoa dừa hữu cơ Sokfarm',
  'Giấm mật hoa dừa hữu cơ Sokfarm',
  'Xốt Teriyaki mật hoa dừa hữu cơ Sokfarm',
  'Nhiều dòng sản phẩm / Gia công OEM',
];

const CERTIFICATION_OPTIONS = [
  'USDA Organic',
  'EU Organic',
  'JAS Organic',
  'ISO 22000:2018',
  'FDA',
  'HALAL',
  'HACCP / COA',
];

const ExportQuoteSection: React.FC = () => {
  const { notify } = useApp();
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [productInterest, setProductInterest] = useState('');
  const [importCountry, setImportCountry] = useState('');
  const [quantityValue, setQuantityValue] = useState('');
  const [quantityUnit, setQuantityUnit] = useState('kg');
  const [certRequirements, setCertRequirements] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submittedSummary, setSubmittedSummary] = useState<{
    fullName: string;
    companyName: string;
    email: string;
    website: string;
    productInterest: string;
    importCountry: string;
    quantityDisplay: string;
    certsDisplay: string;
    notes: string;
  } | null>(null);

  const toggleCert = (cert: string) => {
    setCertRequirements((prev) =>
      prev.includes(cert) ? prev.filter((c) => c !== cert) : [...prev, cert]
    );
  };

  const buildQuoteText = (s: NonNullable<typeof submittedSummary>) =>
    [
      'YÊU CẦU BÁO GIÁ XUẤT KHẨU SOKFARM (B2B)',
      `Người liên hệ: ${s.fullName}`,
      s.companyName ? `Doanh nghiệp: ${s.companyName}` : '',
      `Email: ${s.email}`,
      s.website ? `Website: ${s.website}` : '',
      `Sản phẩm quan tâm: ${s.productInterest}`,
      `Thị trường nhập khẩu: ${s.importCountry}`,
      s.quantityDisplay ? `Số lượng dự kiến: ${s.quantityDisplay}` : '',
      s.certsDisplay ? `Yêu cầu chứng nhận: ${s.certsDisplay}` : '',
      '',
      `Ghi chú / Quy cách: ${s.notes}`,
    ]
      .filter(Boolean)
      .join('\n');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};
    if (!fullName.trim()) nextErrors.fullName = 'Vui lòng nhập họ và tên người liên hệ.';
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = 'Vui lòng nhập địa chỉ email hợp lệ.';
    }
    if (!productInterest) nextErrors.productInterest = 'Vui lòng chọn sản phẩm quan tâm.';
    if (!importCountry.trim()) nextErrors.importCountry = 'Vui lòng nhập quốc gia nhập khẩu.';
    if (quantityValue.trim() !== '') {
      const qtyNum = Number(quantityValue);
      if (isNaN(qtyNum) || qtyNum < 0) {
        nextErrors.quantityValue = 'Số lượng dự kiến phải lớn hơn hoặc bằng 0.';
      }
    }
    if (!notes.trim()) nextErrors.notes = 'Vui lòng nhập ghi chú bổ sung hoặc yêu cầu quy cách.';

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      notify('Vui lòng kiểm tra lại các trường thông tin bắt buộc.', 'warning');
      return;
    }

    setErrors({});
    setSubmittedSummary({
      fullName: fullName.trim(),
      companyName: companyName.trim(),
      email: email.trim(),
      website: website.trim(),
      productInterest,
      importCountry: importCountry.trim(),
      quantityDisplay: quantityValue.trim() ? `${quantityValue.trim()} ${quantityUnit}` : '',
      certsDisplay: certRequirements.join(', '),
      notes: notes.trim(),
    });
    notify('Hồ sơ báo giá xuất khẩu đã sẵn sàng gửi tới Sokfarm.', 'success');
  };

  const handleCopyQuote = async () => {
    if (!submittedSummary) return;
    try {
      await navigator.clipboard.writeText(buildQuoteText(submittedSummary));
      notify('Đã sao chép nội dung báo giá B2B.', 'success');
    } catch {
      notify('Không thể tự động sao chép, vui lòng sử dụng nút gửi Email.', 'warning');
    }
  };

  return (
    <section id="bao-gia-xuat-khau" className="contact-us section py-5" style={{ background: '#ffffff' }}>
      <div className="container">
        <div className="contact-head p-3 p-md-5 rounded" id="contact-head-form" style={{ border: '1px solid #d7e6dc' }}>
          <div className="row align-items-center">
            <div className="col-lg-5 text-center mb-4 mb-lg-0">
              <img
                src="/images/opt/sub/sokfarm_leodua2.webp"
                className="w-75"
                width={340}
                height={340}
                alt="Đối tác xuất khẩu Sokfarm"
                loading="lazy"
                decoding="async"
                style={{ maxWidth: '340px', height: 'auto' }}
              />
              <div className="mt-4 text-left p-3 rounded" style={{ background: '#fbf4eb', fontSize: '14px' }}>
                <div className="font-weight-bold web-color-origin mb-1">
                  Hỗ trợ Đối tác B2B &amp; Xuất khẩu
                </div>
                <div className="text-muted">
                  <i className="fa fa-phone mr-2 text-success" aria-hidden="true"></i>Hotline B2B: 0974 038 946
                </div>
                <div className="text-muted mt-1">
                  <i className="fa fa-envelope mr-2 text-success" aria-hidden="true"></i>Email: hello@sokfarm.com
                </div>
                <div className="mt-2">
                  <Link to="/giai-phap-horeca" style={{ color: '#158247', fontWeight: 600 }}>
                    Xem danh mục Giải pháp HORECA &rarr;
                  </Link>
                </div>
              </div>
            </div>

            <div className="col-lg-7">
              <div className="form-main p-0" style={{ boxShadow: 'none' }}>
                <div className="title mb-3">
                  <h2 className="web-color-origin mb-1" style={{ fontSize: '26px' }}>
                    Yêu cầu báo giá xuất khẩu
                  </h2>
                  <p className="text-muted mb-0" style={{ fontSize: '14px' }}>
                    Vui lòng cung cấp thông tin nhu cầu nhập khẩu để đội ngũ kinh doanh quốc tế Sokfarm chuẩn bị hồ sơ và báo giá phù hợp.
                  </p>
                </div>

                {submittedSummary && (
                  <div
                    className="p-3 mb-4 rounded border"
                    role="status"
                    style={{ borderLeft: '4px solid #158247', backgroundColor: '#f7fbf8', borderColor: '#cce2d2' }}
                  >
                    <div className="font-weight-bold mb-1" style={{ color: '#158247' }}>
                      Hồ sơ yêu cầu báo giá đã được tổng hợp (Chưa gửi máy chủ tự động):
                    </div>
                    <p className="mb-2" style={{ fontSize: '13.5px', color: '#333' }}>
                      Cảm ơn <strong>{submittedSummary.fullName}</strong> đã chuẩn bị yêu cầu cho{' '}
                      <strong>{submittedSummary.productInterest}</strong> tại thị trường{' '}
                      <strong>{submittedSummary.importCountry}</strong>. Vui lòng gửi trực tiếp tới bộ phận Xuất khẩu Sokfarm:
                    </p>
                    <div className="d-flex flex-wrap" style={{ gap: '8px' }}>
                      <a
                        href={`mailto:hello@sokfarm.com?subject=${encodeURIComponent(
                          `[B2B Export Quote] ${submittedSummary.productInterest} - ${submittedSummary.importCountry}`
                        )}&body=${encodeURIComponent(buildQuoteText(submittedSummary))}`}
                        className="btn btn-sm btn-success text-white px-3 py-2"
                        style={{ backgroundColor: '#158247', borderColor: '#158247' }}
                      >
                        Gửi Email B2B (hello@sokfarm.com)
                      </a>
                      <button
                        type="button"
                        onClick={handleCopyQuote}
                        className="btn btn-sm btn-outline-success px-3 py-2"
                        style={{ borderColor: '#158247', color: '#158247' }}
                      >
                        Sao chép hồ sơ
                      </button>
                      <a
                        href="tel:0974038946"
                        className="btn btn-sm btn-outline-dark px-3 py-2"
                      >
                        Gọi B2B: 0974 038 946
                      </a>
                    </div>
                  </div>
                )}

                <form className="form-contact form contact_form" onSubmit={handleSubmit} noValidate>
                  <div className="row">
                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteFullName" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Họ và tên <span className="text-danger">*</span>
                        </label>
                        <input
                          id="quoteFullName"
                          type="text"
                          className="form-control"
                          placeholder="Nhập họ và tên của bạn"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        />
                        {errors.fullName && <small className="text-danger">{errors.fullName}</small>}
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteCompany" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Tên công ty
                        </label>
                        <input
                          id="quoteCompany"
                          type="text"
                          className="form-control"
                          placeholder="Tên doanh nghiệp / Đơn vị nhập khẩu"
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        />
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteEmail" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Email <span className="text-danger">*</span>
                        </label>
                        <input
                          id="quoteEmail"
                          type="email"
                          className="form-control"
                          placeholder="example@company.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        />
                        {errors.email && <small className="text-danger">{errors.email}</small>}
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteWebsite" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Website
                        </label>
                        <input
                          id="quoteWebsite"
                          type="text"
                          className="form-control"
                          placeholder="https://website-cong-ty.com"
                          value={website}
                          onChange={(e) => setWebsite(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        />
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteProduct" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Sản phẩm quan tâm <span className="text-danger">*</span>
                        </label>
                        <select
                          id="quoteProduct"
                          className="form-control"
                          value={productInterest}
                          onChange={(e) => setProductInterest(e.target.value)}
                          style={{ height: '48px', borderRadius: '8px', fontSize: '14px' }}
                        >
                          <option value="">-- Chọn sản phẩm quan tâm --</option>
                          {EXPORT_PRODUCT_OPTIONS.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                        {errors.productInterest && (
                          <small className="text-danger">{errors.productInterest}</small>
                        )}
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteCountry" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Quốc gia nhập khẩu <span className="text-danger">*</span>
                        </label>
                        <input
                          id="quoteCountry"
                          type="text"
                          className="form-control"
                          placeholder="Ví dụ: Nhật Bản, Mỹ, Đức, Hà Lan..."
                          value={importCountry}
                          onChange={(e) => setImportCountry(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        />
                        {errors.importCountry && (
                          <small className="text-danger">{errors.importCountry}</small>
                        )}
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label htmlFor="quoteQty" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Số lượng dự kiến
                        </label>
                        <div className="input-group">
                          <input
                            id="quoteQty"
                            type="number"
                            min={0}
                            className="form-control"
                            placeholder="Nhập số lượng"
                            value={quantityValue}
                            onChange={(e) => setQuantityValue(e.target.value)}
                            style={{ borderRadius: '8px 0 0 8px' }}
                          />
                          <div className="input-group-append">
                            <select
                              aria-label="Đơn vị số lượng"
                              className="form-control"
                              value={quantityUnit}
                              onChange={(e) => setQuantityUnit(e.target.value)}
                              style={{ height: '48px', borderRadius: '0 8px 8px 0', minWidth: '95px' }}
                            >
                              <option value="kg">kg</option>
                              <option value="Lít">Lít</option>
                              <option value="Thùng">Thùng</option>
                              <option value="Pallet">Pallet</option>
                              <option value="Container">Container</option>
                            </select>
                          </div>
                        </div>
                        {errors.quantityValue && (
                          <small className="text-danger">{errors.quantityValue}</small>
                        )}
                      </div>
                    </div>

                    <div className="col-lg-6 col-12">
                      <div className="form-group">
                        <label className="font-weight-bold d-block" style={{ fontSize: '13.5px' }}>
                          Yêu cầu chứng nhận
                        </label>
                        <div className="d-flex flex-wrap pt-1" style={{ gap: '8px 14px' }}>
                          {CERTIFICATION_OPTIONS.map((cert) => (
                            <label
                              key={cert}
                              className="d-inline-flex align-items-center mb-0"
                              style={{ cursor: 'pointer', fontSize: '13px', gap: '5px' }}
                            >
                              <input
                                type="checkbox"
                                checked={certRequirements.includes(cert)}
                                onChange={() => toggleCert(cert)}
                              />
                              <span>{cert}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="col-12">
                      <div className="form-group message">
                        <label htmlFor="quoteNotes" className="font-weight-bold" style={{ fontSize: '13.5px' }}>
                          Ghi chú bổ sung <span className="text-danger">*</span>
                        </label>
                        <textarea
                          id="quoteNotes"
                          rows={4}
                          placeholder="Ghi rõ quy cách đóng gói mong muốn, điều kiện giao hàng (FOB/CIF/EXW), hoặc câu hỏi khác..."
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          style={{ borderRadius: '8px' }}
                        ></textarea>
                        {errors.notes && <small className="text-danger">{errors.notes}</small>}
                      </div>
                    </div>

                    <div className="col-12">
                      <div className="form-group button mb-0">
                        <button
                          type="submit"
                          className="btn btn-success px-4 py-2 text-white"
                          style={{ borderRadius: '8px', backgroundColor: '#158247', borderColor: '#158247' }}
                        >
                          Gửi yêu cầu báo giá xuất khẩu
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export const SubpageWrapper: React.FC<SubpageWrapperProps> = ({ pageKey }) => {
  const { addToCart, notify, openCmpModal } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const pageData = subpages[pageKey];
  const seoMeta = SUBPAGE_META[pageKey];

  useEffect(() => {
    if (location.hash) {
      const targetId = location.hash.slice(1);
      const timer = setTimeout(() => {
        const el = document.getElementById(targetId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 120);
      return () => clearTimeout(timer);
    }
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [pageKey, location.hash]);

  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;

    const swiperInstances: Swiper[] = [];
    const initSwiper = (selector: string, options: Record<string, unknown>) => {
      const els = root.querySelectorAll(selector);
      els.forEach((el) => {
        const inst = new Swiper(el as HTMLElement, {
          modules: [Navigation, Pagination, Autoplay],
          ...options,
        });
        swiperInstances.push(inst);
      });
    };

    if (pageKey === 'about') {
      initSwiper('.mySwiperTimeline', {
        slidesPerView: 1,
        autoHeight: true,
        speed: 500,
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        spaceBetween: 30,
        breakpoints: {
          768: { slidesPerView: 3, spaceBetween: 25 },
        },
        on: {
          init(sw: Swiper) {
            const switches = root.querySelectorAll('.swiper-pagination-custom .swiper-pagination-switch');
            switches.forEach((s, idx) => {
              s.classList.toggle('active', idx >= sw.realIndex && idx < sw.realIndex + 3);
            });
          },
          slideChangeTransitionStart(sw: Swiper) {
            const switches = root.querySelectorAll('.swiper-pagination-custom .swiper-pagination-switch');
            switches.forEach((s, idx) => {
              s.classList.toggle('active', idx >= sw.realIndex && idx < sw.realIndex + 3);
            });
          },
        },
      });
      initSwiper('.swiper.timeLineMobile', {
        slidesPerView: 1,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
      });
      initSwiper('.mySwiperStepCollectCoconutFlower', {
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
      });
      initSwiper('.swiper.certi', {
        slidesPerView: 2,
        spaceBetween: 30,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        breakpoints: {
          768: { slidesPerView: 4, spaceBetween: 30 },
          1024: { slidesPerView: 6, spaceBetween: 30 },
        },
      });
      initSwiper('.swiper.news', {
        slidesPerView: 2,
        spaceBetween: 30,
        loop: true,
        autoplay: { delay: 6000, disableOnInteraction: false },
        breakpoints: {
          768: { slidesPerView: 4, spaceBetween: 30 },
          1024: { slidesPerView: 6, spaceBetween: 30 },
        },
      });
      initSwiper('.swiper.reward', {
        spaceBetween: 30,
        slidesPerView: 4,
        slidesPerGroup: 4,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
      });
      initSwiper('.swiper.reward-mobile', {
        spaceBetween: 30,
        slidesPerView: 1,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
      });
    } else if (pageKey === 'nguyen_lieu') {
      initSwiper('.swiper.certificate', {
        spaceBetween: 30,
        slidesPerView: 3,
        slidesPerGroup: 1,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          1024: { slidesPerView: 5 },
        },
      });
      initSwiper('.swiper.product_ingredient', {
        slidesPerView: 1,
        slidesPerGroup: 1,
        loop: true,
        autoplay: { delay: 3000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          768: { slidesPerView: 3, spaceBetween: 20 },
          1024: { slidesPerView: 4, spaceBetween: 20 },
        },
      });
    } else if (pageKey === 'export_markets') {
      initSwiper('.swiper.certificate', {
        spaceBetween: 30,
        slidesPerView: 3,
        slidesPerGroup: 1,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          1024: { slidesPerView: 5 },
        },
      });
      initSwiper('.swiper.product-export', {
        spaceBetween: 30,
        slidesPerView: 2,
        slidesPerGroup: 1,
        loop: true,
        autoplay: { delay: 5000, disableOnInteraction: false },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          768: { slidesPerView: 3 },
          1024: { slidesPerView: 4 },
        },
      });
    } else if (pageKey === 'product_list') {
      initSwiper('.swiper.list-show-cate', {
        slidesPerView: 2,
        spaceBetween: 5,
        loop: true,
        autoplay: { delay: 3000 },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          768: { slidesPerView: 3, spaceBetween: 5 },
          1024: { slidesPerView: 3, spaceBetween: 5 },
        },
      });
      initSwiper('.swiper.feedback-customer', {
        slidesPerView: 1,
        spaceBetween: 5,
        loop: true,
        autoplay: { delay: 5000 },
        breakpoints: {
          768: { slidesPerView: 3, spaceBetween: 5 },
          1024: { slidesPerView: 3, spaceBetween: 5 },
        },
      });
      initSwiper('.swiper.certi', {
        slidesPerView: 2,
        spaceBetween: 5,
        loop: true,
        autoplay: { delay: 3000 },
        breakpoints: {
          640: { slidesPerView: 2, spaceBetween: 20 },
          768: { slidesPerView: 4, spaceBetween: 40 },
          1024: { slidesPerView: 5, spaceBetween: 50 },
        },
      });
      initSwiper('.swiper.product-list', {
        slidesPerView: 2,
        spaceBetween: 5,
        loop: true,
        autoplay: { delay: 4000 },
        navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        breakpoints: {
          768: { slidesPerView: 3, spaceBetween: 15 },
          1024: { slidesPerView: 4, spaceBetween: 20 },
        },
      });
    }

    const onClick = (e: Event) => {
      const target = e.target as HTMLElement;

      const cmpBtn = target.closest('[data-open-cmp="true"]');
      if (cmpBtn) {
        e.preventDefault();
        openCmpModal();
        return;
      }

      const ytBtn = target.closest('.sokfarm-yt-facade') as HTMLElement | null;
      if (ytBtn) {
        e.preventDefault();
        const vidId = ytBtn.getAttribute('data-yt-id');
        const vidTitle = ytBtn.getAttribute('data-yt-title') || 'Video YouTube Sokfarm';
        if (vidId) {
          const iframe = document.createElement('iframe');
          iframe.width = '100%';
          iframe.height = '100%';
          iframe.style.cssText = 'width:100%;height:100%;border:0;display:block;';
          iframe.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(vidId)}?autoplay=1&rel=0`;
          iframe.title = vidTitle;
          iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
          iframe.allowFullscreen = true;
          ytBtn.innerHTML = '';
          ytBtn.appendChild(iframe);
        }
        return;
      }

      const cartBtn = target.closest('.btn-add-to-cart-item, .btn-add-to-cart-item2') as HTMLElement | null;
      if (cartBtn) {
        e.preventDefault();
        const pid = cartBtn.getAttribute('data-product_id') || '';
        const pname = cartBtn.getAttribute('data-product_name') || '';
        const pprice = Number(cartBtn.getAttribute('data-product_price') || 0);
        const found = products.find((p) => p.id === pid || p.title === pname);
        const firstVar = found?.dataProducts?.[0];
        const canonicalSlug = resolveCanonicalProductSlug(found?.slug) || found?.slug || '';
        addToCart({
          productId: pid || found?.id || pname,
          code: firstVar?.code || pid || canonicalSlug || pname,
          slug: canonicalSlug,
          title: pname || found?.title || 'Sản phẩm Sokfarm',
          packaging: firstVar?.attributes,
          price: pprice || found?.price || 0,
          img: found?.defaultImg || '/images/opt/ui/logo_sokfarm2.webp',
        });
        return;
      }

      const catBtn = target.closest(
        '.categories-btn-link-section, .categories-mobile-btn-link-section'
      ) as HTMLElement | null;
      if (catBtn) {
        e.preventDefault();
        const secId = catBtn.getAttribute('data-section_div');
        if (secId) {
          const el = document.getElementById(secId);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        return;
      }

      const esgItem = target.closest('.item_esg') as HTMLElement | null;
      if (esgItem) {
        e.preventDefault();
        root.querySelectorAll('.block_item').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.div_triange').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.block_item_css_img_item').forEach((el) => el.classList.remove('active'));

        esgItem.querySelector('.block_item')?.classList.add('active');
        esgItem.querySelector('.block_item_css_img_item')?.classList.add('active');
        esgItem.querySelector('.div_triange')?.classList.add('active');

        const divsec = esgItem.getAttribute('data-section_div');
        if (divsec) {
          const secEl = document.getElementById(divsec);
          if (secEl) secEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        return;
      }

      const cont = target.closest('.continents') as HTMLElement | null;
      if (cont) {
        root.querySelectorAll('.continents').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.location_country').forEach((el) => el.classList.remove('active'));
        cont.classList.add('active');
        const idLoc = cont.getAttribute('data-id_location');
        if (idLoc) document.getElementById(idLoc)?.classList.add('active');
        return;
      }

      const loc = target.closest('.locations') as HTMLElement | null;
      if (loc) {
        root.querySelectorAll('.continents').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.locations').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.location_country').forEach((el) => el.classList.remove('active'));
        loc.classList.add('active');
        const idLoc = loc.getAttribute('data-id_location');
        const idCont = loc.getAttribute('data-id_continents');
        if (idLoc) document.getElementById(idLoc)?.classList.add('active');
        if (idCont) document.getElementById(idCont)?.classList.add('active');
        return;
      }

      const country = target.closest('.country') as HTMLElement | null;
      if (country) {
        root.querySelectorAll('.country').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.locations').forEach((el) => el.classList.remove('active'));
        country.classList.add('active');
        const idCountry = country.getAttribute('data-id_country');
        if (idCountry) document.getElementById(idCountry)?.classList.add('active');
        return;
      }

      const contMb = target.closest('.continents-mb') as HTMLElement | null;
      if (contMb) {
        root.querySelectorAll('.continents-mb').forEach((el) => el.classList.remove('active'));
        root.querySelectorAll('.location_country-mb').forEach((el) => el.classList.remove('active'));
        contMb.classList.add('active');
        const idLoc = contMb.getAttribute('data-id_location');
        if (idLoc) document.getElementById(idLoc)?.classList.add('active');
        return;
      }

      const contactNow = target.closest('.contact_now_btn');
      if (contactNow) {
        e.preventDefault();
        contactNow.classList.add('active');
        const quoteEl =
          document.getElementById('bao-gia-xuat-khau') || document.getElementById('contact-head-form');
        if (quoteEl) quoteEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }

      const dlBtn = target.closest('.dowload-profile-css');
      if (dlBtn) {
        root.querySelectorAll('.dowload-profile-css').forEach((el) => el.classList.remove('active'));
        dlBtn.classList.add('active');
      }

      const anchor = target.closest('a');
      if (anchor) {
        const href = anchor.getAttribute('href') || '';
        if (href.startsWith('javascript:')) {
          e.preventDefault();
          return;
        }
        if (href.startsWith('#')) {
          e.preventDefault();
          const secEl = document.getElementById(href.slice(1));
          if (secEl) secEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
          return;
        }
        if (href.startsWith('/product-detail/')) {
          e.preventDefault();
          const rawSlug = href.replace('/product-detail/', '').split(/[?#]/)[0];
          navigate(getProductPath(rawSlug));
          return;
        }
        if (href.startsWith('/') && !href.startsWith('//')) {
          e.preventDefault();
          navigate(href);
        }
      }
    };

    const onMouseOver = (e: Event) => {
      const target = e.target as HTMLElement;
      const iconBox = target.closest('.icon-sok-click');
      if (iconBox) {
        iconBox.querySelector('.tyle-dn img')?.classList.add('opacity-cus');
        iconBox.querySelector('.text-icon')?.classList.remove('d-none');
      }
      if (target.closest('.img_center_esg')) {
        root.querySelectorAll('.top10_item').forEach((el) => el.classList.remove('hide-element'));
      }
      if (target.closest('.img_enviromental')) {
        root.querySelectorAll('.item_enviromental').forEach((el) => el.classList.remove('hide-element'));
      }
      if (target.closest('.img_governance')) {
        root.querySelectorAll('.item_governance_go').forEach((el) => el.classList.remove('hide-element'));
      }
    };

    const onMouseOut = (e: Event) => {
      const target = e.target as HTMLElement;
      const iconBox = target.closest('.icon-sok-click');
      if (iconBox) {
        iconBox.querySelector('.tyle-dn img')?.classList.remove('opacity-cus');
        iconBox.querySelector('.text-icon')?.classList.add('d-none');
      }
      if (target.closest('.img_center_esg')) {
        root.querySelectorAll('.top10_item').forEach((el) => el.classList.add('hide-element'));
      }
      if (target.closest('.img_enviromental')) {
        root.querySelectorAll('.item_enviromental').forEach((el) => el.classList.add('hide-element'));
      }
      if (target.closest('.img_governance')) {
        root.querySelectorAll('.item_governance_go').forEach((el) => el.classList.add('hide-element'));
      }
    };

    const onSubmit = (e: Event) => {
      e.preventDefault();
      notify(
        'Biểu mẫu trực tuyến chưa kết nối máy chủ tiếp nhận tự động. Quý khách vui lòng gửi yêu cầu trực tiếp tới hello@sokfarm.com hoặc gọi 0966 243 066.',
        'warning'
      );
    };

    root.addEventListener('click', onClick);
    root.addEventListener('mouseover', onMouseOver);
    root.addEventListener('mouseout', onMouseOut);
    root.addEventListener('submit', onSubmit);

    return () => {
      root.removeEventListener('click', onClick);
      root.removeEventListener('mouseover', onMouseOver);
      root.removeEventListener('mouseout', onMouseOut);
      root.removeEventListener('submit', onSubmit);
      swiperInstances.forEach((sw) => {
        try {
          sw.destroy(true, true);
        } catch {
          // ignore
        }
      });
    };
  }, [pageKey, addToCart, navigate, notify, openCmpModal]);

  return (
    <>
      <SeoHead
        title={seoMeta.title}
        description={seoMeta.description}
        canonicalPath={seoMeta.path}
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: seoMeta.breadcrumb, path: seoMeta.path },
        ]}
      />
      {pageData.css && <style>{pageData.css}</style>}
      <div ref={containerRef} dangerouslySetInnerHTML={{ __html: pageData.html }} />
      {pageKey === 'export_markets' && <ExportQuoteSection />}
    </>
  );
};
