import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { SeoHead } from '../components/SeoHead';
import { latestBlogs, loadAllBlogs } from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { useArticleComments } from '../hooks/useArticleComments';
import { ArticleMetaBar } from '../components/ArticleMetaBar';
import { ArticleCommentsSection } from '../components/ArticleCommentsSection';
import { RelatedArticlesSection } from '../components/RelatedArticlesSection';
import { BlogSidebar } from '../components/BlogSidebar';

const ARTICLE_SLUG = 'vi-ngot-cho-nguoi-an-thuan-chay';
const ARTICLE_PATH = '/vi-ngot-cho-nguoi-an-thuan-chay';
const ARTICLE_TITLE = 'Vị Ngọt Thuần Chay: Lựa Chọn Chất Tạo Ngọt Từ Thực Vật';
const META_DESCRIPTION =
  'Vị ngọt thuần chay có từ đâu? Cùng Sokfarm tìm hiểu cách chọn chất tạo ngọt thực vật, thay thế mật ong và ứng dụng mật hoa dừa cô đặc trong món ăn.';
const COVER_IMAGE = '/images/opt/blogs/vi-ngot-thuan-chay/mon-an-thuan-chay.webp';

const KEYWORDS = [
  'vị ngọt thuần chay',
  'chất tạo ngọt thuần chay',
  'chất tạo ngọt từ thực vật',
  'mật hoa dừa cô đặc Sokfarm',
  'mật ong trong chế độ thuần chay',
];

export const ViNgotThuanChayPage: React.FC = () => {
  const [allBlogs, setAllBlogs] = useState<BlogPost[]>(latestBlogs);
  const { comments, addComment } = useArticleComments(ARTICLE_SLUG);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    let cancelled = false;
    loadAllBlogs().then((all) => {
      if (!cancelled) setAllBlogs(all);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const currentPost = allBlogs.find((b) => b.slug === ARTICLE_SLUG);

  const sidebarKnowledgePosts = allBlogs
    .filter(
      (b) =>
        b.catSlug === 'kien-thuc-mat-hoa-dua' &&
        b.slug !== ARTICLE_SLUG
    )
    .slice(0, 5);

  const breadcrumbs = [
    { name: 'Trang chủ', path: '/' },
    { name: 'Tin tức & Kiến thức', path: '/goc-kham-pha' },
    { name: 'Kiến thức mật hoa dừa', path: '/goc-kham-pha/kien-thuc-mat-hoa-dua' },
    { name: ARTICLE_TITLE, path: ARTICLE_PATH },
  ];

  return (
    <>
      <SeoHead
        title={ARTICLE_TITLE}
        description={META_DESCRIPTION}
        canonicalPath={ARTICLE_PATH}
        image={COVER_IMAGE}
        ogType="article"
        keywords={KEYWORDS}
        breadcrumbs={breadcrumbs}
        articleSchema={{
          schemaType: 'BlogPosting',
          headline: ARTICLE_TITLE,
          image: COVER_IMAGE,
          datePublished: '2026-11-12',
          description: META_DESCRIPTION,
        }}
      />

      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/goc-kham-pha">
                      Tin tức &amp; Kiến thức<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/goc-kham-pha/kien-thuc-mat-hoa-dua">
                      Kiến thức mật hoa dừa<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <span>{ARTICLE_TITLE}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Article Section */}
      <section className="blog-single section" style={{ paddingTop: '40px', paddingBottom: '70px' }}>
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-12">
              <article className="blog-single-main" style={{ marginTop: 0 }}>
                {/* Hình 1: Ảnh đại diện lớn */}
                <figure className="mb-4">
                  <div className="image rounded overflow-hidden">
                    <img
                      src={COVER_IMAGE}
                      alt="Các món ăn thuần chay gồm trái cây, bánh ngọt và nguyên liệu có nguồn gốc thực vật"
                      width={1200}
                      height={800}
                      decoding="async"
                      fetchPriority="high"
                      className="img-fluid w-100"
                      style={{ height: 'auto', display: 'block', borderRadius: '8px' }}
                    />
                  </div>
                  <figcaption
                    className="text-center text-muted mt-2"
                    style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                  >
                    Một phần ăn thuần chay gồm trái cây, bánh, sữa hạt và các nguyên liệu có nguồn gốc thực vật
                  </figcaption>
                </figure>

                <div className="blog-detail">
                  <div className="mb-3">
                    <Link
                      to="/goc-kham-pha/kien-thuc-mat-hoa-dua"
                      className="categories-news-link d-inline-block"
                      style={{ padding: '4px 14px', fontSize: '13px', textDecoration: 'none' }}
                    >
                      Kiến thức mật hoa dừa
                    </Link>
                  </div>

                  <h1
                    className="blog-title web-color-origin"
                    style={{
                      fontSize: 'clamp(24px, 4vw, 32px)',
                      lineHeight: 1.35,
                      marginTop: 0,
                      marginBottom: '14px',
                      textTransform: 'none',
                    }}
                  >
                    {ARTICLE_TITLE}
                  </h1>

                  <ArticleMetaBar
                    author={currentPost?.author || 'Admin'}
                    date={currentPost?.date || '12 Nov, 2026'}
                    commentCount={comments.length}
                    dateFormat="raw"
                  />

                  <div className="content content-post">
                    {/* Sapo / Intro */}
                    <p style={{ lineHeight: 1.75, color: '#333' }}>
                      <strong>Vị ngọt thuần chay</strong> không chỉ đến từ trái cây mà còn có thể
                      được tạo nên từ nhiều nguyên liệu thực vật quen thuộc. Tuy nhiên, khi lựa
                      chọn chế độ ăn thuần chay, không ít người băn khoăn liệu mình có thể tiếp tục
                      thưởng thức bánh ngọt, món tráng miệng hay các loại thức uống yêu thích hay
                      không.
                    </p>
                    <p style={{ lineHeight: 1.75, color: '#333' }}>
                      Thực tế, người ăn thuần chay vẫn có thể thưởng thức nhiều món ngọt hấp dẫn
                      nếu lựa chọn nguyên liệu phù hợp. Vậy vì sao một số món ngọt thông thường không
                      đáp ứng chế độ ăn thuần chay và đâu là những chất tạo ngọt có nguồn gốc thực
                      vật? Hãy cùng Sokfarm tìm hiểu ngay sau đây!
                    </p>

                    {/* Section 1 */}
                    <section className="mb-5">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        1. Vì sao một số món ngọt không phù hợp với người ăn thuần chay?
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Chế độ ăn thuần chay (vegan) loại trừ các thực phẩm có nguồn gốc động vật
                        như thịt, cá, trứng, sữa và mật ong. Vì vậy, ngoài việc lựa chọn món ăn
                        chính, người ăn thuần chay cũng cần chú ý đến thành phần của bánh, kẹo và
                        các món tráng miệng.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Một số món ngọt thông thường sử dụng trứng, bơ, sữa hoặc gelatin có nguồn
                        gốc động vật để tạo hương vị và kết cấu. Chẳng hạn, trứng có thể giúp bánh
                        có độ xốp, trong khi bơ và sữa thường được dùng để tạo độ béo.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Đặc biệt, <strong>mật ong cũng không được xem là nguyên liệu thuần chay</strong>{' '}
                        vì đây là sản phẩm do ong tạo ra. Do đó, người theo chế độ thuần chay thường
                        lựa chọn các chất tạo ngọt từ thực vật để thay thế mật ong trong chế biến
                        món ăn.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Tuy nhiên, không phải món ngọt nào cũng chứa nguyên liệu động vật. Hiện nay,
                        người ăn thuần chay có thể sử dụng nhiều nguyên liệu khác nhau để chế biến
                        bánh, thức uống và món tráng miệng phù hợp với nhu cầu của mình.
                      </p>
                    </section>

                    {/* Section 2 */}
                    <section className="mb-5">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        2. Những chất tạo ngọt từ thực vật phù hợp với người ăn thuần chay
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Để tạo vị ngọt cho món ăn mà không sử dụng nguyên liệu có nguồn gốc động
                        vật, bạn có thể lựa chọn các chất tạo ngọt từ thực vật như đường mía, đường
                        thốt nốt, đường chà là, đường hoa dừa hoặc mật hoa dừa cô đặc.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Mỗi nguyên liệu có hương vị và đặc điểm riêng, phù hợp với những cách chế
                        biến khác nhau.
                      </p>

                      {/* 2.1 */}
                      <h3 className="mt-4 mb-2" style={{ fontSize: '19px', color: '#158247' }}>
                        2.1. Đường mía và đường thốt nốt
                      </h3>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Đường mía là nguyên liệu tạo ngọt quen thuộc trong nhiều gia đình, thường
                        được sử dụng khi nấu ăn, pha chế và làm bánh.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Trong khi đó, đường thốt nốt có màu sắc và hương thơm đặc trưng, thường
                        xuất hiện trong các món chè, bánh và món ăn truyền thống.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Cả hai đều có nguồn gốc từ thực vật. Tuy nhiên, với sản phẩm đường chế biến
                        sẵn, người ăn thuần chay nghiêm ngặt có thể cần tìm hiểu thêm về quy trình
                        sản xuất nếu có sử dụng chất hỗ trợ chế biến từ động vật.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/blogs/vi-ngot-thuan-chay/duong-mia-va-duong-thot-not.webp"
                          alt="Đường mía và đường thốt nốt là những chất tạo ngọt có nguồn gốc thực vật"
                          width={1080}
                          height={720}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Đường mía và đường thốt nốt với các dạng hạt, viên và đường thô
                        </figcaption>
                      </figure>

                      {/* 2.2 */}
                      <h3 className="mt-4 mb-2" style={{ fontSize: '19px', color: '#158247' }}>
                        2.2. Đường la hán quả
                      </h3>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Đường la hán quả</strong> là sản phẩm tạo ngọt có thành phần chiết
                        xuất từ quả la hán, một loại quả có nguồn gốc thực vật. Vị ngọt của la hán
                        quả chủ yếu đến từ các hợp chất tự nhiên gọi là mogroside.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Trên thị trường, đường la hán quả thường được sử dụng để pha trà, cà phê
                        hoặc chế biến một số món ăn và món tráng miệng. Tùy từng sản phẩm, đường la
                        hán quả có thể được phối trộn với những thành phần khác để tạo dạng hạt và
                        điều chỉnh độ ngọt.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Vì vậy, người ăn thuần chay nên kiểm tra bảng thành phần trước khi sử dụng
                        và điều chỉnh lượng dùng theo hướng dẫn của sản phẩm.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/blogs/vi-ngot-thuan-chay/duong-la-han-qua.webp"
                          alt="Quả la hán và đường la hán quả dạng hạt dùng làm chất tạo ngọt thực vật"
                          width={1080}
                          height={720}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Quả la hán và đường la hán quả dạng hạt
                        </figcaption>
                      </figure>

                      {/* 2.3 */}
                      <h3 className="mt-4 mb-2" style={{ fontSize: '19px', color: '#158247' }}>
                        2.3. Mật hoa dừa cô đặc – Vị ngọt thuần chay từ hoa dừa
                      </h3>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Bên cạnh các loại đường dạng hạt, <strong>mật hoa dừa cô đặc</strong> là một
                        lựa chọn tạo ngọt có nguồn gốc thực vật với kết cấu dạng sánh và hương vị đặc
                        trưng.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Mật hoa dừa cô đặc hữu cơ Sokfarm được chế biến từ mật thu ở cụm hoa dừa.
                        Theo thông tin thương hiệu công bố, sản phẩm có thành phần 100% mật hoa dừa
                        hữu cơ, không bổ sung đường tinh luyện hoặc chất bảo quản.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Nhờ nguồn gốc thực vật, sản phẩm có thể được sử dụng trong nhiều công thức
                        thuần chay, chẳng hạn:
                      </p>
                      <ul
                        className="mb-3 pl-4"
                        style={{ listStyle: 'disc', lineHeight: 1.8, color: '#333' }}
                      >
                        <li>Pha trà trái cây, nước me và các loại thức uống.</li>
                        <li>Tạo ngọt cho sữa hạt hoặc sinh tố.</li>
                        <li>Kết hợp với yến mạch, trái cây và món tráng miệng.</li>
                        <li>Sử dụng trong một số công thức làm bánh và nước sốt.</li>
                      </ul>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Khi thay mật ong hoặc đường cát bằng mật hoa dừa cô đặc, bạn nên điều chỉnh
                        lượng dùng theo khẩu vị vì mỗi nguyên liệu có hương vị, độ ngọt và kết cấu
                        khác nhau.
                      </p>

                      <figure className="my-4">
                        <img
                          src="/images/opt/blogs/vi-ngot-thuan-chay/mat-hoa-dua-co-dac-sokfarm.webp"
                          alt="Chai mật hoa dừa cô đặc hữu cơ Sokfarm được sử dụng làm chất tạo ngọt thuần chay"
                          width={1080}
                          height={724}
                          loading="lazy"
                          decoding="async"
                          className="img-fluid rounded w-100"
                          style={{ height: 'auto', display: 'block' }}
                        />
                        <figcaption
                          className="text-center text-muted mt-2"
                          style={{ fontSize: '13.5px', fontStyle: 'italic' }}
                        >
                          Mật hoa dừa cô đặc hữu cơ Sokfarm từ vùng dừa Trà Vinh
                        </figcaption>
                      </figure>
                    </section>

                    {/* Section 3 */}
                    <section className="mb-5">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        3. Chất tạo ngọt thuần chay có tốt cho sức khỏe hơn không?
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Nhiều người cho rằng các chất tạo ngọt có nguồn gốc tự nhiên hoặc thực vật
                        luôn tốt cho sức khỏe hơn đường thông thường. Tuy nhiên,{' '}
                        <strong>
                          nguồn gốc thực vật không đồng nghĩa với việc sản phẩm không chứa đường
                          hoặc ít năng lượng
                        </strong>
                        .
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Chẳng hạn, mật hoa dừa cô đặc và các loại đường từ thực vật vẫn có thể cung
                        cấp đường và calo. Vì vậy, khi lựa chọn chất tạo ngọt, người tiêu dùng cần
                        quan tâm đến thành phần, khẩu phần sử dụng và nhu cầu dinh dưỡng của bản
                        thân.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Một số sản phẩm có thể được giới thiệu với thông tin về chỉ số đường huyết
                        (GI) hoặc hàm lượng khoáng chất. Tuy nhiên, những chỉ số này cần có kết quả
                        kiểm nghiệm phù hợp với từng sản phẩm và không đủ để kết luận một chất tạo
                        ngọt có thể phòng ngừa hoặc điều trị bệnh đái tháo đường.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Vì thế, dù lựa chọn đường mía, đường thốt nốt hay mật hoa dừa cô đặc, bạn
                        vẫn nên sử dụng với lượng hợp lý trong chế độ ăn cân đối.
                      </p>
                    </section>

                    {/* Section 4 */}
                    <section className="mb-5">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        4. Gợi ý sử dụng mật hoa dừa cô đặc trong món ăn thuần chay
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Nếu muốn thử một nguyên liệu tạo ngọt mới, bạn có thể bắt đầu với mật hoa
                        dừa cô đặc Sokfarm trong những món ăn và thức uống quen thuộc.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Pha chế thức uống:</strong> Thêm một lượng mật hoa dừa cô đặc vừa đủ
                        vào trà trái cây, nước me hoặc các loại thức uống yêu thích.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Kết hợp với sữa hạt:</strong> Sử dụng mật hoa dừa cô đặc để tạo ngọt
                        cho sữa đậu nành, sữa yến mạch hoặc các loại sữa hạt không chứa nguyên liệu
                        động vật.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Dùng cùng món ăn sáng:</strong> Kết hợp mật hoa dừa cô đặc với yến
                        mạch, trái cây hoặc bánh mì để thay đổi hương vị.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        <strong>Chế biến món tráng miệng:</strong> Thử sử dụng mật hoa dừa cô đặc
                        trong các công thức bánh và món tráng miệng thuần chay, đồng thời điều chỉnh
                        lượng nguyên liệu lỏng khi cần.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Nếu yêu thích các thức uống chua ngọt, bạn có thể tham khảo bài viết{' '}
                        <Link
                          to="/4-cach-lam-da-me-voi-mat-hoa-dua-co-dac"
                          style={{ color: '#158247', fontWeight: 700, textDecoration: 'underline' }}
                        >
                          “4 Cách Làm Đá Me Với Mật Hoa Dừa Cô Đặc Sokfarm Tại Nhà”
                        </Link>{' '}
                        để khám phá thêm cách sử dụng mật hoa dừa trong pha chế.
                      </p>
                    </section>

                    {/* Section 5 + CTA */}
                    <section className="mb-4">
                      <h2
                        className="web-color-origin mb-3"
                        style={{ fontSize: '23px', lineHeight: 1.4 }}
                      >
                        5. Khám phá “Vị ngọt thuần chay từ hoa dừa” cùng Sokfarm
                      </h2>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Chế độ ăn thuần chay không có nghĩa là phải từ bỏ những món ngọt yêu thích.
                        Với các nguyên liệu tạo ngọt có nguồn gốc thực vật, bạn vẫn có thể chế biến
                        nhiều món bánh, thức uống và món tráng miệng theo khẩu vị của mình.
                      </p>
                      <p style={{ lineHeight: 1.75, color: '#333' }}>
                        Thông qua chiến dịch <strong>“Vị ngọt thuần chay từ hoa dừa”</strong>,
                        Sokfarm mong muốn giới thiệu đến người tiêu dùng một lựa chọn tạo ngọt từ
                        thực vật, đồng thời gợi mở những cách ứng dụng mật hoa dừa cô đặc hữu cơ
                        trong các món ăn và thức uống hằng ngày.
                      </p>

                      {/* Product CTA Box */}
                      <div
                        className="p-4 rounded my-4 d-flex flex-column flex-md-row align-items-md-center justify-content-between"
                        style={{
                          backgroundColor: '#f3f9f5',
                          border: '1px solid #cce3d4',
                          gap: '16px',
                        }}
                      >
                        <div>
                          <div
                            className="web-color-origin font-weight-bold mb-1"
                            style={{ fontSize: '18px' }}
                          >
                            Mật hoa dừa cô đặc organic Sokfarm
                          </div>
                          <p className="mb-0" style={{ fontSize: '14.5px', color: '#444' }}>
                            100% mật hoa dừa hữu cơ từ Trà Vinh, không bổ sung đường tinh luyện hay
                            chất bảo quản — lựa chọn tạo ngọt thuần thực vật cho thực đơn hằng ngày.
                          </p>
                        </div>
                        <Link
                          to="/san-pham/mat-hoa-dua-co-dac-huu-co"
                          className="btn text-white flex-shrink-0"
                          style={{
                            backgroundColor: '#158247',
                            borderColor: '#158247',
                            padding: '12px 20px',
                            fontWeight: 600,
                            borderRadius: '6px',
                            whiteSpace: 'normal',
                            textAlign: 'center',
                          }}
                        >
                          Khám phá mật hoa dừa cô đặc hữu cơ Sokfarm
                        </Link>
                      </div>

                      <p className="mb-0" style={{ lineHeight: 1.75, color: '#333', fontWeight: 600 }}>
                        Bạn đã từng sử dụng chất tạo ngọt thuần chay nào? Hãy chia sẻ trải nghiệm
                        của mình và cùng Sokfarm khám phá thêm những cách kết hợp vị ngọt từ hoa dừa
                        nhé!
                      </p>
                    </section>
                  </div>
                </div>
              </article>

              <ArticleCommentsSection comments={comments} onAddComment={addComment} />

              <RelatedArticlesSection
                currentSlug={ARTICLE_SLUG}
                catSlug="kien-thuc-mat-hoa-dua"
                posts={allBlogs}
              />
            </div>

            {/* Sidebar */}
            <BlogSidebar
              recentPosts={sidebarKnowledgePosts}
              recentTitle="Tin Mới"
              activeCategorySlug="kien-thuc-mat-hoa-dua"
            />
          </div>
        </div>
      </section>
    </>
  );
};
