import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { STORE_DIRECTORY, STORE_REGIONS, normalizeExternalHref } from '../data/storeData';
import type { StoreRegionKey } from '../types/sokfarm';
import { SeoHead } from '../components/SeoHead';

export const StoreListPage: React.FC = () => {
  const [activeRegion, setActiveRegion] = useState<StoreRegionKey>('hcm_stores');
  const [openDistricts, setOpenDistricts] = useState<Record<string, boolean>>({});
  const [selectedDistrictKey, setSelectedDistrictKey] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, []);

  const handleSelectRegion = (regionKey: StoreRegionKey) => {
    setActiveRegion(regionKey);
    setSelectedDistrictKey(null);
  };

  const toggleDistrict = (key: string) => {
    setSelectedDistrictKey(key);
    setOpenDistricts((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const currentDistricts = STORE_DIRECTORY[activeRegion] || [];
  const activeRegionLabel = STORE_REGIONS.find((r) => r.key === activeRegion)?.label || '';

  return (
    <>
      <SeoHead
        title="Hệ thống cửa hàng | Sokfarm"
        description="Hệ thống cửa hàng, đại lý và kênh bán hàng trực tuyến chính hãng các sản phẩm Mật hoa dừa hữu cơ Sokfarm."
        canonicalPath="/he-thong-cua-hang"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Hệ thống cửa hàng', path: '/he-thong-cua-hang' },
        ]}
      />

      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <Link to="/he-thong-cua-hang">Hệ thống cửa hàng</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="shop-blog grid py-4 pb-5">
        <div className="container">
          <div className="mb-4">
            <h1 className="web-color-origin mb-1" style={{ fontSize: '28px' }}>
              Hệ thống cửa hàng
            </h1>
            <p className="text-muted mb-0" style={{ fontSize: '14.5px' }}>
              Chọn khu vực và phường/tỉnh thành để xem danh sách điểm bán sản phẩm mật hoa dừa hữu cơ Sokfarm.
            </p>
          </div>

          <div className="row align-items-start">
            {/* Cột bên trái: 4 lựa chọn khu vực */}
            <div className="col-lg-3 col-12 mb-4 mb-lg-0">
              <div className="main-sidebar" style={{ marginTop: 0 }}>
                <div className="d-flex flex-column" style={{ gap: '10px' }} role="tablist" aria-label="Khu vực cửa hàng">
                  {STORE_REGIONS.map((reg) => {
                    const isActive = activeRegion === reg.key;
                    return (
                      <button
                        key={reg.key}
                        type="button"
                        role="tab"
                        aria-selected={isActive}
                        onClick={() => handleSelectRegion(reg.key)}
                        className="w-100 text-left d-flex align-items-center justify-content-between"
                        style={{
                          backgroundColor: isActive ? '#edf7f1' : '#f9f9f9',
                          border: isActive ? '1.5px solid #158247' : '1px solid #eeeeee',
                          color: isActive ? '#158247' : '#333333',
                          padding: '13px 15px',
                          borderRadius: '6px',
                          fontSize: '15.5px',
                          fontWeight: isActive ? 700 : 500,
                          cursor: 'pointer',
                          transition: 'all 0.2s ease',
                        }}
                      >
                        <span>{reg.label}</span>
                        {isActive && <i className="fa fa-angle-right" aria-hidden="true"></i>}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Cột bên phải: Danh sách khu vực / phường & điểm bán tương ứng */}
            <div className="col-lg-9 col-12">
              <div
                className="list-district bg-white rounded"
                style={{
                  padding: '20px',
                  border: '1px solid #e5ece7',
                }}
              >
                <div className="d-flex flex-wrap align-items-center justify-content-between pb-3 mb-3 border-bottom">
                  <h2 className="web-color-origin mb-0" style={{ fontSize: '20px' }}>
                    {activeRegionLabel}
                  </h2>
                  <span className="text-muted" style={{ fontSize: '13.5px' }}>
                    {currentDistricts.length > 0
                      ? `${currentDistricts.length} khu vực`
                      : 'Đang cập nhật'}
                  </span>
                </div>

                {currentDistricts.length === 0 ? (
                  <div className="text-center py-5 text-muted">
                    Đang cập nhật danh sách điểm bán
                  </div>
                ) : (
                  currentDistricts.map((dist, idx) => {
                    const dKey = `${activeRegion}-${idx}`;
                    const isOpen = !!openDistricts[dKey];
                    const isSelected = selectedDistrictKey === dKey && isOpen;
                    return (
                      <div key={dKey} className="mb-2">
                        <button
                          type="button"
                          aria-expanded={isOpen}
                          onClick={() => toggleDistrict(dKey)}
                          className="district-item w-100 d-flex justify-content-between align-items-center text-left"
                          style={{
                            backgroundColor: isSelected ? '#edf7f1' : '#f9f9f9',
                            border: isSelected ? '1px solid #158247' : '1px solid #f0f0f0',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            padding: '11px 14px',
                            color: isSelected ? '#158247' : '#333333',
                            fontWeight: isSelected ? 600 : 400,
                            transition: 'all 0.2s ease',
                          }}
                        >
                          <span className="district mb-0" style={{ fontSize: '14.5px' }}>
                            {dist.district}
                          </span>
                          <i
                            className={`fa fa-chevron-${isOpen ? 'down' : 'right'}`}
                            style={{ color: '#158247', fontSize: '12px' }}
                            aria-hidden="true"
                          ></i>
                        </button>

                        {isOpen && (
                          <div className="scroll-list px-2 px-md-3 py-2 bg-white border border-top-0 rounded-bottom">
                            {!dist.stores || dist.stores.length === 0 ? (
                              <p className="mb-0 py-3 text-center text-muted" style={{ fontSize: '14px' }}>
                                Đang cập nhật danh sách điểm bán
                              </p>
                            ) : (
                              dist.stores.map((st, sIdx) => {
                                const safeHref = normalizeExternalHref(st.href);
                                const safeMaps = normalizeExternalHref(st.mapsUrl);
                                return (
                                  <div
                                    key={sIdx}
                                    className={`address-item row py-3 align-items-center ${
                                      sIdx < dist.stores.length - 1 ? 'border-bottom' : ''
                                    }`}
                                  >
                                    <div className={activeRegion === 'online' ? 'col-3 col-sm-2 col-md-1 text-center' : 'col-3 col-sm-2 text-center'}>
                                      <img
                                        className="store-img"
                                        alt={st.name || 'Biểu tượng cửa hàng Sokfarm'}
                                        src={st.img || '/images/logo_sokfarm.svg'}
                                        width={48}
                                        height={48}
                                        loading="lazy"
                                        decoding="async"
                                        style={{
                                          height: '46px',
                                          width: '46px',
                                          objectFit: 'contain',
                                        }}
                                      />
                                    </div>
                                    <div className={activeRegion === 'online' ? 'col-9 col-sm-10 col-md-11' : 'col-9 col-sm-10'}>
                                      {safeHref ? (
                                        <p className="mb-0" style={{ wordBreak: 'break-word' }}>
                                          <a
                                            href={safeHref}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            style={{ color: '#158247', fontWeight: 600 }}
                                          >
                                            {st.name || safeHref}
                                            <i className="fa fa-external-link ml-2" aria-hidden="true"></i>
                                          </a>
                                        </p>
                                      ) : (
                                        <div>
                                          <p className="mb-1" style={{ color: '#000', fontWeight: 700, fontSize: '15px' }}>
                                            {st.name || 'Đang cập nhật tên cửa hàng'}
                                          </p>
                                          {st.address && (
                                            <p className="mb-1 text-muted" style={{ fontSize: '14px' }}>
                                              <i className="fa fa-map-marker mr-2 text-success" aria-hidden="true"></i>
                                              {st.address}
                                            </p>
                                          )}
                                          {st.phone && (
                                            <p className="mb-1" style={{ fontSize: '14px' }}>
                                              <i className="fa fa-phone mr-2 text-success" aria-hidden="true"></i>
                                              <a href={`tel:${st.phone.replace(/\s+/g, '')}`} style={{ color: '#158247' }}>
                                                {st.phone}
                                              </a>
                                            </p>
                                          )}
                                          {safeMaps && (
                                            <p className="mb-1" style={{ fontSize: '13.5px' }}>
                                              <a
                                                href={safeMaps}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                style={{ color: '#158247', fontWeight: 600 }}
                                              >
                                                <i className="fa fa-map-o mr-1" aria-hidden="true"></i>
                                                Xem trên Google Maps
                                              </a>
                                            </p>
                                          )}
                                          {st.extra?.map((ex, eIdx) => (
                                            <p key={eIdx} className="mb-0 text-muted" style={{ fontSize: '13.5px' }}>
                                              {ex}
                                            </p>
                                          ))}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
