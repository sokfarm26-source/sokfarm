import { useState, useEffect, useCallback } from 'react';

export interface ArticleComment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

const COMMENTS_STORAGE_KEY = 'sokfarm_article_comments_v1';
const COMMENTS_SYNC_EVENT = 'sokfarm-article-comments-updated';

function readCommentsMap(): Record<string, ArticleComment[]> {
  try {
    const raw = localStorage.getItem(COMMENTS_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function useArticleComments(slug: string) {
  const [comments, setComments] = useState<ArticleComment[]>(() => {
    if (!slug) return [];
    const map = readCommentsMap();
    return Array.isArray(map[slug]) ? map[slug] : [];
  });

  useEffect(() => {
    if (!slug) {
      setComments([]);
      return;
    }
    const sync = () => {
      const map = readCommentsMap();
      setComments(Array.isArray(map[slug]) ? map[slug] : []);
    };
    sync();
    window.addEventListener(COMMENTS_SYNC_EVENT, sync);
    return () => window.removeEventListener(COMMENTS_SYNC_EVENT, sync);
  }, [slug]);

  const addComment = useCallback(
    (author: string, text: string) => {
      const cleanText = text.trim();
      if (!slug || !cleanText) return false;
      const now = new Date();
      const dd = String(now.getDate()).padStart(2, '0');
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const yyyy = now.getFullYear();
      const hh = String(now.getHours()).padStart(2, '0');
      const min = String(now.getMinutes()).padStart(2, '0');

      const entry: ArticleComment = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        author: author.trim() || 'Khách hàng',
        text: cleanText,
        createdAt: `${dd}/${mm}/${yyyy} ${hh}:${min}`,
      };

      const map = readCommentsMap();
      const prevList = Array.isArray(map[slug]) ? map[slug] : [];
      const nextList = [entry, ...prevList];
      map[slug] = nextList;
      try {
        localStorage.setItem(COMMENTS_STORAGE_KEY, JSON.stringify(map));
      } catch {
        // Ignore storage quota errors
      }
      setComments(nextList);
      window.dispatchEvent(new Event(COMMENTS_SYNC_EVENT));
      return true;
    },
    [slug]
  );

  return { comments, addComment };
}
