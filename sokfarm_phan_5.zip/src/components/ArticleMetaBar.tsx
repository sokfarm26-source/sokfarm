import React from 'react';
import { formatBlogDateVi } from '../data/siteData';

interface ArticleMetaBarProps {
  author?: string;
  date?: string;
  commentCount: number;
  commentsTargetId?: string;
  dateFormat?: 'vi' | 'raw';
}

export const ArticleMetaBar: React.FC<ArticleMetaBarProps> = ({
  author,
  date,
  commentCount,
  commentsTargetId = 'comments',
  dateFormat = 'vi',
}) => {
  const cleanDate = date?.trim() || '';
  const cleanAuthor = author?.trim() || '';
  const formattedDate = cleanDate
    ? dateFormat === 'raw'
      ? cleanDate
      : formatBlogDateVi(cleanDate)
    : '';

  const handleScrollToComments = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const target = document.getElementById(commentsTargetId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="blog-meta sokfarm-blog-meta">
      <div className="author d-flex flex-wrap align-items-center">
        {cleanAuthor && (
          <>
            <span className="sokfarm-meta-item">
              <i className="fa fa-user" aria-hidden="true"></i>{' '}
              {cleanAuthor === 'Admin' ? 'By Admin' : cleanAuthor}
            </span>
            <span className="sokfarm-meta-sep" aria-hidden="true">|</span>
          </>
        )}
        {formattedDate && (
          <>
            <span className="sokfarm-meta-item">
              <i className="fa fa-calendar" aria-hidden="true"></i> {formattedDate}
            </span>
            <span className="sokfarm-meta-sep" aria-hidden="true">|</span>
          </>
        )}
        <a
          href={`#${commentsTargetId}`}
          onClick={handleScrollToComments}
          className="sokfarm-meta-item sokfarm-meta-link"
        >
          <i className="fa fa-comments" aria-hidden="true"></i> Comment ({commentCount})
        </a>
      </div>
    </div>
  );
};
