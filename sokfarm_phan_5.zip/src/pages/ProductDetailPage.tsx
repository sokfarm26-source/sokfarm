import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate, Navigate } from 'react-router-dom';
import {
  products,
  B2C_CATEGORIES,
  formatVnd,
  resolveCanonicalProductSlug,
  getProductPath,
  getPrimaryCategoryForProduct,
  getCategoryPath,
  isB2BProduct,
} from '../data/siteData';
import { useApp } from '../context/AppContext';
import { ProductCard } from '../components/ProductCard';
import { SeoHead } from '../components/SeoHead';

const productDetailCache = new Map<string, { shortHtml: string; descHtml: string }>();

export const ProductDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { addToCart, toggleWishlist, wishlist, notify } = useApp();

  const directProduct = products.find((p) => p.slug === slug);
  const canonicalFallback = !directProduct ? resolveCanonicalProductSlug(slug) : null;

  const [selectedVariantIdx, setSelectedVariantIdx] = useState(0);
  const [activeImgIdx, setActiveImgIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [hoveredIcon, setHoveredIcon] = useState<number | null>(null);
  const [detailContent, setDetailContent] = useState<{ shortHtml: string; descHtml: string } | null>(
    () => (directProduct ? productDetailCache.get(directProduct.slug) || null : null)
  );
  const descRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setSelectedVariantIdx(0);
    setActiveImgIdx(0);
    setQuantity(1);
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });

    if (!directProduct) {
      setDetailContent(null);
      return;
    }
    if (directProduct.descHtml || directProduct.shortHtml) {
      const existing = { shortHtml: directProduct.shortHtml, descHtml: directProduct.descHtml };
      productDetailCache.set(directProduct.slug, existing);
      setDetailContent(existing);
      return;
    }
    const cached = productDetailCache.get(directProduct.slug);
    if (cached) {
      setDetailContent(cached);
      return;
    }
    let cancelled = false;
    setDetailContent(null);
    fetch(`/data/products/${encodeURIComponent(directProduct.slug)}.json`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { shortHtml?: string; descHtml?: string } | null) => {
        if (cancelled || !data) return;
        const payload = {
          shortHtml: data.shortHtml || '',
          descHtml: data.descHtml || '',
        };
        productDetailCache.set(directProduct.slug, payload);
        setDetailContent(payload);
      })
      .catch(() => {
        // fallback stays empty gracefully
      });
    return () => {
      cancelled = true;
    };
  }, [slug, directProduct]);

  const product = directProduct;
  const shortHtml = detailContent?.shortHtml ?? product?.shortHtml ?? '';
  const descHtml = detailContent?.descHtml ?? product?.descHtml ?? '';

  // Wire interactive elements inside raw descHtml (YouTube facade, .buynow scroll, review form submit, internal links)
  useEffect(() => {
    const container = descRef.current;
    if (!container || !product) return;

    const handleClick = (e: Event) => {
      const target = e.target as HTMLElement;
      const ytBtn = target.closest('.sokfarm-yt-facade') as HTMLElement | null;
      if (ytBtn) {
        e.preventDefault();
        const vidId = ytBtn.getAttribute('data-yt-id');
        const vidTitle = ytBtn.getAttribute('data-yt-title') || 'Video YouTube Sokfarm';
        if (vidId) {
          const iframe = document.createElement('iframe');
          iframe.width = '100%';
          iframe.height = '100%';
          iframe.style.cssText = 'width:100%;height:100%;border:0;display:block;';
          iframe.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(vidId)}?autoplay=1&rel=0`;
          iframe.title = vidTitle;
          iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
          iframe.allowFullscreen = true;
          ytBtn.innerHTML = '';
          ytBtn.appendChild(iframe);
        }
        return;
      }
      const anchor = target.closest('a');
      if (anchor) {
        const href = anchor.getAttribute('href') || '';
        if (href === '#' || href.trim() === '') {
          e.preventDefault();
          return;
        }
        if (href.startsWith('#')) {
          e.preventDefault();
          const targetId = href.slice(1);
          const targetEl = document.getElementById(targetId);
          if (targetEl) {
            targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
          return;
        }
        if (href.startsWith('/product-detail/')) {
          e.preventDefault();
          const rawSlug = href.replace('/product-detail/', '').split(/[?#]/)[0];
          navigate(getProductPath(rawSlug));
          return;
        }
        if (href.startsWith('/')) {
          e.preventDefault();
          navigate(href);
          return;
        }
      }
      if (target.closest('.buynow') || target.closest('.buynowmobile')) {
        e.preventDefault();
        const el = document.getElementById('id_scroll_to');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      if (target.closest('.submitFormComment')) {
        e.preventDefault();
        notify(
          'Biểu mẫu đánh giá chưa kết nối máy chủ tiếp nhận tự động. Quý khách vui lòng gửi góp ý về hello@sokfarm.com.',
          'warning'
        );
      }
    };

    const handleSubmit = (e: Event) => {
      e.preventDefault();
      notify(
        'Biểu mẫu đánh giá chưa kết nối máy chủ tiếp nhận tự động. Quý khách vui lòng gửi góp ý về hello@sokfarm.com.',
        'warning'
      );
    };

    container.addEventListener('click', handleClick);
    container.addEventListener('submit', handleSubmit);
    return () => {
      container.removeEventListener('click', handleClick);
      container.removeEventListener('submit', handleSubmit);
    };
  }, [product, navigate, notify]);

  if (!directProduct && canonicalFallback) {
    return <Navigate to={getProductPath(canonicalFallback)} replace />;
  }

  if (!product) {
    return (
      <>
        <SeoHead
          title="Không tìm thấy sản phẩm - Sokfarm"
          description="Sản phẩm bạn đang tìm kiếm không tồn tại hoặc đã được di chuyển."
          canonicalPath="/san-pham"
          breadcrumbs={[
            { name: 'Trang chủ', path: '/' },
            { name: 'Sản phẩm', path: '/san-pham' },
            { name: 'Không tìm thấy sản phẩm', path: `/san-pham/${slug || ''}` },
          ]}
        />
        <div className="breadcrumbs">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="bread-inner">
                  <ul className="bread-list">
                    <li>
                      <Link to="/">
                        Trang chủ<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                    <li>
                      <Link to="/san-pham">
                        Sản phẩm<i className="ti-arrow-right"></i>
                      </Link>
                    </li>
                    <li className="active">
                      <span>Không tìm thấy sản phẩm</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <section className="section py-5">
          <div className="container text-center py-5">
            <h1 className="web-color-origin mb-3" style={{ fontSize: '28px' }}>
              Không tìm thấy sản phẩm (404)
            </h1>
            <p className="mb-4">Sản phẩm bạn tìm kiếm hiện không tồn tại hoặc đường dẫn đã được cập nhật.</p>
            <Link to="/san-pham" className="btn btn-success text-white px-4 py-2">
              Xem tất cả sản phẩm Sokfarm
            </Link>
          </div>
        </section>
      </>
    );
  }

  const activeVariant = product.dataProducts?.[selectedVariantIdx] || product.dataProducts?.[0];
  const galleryImages =
    activeVariant?.images && activeVariant.images.length > 0
      ? activeVariant.images
      : product.gallery && product.gallery.length > 0
      ? product.gallery
      : [product.defaultImg];

  const currentPrice = activeVariant
    ? Number(activeVariant.selling_price || activeVariant.price || 0)
    : product.price;

  const isInWishlist = activeVariant
    ? wishlist.some((w) => w.code === activeVariant.code)
    : false;

  const handleAddToCart = (buyNow = false) => {
    if (!product.hasCartBtn || currentPrice === 0) {
      navigate('/contact');
      return;
    }
    const code = activeVariant?.code || product.id || product.slug;
    addToCart(
      {
        productId: product.id || code,
        code,
        slug: product.slug,
        title: product.title,
        packaging: activeVariant?.attributes,
        price: currentPrice,
        img: galleryImages[0] || product.defaultImg,
      },
      quantity
    );
    if (buyNow) {
      navigate('/dat-hang');
    }
  };

  const handleToggleWishlist = () => {
    if (!activeVariant) {
      notify('Sản phẩm không thể thêm yêu thích', 'warning');
      return;
    }
    toggleWishlist({
      productId: product.id || activeVariant.code,
      code: activeVariant.code,
      slug: product.slug,
      title: product.title,
      price: currentPrice,
      img: galleryImages[0] || product.defaultImg,
    });
  };

  const relatedProducts = products
    .filter((p) => product.relatedSlugs?.includes(p.slug) && p.slug !== product.slug)
    .slice(0, 4);

  const pillars = [
    { icon: '/images/icon_sok1.svg', label: 'Sản phẩm hữu cơ', w: '100%' },
    { icon: '/images/icon_sok2.svg', label: 'Sinh kế bền vững', w: '100%' },
    { icon: '/images/icon_sok3.svg', label: 'Thích nghi biến đổi khí hậu', w: '100%' },
    { icon: '/images/icon_sok4.svg', label: 'Thuần chay', w: '100%' },
    { icon: '/images/icon_sok5.svg', label: 'Nghề truyền thống', w: '100%' },
    { icon: '/images/icon_sok6.svg', label: 'Hương vị phù sa', w: '80%' },
  ];

  const canonicalPath = getProductPath(product.slug);
  const primaryCat = getPrimaryCategoryForProduct(product);
  const parentCat = primaryCat?.parentSlug
    ? B2C_CATEGORIES.find((c) => c.slug === primaryCat.parentSlug)
    : null;

  const breadcrumbItems = [
    { name: 'Trang chủ', path: '/' },
    ...(primaryCat?.isB2B
      ? [{ name: 'Đối tác & Xuất khẩu', path: '/export-markets' }]
      : [{ name: 'Sản phẩm', path: '/san-pham' }]),
    ...(parentCat ? [{ name: parentCat.name, path: getCategoryPath(parentCat.slug) }] : []),
    ...(primaryCat ? [{ name: primaryCat.name, path: getCategoryPath(primaryCat.slug) }] : []),
    { name: product.title, path: canonicalPath },
  ];

  return (
    <>
      <SeoHead
        title={`${product.title} | Sokfarm`}
        description={`${product.title} - Sản phẩm mật hoa dừa hữu cơ Sokfarm. Giá: ${product.priceText}.`}
        canonicalPath={canonicalPath}
        image={galleryImages[0] || product.defaultImg}
        breadcrumbs={breadcrumbItems}
        productSchema={{
          name: product.title,
          price: currentPrice,
          image: galleryImages[0] || product.defaultImg,
          sku: activeVariant?.code || product.id || product.slug,
        }}
      />

      {/* Breadcrumbs */}
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  {breadcrumbItems.map((bc, idx) => {
                    const isLast = idx === breadcrumbItems.length - 1;
                    return (
                      <li key={bc.path + idx} className={isLast ? 'active' : undefined}>
                        <Link to={bc.path}>
                          {bc.name}
                          {!isLast && <i className="ti-arrow-right"></i>}
                        </Link>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* End Breadcrumbs */}

      {/* Shop Single */}
      <section className="shop single section py-3">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="row">
                <div className="col-lg-5 col-12">
                  {/* Product Slider */}
                  <div className="product-gallery">
                    <div id="sliderFlex" className="flexslider" style={{ position: 'relative' }}>
                      <ul className="slides">
                        <li style={{ display: 'block', width: '100%' }}>
                          <img
                            src={galleryImages[activeImgIdx] || galleryImages[0]}
                            alt={
                              galleryImages.length > 1 && activeImgIdx > 0
                                ? `${product.title} - Góc chụp ${activeImgIdx + 1}`
                                : product.title
                            }
                            width={460}
                            height={460}
                            fetchPriority="high"
                            style={{ width: '100%', maxHeight: '460px', objectFit: 'contain' }}
                          />
                        </li>
                      </ul>
                      {galleryImages.length > 1 && (
                        <>
                          <button
                            type="button"
                            aria-label="Ảnh sản phẩm trước"
                            onClick={() =>
                              setActiveImgIdx(
                                (i) => (i - 1 + galleryImages.length) % galleryImages.length
                              )
                            }
                            style={{
                              position: 'absolute',
                              left: '8px',
                              top: '50%',
                              transform: 'translateY(-50%)',
                              background: 'rgba(21,130,71,0.75)',
                              color: '#fff',
                              border: 'none',
                              width: '34px',
                              height: '34px',
                              borderRadius: '50%',
                              cursor: 'pointer',
                            }}
                          >
                            <i className="fa fa-chevron-left" aria-hidden="true"></i>
                          </button>
                          <button
                            type="button"
                            aria-label="Ảnh sản phẩm tiếp theo"
                            onClick={() =>
                              setActiveImgIdx((i) => (i + 1) % galleryImages.length)
                            }
                            style={{
                              position: 'absolute',
                              right: '8px',
                              top: '50%',
                              transform: 'translateY(-50%)',
                              background: 'rgba(21,130,71,0.75)',
                              color: '#fff',
                              border: 'none',
                              width: '34px',
                              height: '34px',
                              borderRadius: '50%',
                              cursor: 'pointer',
                            }}
                          >
                            <i className="fa fa-chevron-right" aria-hidden="true"></i>
                          </button>
                        </>
                      )}
                    </div>

                    {galleryImages.length > 1 && (
                      <div id="carouselFlex" className="flexslider mt-2">
                        <ul className="slides d-flex flex-wrap" style={{ gap: '6px' }}>
                          {galleryImages.map((imgUrl, idx) => (
                            <li
                              key={idx}
                              style={{
                                width: '80px',
                                height: '80px',
                                border:
                                  activeImgIdx === idx ? '2px solid #158247' : '1px solid #ddd',
                                borderRadius: '4px',
                                overflow: 'hidden',
                              }}
                            >
                              <button
                                type="button"
                                aria-label={`Xem ${product.title} ảnh ${idx + 1}`}
                                onClick={() => setActiveImgIdx(idx)}
                                style={{
                                  padding: 0,
                                  border: 0,
                                  width: '100%',
                                  height: '100%',
                                  background: 'transparent',
                                  cursor: 'pointer',
                                  display: 'block',
                                }}
                              >
                                <img
                                  src={imgUrl}
                                  width={80}
                                  height={80}
                                  loading="lazy"
                                  decoding="async"
                                  alt={`${product.title} - Góc chụp ${idx + 1}`}
                                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                                />
                              </button>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* 6 Icons */}
                  <div className="row my-3 d-none d-md-flex">
                    {pillars.map((pil, idx) => (
                      <div
                        key={idx}
                        className="col-2 col-md-2 icon-sok-click"
                        style={{ position: 'relative' }}
                        onMouseEnter={() => setHoveredIcon(idx)}
                        onMouseLeave={() => setHoveredIcon(null)}
                      >
                        <div className="rounded-circle bg-white tyle-dn text-center p-2">
                          <img
                            src={pil.icon}
                            width={48}
                            height={48}
                            loading="lazy"
                            className={hoveredIcon === idx ? 'opacity-cus' : ''}
                            style={{ width: pil.w, height: 'auto' }}
                            alt={pil.label}
                          />
                        </div>
                        {hoveredIcon === idx && (
                          <div
                            className="text-icon text-center"
                            style={{
                              fontSize: '11px',
                              color: '#158247',
                              fontWeight: 700,
                              marginTop: '4px',
                            }}
                          >
                            {pil.label}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="col-lg-7 col-12">
                  <div className="product-des">
                    <div className="short">
                      <h1 className="web-color-origin" style={{ fontSize: '26px', lineHeight: 1.35 }}>
                        {product.title}
                      </h1>
                      <div className="rating-main">
                        <ul className="rating">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <li key={s}>
                              <i className="fa fa-star" aria-hidden="true"></i>
                            </li>
                          ))}
                        </ul>
                        <button
                          type="button"
                          className="total-review btn btn-link p-0 border-0"
                          style={{ color: '#333', fontSize: '14px', cursor: 'pointer', textDecoration: 'underline' }}
                          onClick={() => {
                            const rev = document.getElementById('reviews');
                            if (rev) rev.scrollIntoView({ behavior: 'smooth' });
                          }}
                        >
                          ({product.reviewCount}) Đánh giá
                        </button>
                      </div>

                      <p className="selling-price mt-3 mb-3">
                        <span className="price-show mr-2 price" style={{ fontVariantNumeric: 'tabular-nums' }}>
                          {currentPrice > 0 && !isB2BProduct(product) ? formatVnd(currentPrice) : 'Liên hệ báo giá B2B'}
                        </span>
                      </p>
                    </div>

                    {/* Product Buy (Prioritized above short highlights for fast conversion) */}
                    <div className="product-buy mt-2 mb-3" id="id_scroll_to">
                      {product.dataProducts && product.dataProducts.length > 0 && (
                        <div className="size d-flex align-items-center flex-wrap mb-3">
                          <h6 className="mr-3 mb-1">Phân loại / Quy cách:</h6>
                          <div className="d-flex flex-wrap">
                            {product.dataProducts.map((v, idx) => (
                              <button
                                key={v.code}
                                type="button"
                                id={`attr-${v.code}`}
                                aria-pressed={selectedVariantIdx === idx}
                                style={{
                                  cursor: 'pointer',
                                  padding: '6px 14px',
                                  minHeight: '38px',
                                  borderRadius: '6px',
                                  border:
                                    selectedVariantIdx === idx
                                      ? '1.5px solid #158247'
                                      : '1px solid #ccc',
                                  backgroundColor:
                                    selectedVariantIdx === idx ? '#158247' : '#fff',
                                  color: selectedVariantIdx === idx ? '#fff' : '#333',
                                  fontWeight: selectedVariantIdx === idx ? 600 : 400,
                                }}
                                className={`variant m-1 attr ${
                                  selectedVariantIdx === idx ? 'active' : ''
                                }`}
                                onClick={() => {
                                  setSelectedVariantIdx(idx);
                                  setActiveImgIdx(0);
                                }}
                              >
                                {v.attributes}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {!isB2BProduct(product) && product.hasCartBtn && currentPrice > 0 ? (
                        <div>
                          <div className="quantity">
                            <label htmlFor="quantity" className="font-weight-bold d-block mb-1" style={{ fontSize: '14px' }}>
                              Số lượng:
                            </label>
                            <div className="input-group qty">
                              <div className="button minus">
                                <button
                                  type="button"
                                  aria-label="Giảm số lượng"
                                  className="btn btn-primary btn-number btn-number-minus"
                                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                                >
                                  <i className="ti-minus" aria-hidden="true"></i>
                                </button>
                              </div>
                              <input
                                type="text"
                                name="quant"
                                aria-label="Số lượng sản phẩm"
                                className="input-number"
                                value={quantity}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value, 10);
                                  if (!isNaN(val) && val >= 1 && val <= 100) setQuantity(val);
                                }}
                                id="quantity"
                              />
                              <div className="button plus">
                                <button
                                  type="button"
                                  aria-label="Tăng số lượng"
                                  className="btn btn-primary btn-number btn-number-plus"
                                  onClick={() => setQuantity((q) => Math.min(100, q + 1))}
                                >
                                  <i className="ti-plus" aria-hidden="true"></i>
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className="add-to-cart mt-3 d-flex flex-wrap align-items-center" style={{ gap: '8px' }}>
                            <button
                              type="button"
                              onClick={() => handleAddToCart(false)}
                              className="add-button p-3"
                            >
                              Thêm vào giỏ hàng
                            </button>
                            <button
                              type="button"
                              onClick={() => handleAddToCart(true)}
                              className="add-button buy-now p-3"
                            >
                              MUA NGAY
                            </button>
                            <button
                              type="button"
                              id="wishlist"
                              aria-label="Thêm vào danh sách yêu thích"
                              onClick={handleToggleWishlist}
                              className="btn p-3"
                              style={{
                                border: '1px solid #158247',
                                color: isInWishlist ? '#fff' : '#158247',
                                backgroundColor: isInWishlist ? '#158247' : '#fff',
                              }}
                              title="Yêu thích"
                            >
                              <i className={`fa ${isInWishlist ? 'fa-heart' : 'fa-heart-o'}`} aria-hidden="true"></i>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-3 d-flex flex-wrap" style={{ gap: '10px' }}>
                          <Link
                            to="/export-markets#bao-gia-xuat-khau"
                            className="btn px-4 py-3 text-white font-weight-bold"
                            style={{ backgroundColor: '#158247', borderRadius: '6px' }}
                          >
                            Yêu cầu báo giá B2B / Nguyên liệu
                          </Link>
                          <Link
                            to="/contact"
                            className="btn px-4 py-3 font-weight-bold"
                            style={{
                              border: '1.5px solid #158247',
                              color: '#158247',
                              backgroundColor: '#fff',
                              borderRadius: '6px',
                            }}
                          >
                            Liên hệ tư vấn (0974 038 946)
                          </Link>
                        </div>
                      )}
                    </div>

                    <hr
                      style={
                        product.slug === 'mat-hoa-dua-co-dac-huu-co'
                          ? {
                              border: 0,
                              borderTop: '1.5px solid #158247',
                              background: 'transparent',
                              opacity: 1,
                              margin: '18px 0',
                            }
                          : { background: '#158247' }
                      }
                    />

                    {shortHtml && (
                      <div className="short">
                        <div
                          className={`description mb-0 pb-0${
                            product.slug === 'mat-hoa-dua-co-dac-huu-co'
                              ? ' mat-hoa-dua-co-dac-short'
                              : ''
                          }`}
                          dangerouslySetInnerHTML={{ __html: shortHtml }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Structured Reference Strip (Verified Policies, Origin & Certifications) */}
      <section className="py-3" style={{ backgroundColor: '#fbf4eb', borderTop: '1px solid #ece0d0', borderBottom: '1px solid #ece0d0' }}>
        <div className="container">
          <div className="row" style={{ rowGap: '12px' }}>
            <div className="col-lg-3 col-sm-6">
              <div className="p-3 bg-white rounded h-100 border" style={{ borderColor: '#e4eadc' }}>
                <div className="font-weight-bold mb-1" style={{ color: '#158247', fontSize: '14px' }}>
                  <i className="fa fa-map-marker mr-2" aria-hidden="true"></i>
                  Nguồn gốc Trà Vinh
                </div>
                <p className="mb-0" style={{ fontSize: '13px', color: '#4a554e', lineHeight: 1.55 }}>
                  100% nguyên liệu dừa hữu cơ vùng Trà Vinh, sản xuất tại Công ty TNHH Trà Vinh Farm (Sokfarm).
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-sm-6">
              <div className="p-3 bg-white rounded h-100 border" style={{ borderColor: '#e4eadc' }}>
                <div className="font-weight-bold mb-1" style={{ color: '#158247', fontSize: '14px' }}>
                  <i className="fa fa-certificate mr-2" aria-hidden="true"></i>
                  Chứng nhận quốc tế
                </div>
                <p className="mb-0" style={{ fontSize: '13px', color: '#4a554e', lineHeight: 1.55 }}>
                  Đạt chuẩn USDA Organic, EU Organic, JAS Organic, ISO 22000:2018, FDA, HALAL, OCOP 5 Sao.
                </p>
              </div>
            </div>
            <div className="col-lg-3 col-sm-6">
              <div className="p-3 bg-white rounded h-100 border" style={{ borderColor: '#e4eadc' }}>
                <div className="font-weight-bold mb-1" style={{ color: '#158247', fontSize: '14px' }}>
                  <i className="fa fa-truck mr-2" aria-hidden="true"></i>
                  Giao hàng toàn quốc
                </div>
                <p className="mb-1" style={{ fontSize: '13px', color: '#4a554e', lineHeight: 1.55 }}>
                  Miễn phí vận chuyển đơn từ 1.000.000đ. TP.HCM, Hà Nội, Đà Nẵng 1–2 ngày; tỉnh khác 3–5 ngày.
                </p>
                <Link to="/policy-and-information/chinh-sach-van-chuyen" style={{ color: '#158247', fontSize: '12.5px', fontWeight: 600 }}>
                  Xem chính sách giao hàng &rarr;
                </Link>
              </div>
            </div>
            <div className="col-lg-3 col-sm-6">
              <div className="p-3 bg-white rounded h-100 border" style={{ borderColor: '#e4eadc' }}>
                <div className="font-weight-bold mb-1" style={{ color: '#158247', fontSize: '14px' }}>
                  <i className="fa fa-shield mr-2" aria-hidden="true"></i>
                  Hỗ trợ &amp; Đổi trả
                </div>
                <p className="mb-1" style={{ fontSize: '13px', color: '#4a554e', lineHeight: 1.55 }}>
                  Kiểm tra hàng khi nhận, hỗ trợ đổi trả theo chính sách công ty. Hotline: 0966 243 066.
                </p>
                <Link to="/policy-and-information/chinh-sach-doi-tra" style={{ color: '#158247', fontSize: '12.5px', fontWeight: 600 }}>
                  Xem chính sách đổi trả &rarr;
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Extracted Full Description, How-To-Use, Specs & Reviews */}
      <div id="product-full-description" ref={descRef} dangerouslySetInnerHTML={{ __html: descHtml }} />

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div className="product-area most-popular related-product section py-5">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="section-title">
                  <h2>Sản phẩm liên quan</h2>
                </div>
              </div>
            </div>
            <div className="row">
              {relatedProducts.map((rp) => (
                <ProductCard key={rp.slug} product={rp} variant="home" />
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
