import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  products,
  B2C_CATEGORIES,
  latestBlogs,
  loadAllBlogs,
  formatBlogDateVi,
  getProductVolumeBuckets,
  getProductPriceRange,
  matchesPriceBucket,
  matchesUsageBucket,
  normalizeTextVi,
  type VolumeFilterBucket,
  type PriceFilterBucket,
  type UsageFilterBucket,
} from '../data/siteData';
import type { BlogPost } from '../types/sokfarm';
import { ProductCard } from '../components/ProductCard';
import { SeoHead } from '../components/SeoHead';

export const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = (searchParams.get('searchInfo') || searchParams.get('search') || '').trim();
  const [localQuery, setLocalQuery] = useState(initialQuery);
  const [activeTab, setActiveTab] = useState<'products' | 'news'>('products');
  const [blogs, setBlogs] = useState<BlogPost[]>(latestBlogs);

  const [catFilter, setCatFilter] = useState<string>('all');
  const [volumeFilter, setVolumeFilter] = useState<VolumeFilterBucket>('all');
  const [priceFilter, setPriceFilter] = useState<PriceFilterBucket>('all');
  const [usageFilter, setUsageFilter] = useState<UsageFilterBucket>('all');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc'>('default');

  useEffect(() => {
    setLocalQuery(initialQuery);
  }, [initialQuery]);

  useEffect(() => {
    let cancelled = false;
    loadAllBlogs().then((all) => {
      if (!cancelled) setBlogs(all);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const effectiveQuery = localQuery.trim();
  const qNorm = normalizeTextVi(effectiveQuery);

  const matchedProducts = useMemo(() => {
    let list = products.filter((p) => {
      if (qNorm) {
        const attrStr = (p.dataProducts || []).map((v) => v.attributes).join(' ');
        const matchText =
          normalizeTextVi(p.title).includes(qNorm) ||
          normalizeTextVi(p.slug).includes(qNorm) ||
          normalizeTextVi(attrStr).includes(qNorm);
        if (!matchText) return false;
      }
      if (catFilter !== 'all') {
        const cat = B2C_CATEGORIES.find((c) => c.slug === catFilter);
        if (cat && !cat.productSlugs?.includes(p.slug)) return false;
      }
      if (volumeFilter !== 'all' && !getProductVolumeBuckets(p).includes(volumeFilter)) return false;
      if (!matchesPriceBucket(p, priceFilter)) return false;
      if (!matchesUsageBucket(p, usageFilter)) return false;
      return true;
    });

    if (sortBy === 'price-asc') {
      list = [...list].sort((a, b) => getProductPriceRange(a).min - getProductPriceRange(b).min);
    } else if (sortBy === 'price-desc') {
      list = [...list].sort((a, b) => getProductPriceRange(b).min - getProductPriceRange(a).min);
    }
    return list;
  }, [qNorm, catFilter, volumeFilter, priceFilter, usageFilter, sortBy]);

  const matchedBlogs = useMemo(() => {
    if (!qNorm) return blogs;
    return blogs.filter(
      (b) =>
        normalizeTextVi(b.title).includes(qNorm) ||
        normalizeTextVi(b.excerpt).includes(qNorm) ||
        normalizeTextVi(b.cat).includes(qNorm)
    );
  }, [blogs, qNorm]);

  const handleSearchForm = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams(localQuery.trim() ? { searchInfo: localQuery.trim() } : {});
  };

  return (
    <>
      <SeoHead
        title={effectiveQuery ? `Tìm kiếm: ${effectiveQuery} | Sokfarm` : 'Tìm kiếm sản phẩm | Sokfarm'}
        description="Tìm kiếm và lọc sản phẩm, bài viết kiến thức mật hoa dừa hữu cơ Sokfarm."
        canonicalPath="/product/search"
        breadcrumbs={[
          { name: 'Trang chủ', path: '/' },
          { name: 'Tìm kiếm', path: '/product/search' },
        ]}
      />
      <div className="breadcrumbs">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="bread-inner">
                <ul className="bread-list">
                  <li>
                    <Link to="/">
                      Trang chủ<i className="ti-arrow-right" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li className="active">
                    <span>Tìm kiếm sản phẩm &amp; bài viết</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="product-area shop-sidebar shop-list shop section py-4">
        <div className="container">
          <div className="text-center mb-4">
            <h1 className="web-color-origin mb-2" style={{ fontSize: '28px' }}>
              {effectiveQuery ? `Kết quả tìm kiếm cho: "${effectiveQuery}"` : 'Tìm kiếm & Lọc sản phẩm Sokfarm'}
            </h1>
            <form onSubmit={handleSearchForm} className="mx-auto mt-3" style={{ maxWidth: '540px' }}>
              <div className="input-group">
                <input
                  type="text"
                  aria-label="Từ khóa tìm kiếm"
                  className="form-control"
                  value={localQuery}
                  onChange={(e) => setLocalQuery(e.target.value)}
                  placeholder="Nhập tên sản phẩm, dung tích hoặc chủ đề bài viết..."
                  style={{ height: '44px', borderColor: '#cddbd2' }}
                />
                <div className="input-group-append">
                  <button
                    type="submit"
                    className="btn btn-success text-white px-4"
                    style={{ backgroundColor: '#158247', borderColor: '#158247', fontWeight: 600 }}
                  >
                    Tìm kiếm
                  </button>
                </div>
              </div>
            </form>
          </div>

          <div className="d-flex my-4 justify-content-center" style={{ gap: '12px' }}>
            <button
              type="button"
              className={`btn btn-product-tab ${activeTab === 'products' ? 'active' : ''}`}
              style={{
                border: '1px solid #158247',
                backgroundColor: activeTab === 'products' ? '#158247' : '#fff',
                color: activeTab === 'products' ? '#fff' : '#158247',
                minHeight: '42px',
                fontWeight: 600,
              }}
              onClick={() => setActiveTab('products')}
            >
              Sản phẩm ({matchedProducts.length})
            </button>
            <button
              type="button"
              className={`btn btn-product-tab ${activeTab === 'news' ? 'active' : ''}`}
              style={{
                border: '1px solid #158247',
                backgroundColor: activeTab === 'news' ? '#158247' : '#fff',
                color: activeTab === 'news' ? '#fff' : '#158247',
                minHeight: '42px',
                fontWeight: 600,
              }}
              onClick={() => setActiveTab('news')}
            >
              Tin tức &amp; Kiến thức ({matchedBlogs.length})
            </button>
          </div>

          {activeTab === 'products' ? (
            <>
              <div
                className="p-3 rounded mb-4"
                style={{ backgroundColor: '#fbf4eb', border: '1px solid #d7e6dc' }}
              >
                <div className="row" style={{ rowGap: '10px' }}>
                  <div className="col-6 col-md-3">
                    <label htmlFor="search-cat-filter" className="font-weight-bold mb-1 d-block" style={{ fontSize: '12.5px', color: '#158247' }}>
                      Loại sản phẩm
                    </label>
                    <select
                      id="search-cat-filter"
                      className="form-control form-control-sm"
                      value={catFilter}
                      onChange={(e) => setCatFilter(e.target.value)}
                      style={{ minHeight: '38px' }}
                    >
                      <option value="all">Tất cả loại</option>
                      {B2C_CATEGORIES.filter((c) => c.slug !== 'mat-hoa-dua').map((c) => (
                        <option key={c.slug} value={c.slug}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-6 col-md-2">
                    <label htmlFor="search-vol-filter" className="font-weight-bold mb-1 d-block" style={{ fontSize: '12.5px', color: '#158247' }}>
                      Dung tích
                    </label>
                    <select
                      id="search-vol-filter"
                      className="form-control form-control-sm"
                      value={volumeFilter}
                      onChange={(e) => setVolumeFilter(e.target.value as VolumeFilterBucket)}
                      style={{ minHeight: '38px' }}
                    >
                      <option value="all">Tất cả</option>
                      <option value="small">Nhỏ (&lt; 300ml/g)</option>
                      <option value="medium">Vừa (300ml – 1L/kg)</option>
                      <option value="large">Lớn / Combo</option>
                    </select>
                  </div>
                  <div className="col-6 col-md-2">
                    <label htmlFor="search-price-filter" className="font-weight-bold mb-1 d-block" style={{ fontSize: '12.5px', color: '#158247' }}>
                      Khoảng giá
                    </label>
                    <select
                      id="search-price-filter"
                      className="form-control form-control-sm"
                      value={priceFilter}
                      onChange={(e) => setPriceFilter(e.target.value as PriceFilterBucket)}
                      style={{ minHeight: '38px' }}
                    >
                      <option value="all">Tất cả giá</option>
                      <option value="under-100k">Dưới 100.000đ</option>
                      <option value="100k-300k">100.000đ – 300.000đ</option>
                      <option value="over-300k">Trên 300.000đ</option>
                    </select>
                  </div>
                  <div className="col-6 col-md-3">
                    <label htmlFor="search-usage-filter" className="font-weight-bold mb-1 d-block" style={{ fontSize: '12.5px', color: '#158247' }}>
                      Nhu cầu sử dụng
                    </label>
                    <select
                      id="search-usage-filter"
                      className="form-control form-control-sm"
                      value={usageFilter}
                      onChange={(e) => setUsageFilter(e.target.value as UsageFilterBucket)}
                      style={{ minHeight: '38px' }}
                    >
                      <option value="all">Mọi nhu cầu</option>
                      <option value="ban-chay-nhat">Bán chạy nhất</option>
                      <option value="dung-pha-che">Dùng pha chế</option>
                      <option value="dung-nau-an">Dùng nấu ăn</option>
                      <option value="cho-be">Cho bé</option>
                      <option value="qua-tang">Làm quà tặng</option>
                    </select>
                  </div>
                  <div className="col-12 col-md-2">
                    <label htmlFor="search-sort" className="font-weight-bold mb-1 d-block" style={{ fontSize: '12.5px', color: '#158247' }}>
                      Sắp xếp
                    </label>
                    <select
                      id="search-sort"
                      className="form-control form-control-sm"
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as 'default' | 'price-asc' | 'price-desc')}
                      style={{ minHeight: '38px' }}
                    >
                      <option value="default">Mặc định</option>
                      <option value="price-asc">Giá tăng dần</option>
                      <option value="price-desc">Giá giảm dần</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="row product-info-search">
                <div className="col-12">
                  {matchedProducts.length === 0 ? (
                    <div className="text-center py-5 bg-white rounded border" style={{ borderColor: '#d7e6dc' }}>
                      <p className="mb-3">Không tìm thấy sản phẩm phù hợp với điều kiện lọc.</p>
                      <button
                        type="button"
                        onClick={() => {
                          setLocalQuery('');
                          setCatFilter('all');
                          setVolumeFilter('all');
                          setPriceFilter('all');
                          setUsageFilter('all');
                          setSortBy('default');
                          setSearchParams({});
                        }}
                        className="btn btn-outline-success"
                      >
                        Đặt lại tìm kiếm &amp; bộ lọc
                      </button>
                    </div>
                  ) : (
                    <div className="row">
                      {matchedProducts.map((prod) => (
                        <ProductCard key={prod.slug} product={prod} variant="grid" showSpecsAndActions={true} />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="row news-info-search">
              {matchedBlogs.length === 0 ? (
                <div className="col-12 text-center py-5">Không tìm thấy bài viết phù hợp.</div>
              ) : (
                matchedBlogs.slice(0, 48).map((post) => (
                  <div key={post.slug} className="col-lg-4 col-md-6 col-12 mb-4">
                    <Link to={`/tin-tuc/${post.slug}`} className="text-decoration-none d-block h-100">
                      <article className="shop-single-blog h-100 bg-white rounded border p-2" style={{ borderColor: '#e5ece7' }}>
                        <div>
                          <img
                            src={post.img}
                            alt={post.imgAlt || post.title}
                            width={360}
                            height={220}
                            loading="lazy"
                            decoding="async"
                            style={{ borderRadius: '8px', height: '220px', objectFit: 'cover', width: '100%' }}
                          />
                        </div>
                        <div className="content py-3 px-2">
                          <div className="web-color-origin mb-2" style={{ fontSize: '13px' }}>
                            <i className="fa fa-calendar mr-1" aria-hidden="true"></i> {formatBlogDateVi(post.date)}
                          </div>
                          <h2 className="web-color-origin font-weight-bold mb-0" style={{ fontSize: '16px', lineHeight: 1.4 }}>
                            {post.title}
                          </h2>
                        </div>
                      </article>
                    </Link>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </section>
    </>
  );
};
