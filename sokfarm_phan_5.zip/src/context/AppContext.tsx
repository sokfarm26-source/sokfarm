import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { CartItem, WishlistItem, DemoUser, ToastMessage } from '../types/sokfarm';

interface AppContextValue {
  cart: CartItem[];
  wishlist: WishlistItem[];
  user: DemoUser | null;
  lang: 'vi' | 'en';
  toasts: ToastMessage[];
  cmpBannerVisible: boolean;
  cmpModalOpen: boolean;
  setLang: (l: 'vi' | 'en') => void;
  addToCart: (item: Omit<CartItem, 'quantity'>, qty?: number) => void;
  updateCartQty: (productId: string, code: string, qty: number) => void;
  setItemQtyInCart: (item: Omit<CartItem, 'quantity'>, qty: number) => void;
  removeFromCart: (productId: string, code: string) => void;
  clearCart: () => void;
  toggleWishlist: (item: WishlistItem) => boolean;
  removeFromWishlist: (code: string) => void;
  loginDemo: (email: string, name?: string) => void;
  logoutDemo: () => void;
  notify: (text: string, type?: 'success' | 'warning' | 'error') => void;
  openCmpModal: () => void;
  closeCmpModal: () => void;
  saveCmpConsent: () => void;
  cartTotalCount: number;
  cartSubtotal: number;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

const CART_KEY = 'sokfarm_cart_v1';
const WISHLIST_KEY = 'sokfarm_wishlist_v1';
const USER_KEY = 'sokfarm_user_v1';
const LANG_KEY = 'sokfarm_lang_v1';
const CMP_KEY = 'sokfarm_cmp_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY) || '[]');
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<WishlistItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(WISHLIST_KEY) || '[]');
    } catch {
      return [];
    }
  });

  const [user, setUser] = useState<DemoUser | null>(() => {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });

  const [lang, setLangState] = useState<'vi' | 'en'>(() => {
    const saved = localStorage.getItem(LANG_KEY);
    return saved === 'en' ? 'en' : 'vi';
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [cmpBannerVisible, setCmpBannerVisible] = useState<boolean>(() => {
    return !localStorage.getItem(CMP_KEY);
  });
  const [cmpModalOpen, setCmpModalOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem(LANG_KEY, lang);
  }, [lang]);

  const notify = useCallback((text: string, type: 'success' | 'warning' | 'error' = 'success') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3200);
  }, []);

  const setLang = useCallback((l: 'vi' | 'en') => {
    setLangState(l);
  }, []);

  const addToCart = useCallback(
    (item: Omit<CartItem, 'quantity'>, qty = 1) => {
      setCart((prev) => {
        const idx = prev.findIndex((c) => c.productId === item.productId && c.code === item.code);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = { ...next[idx], quantity: next[idx].quantity + qty };
          return next;
        }
        return [...prev, { ...item, quantity: qty }];
      });
      notify(`Đã thêm "${item.title}" vào giỏ hàng!`, 'success');
    },
    [notify]
  );

  const setItemQtyInCart = useCallback((item: Omit<CartItem, 'quantity'>, qty: number) => {
    setCart((prev) => {
      if (qty <= 0) {
        return prev.filter((c) => !(c.productId === item.productId && c.code === item.code));
      }
      const idx = prev.findIndex((c) => c.productId === item.productId && c.code === item.code);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: qty };
        return next;
      }
      return [...prev, { ...item, quantity: qty }];
    });
  }, []);

  const updateCartQty = useCallback((productId: string, code: string, qty: number) => {
    setCart((prev) => {
      if (qty <= 0) {
        return prev.filter((c) => !(c.productId === productId && c.code === code));
      }
      return prev.map((c) =>
        c.productId === productId && c.code === code ? { ...c, quantity: qty } : c
      );
    });
  }, []);

  const removeFromCart = useCallback((productId: string, code: string) => {
    setCart((prev) => prev.filter((c) => !(c.productId === productId && c.code === code)));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const toggleWishlist = useCallback(
    (item: WishlistItem) => {
      let added = false;
      setWishlist((prev) => {
        const exists = prev.some((w) => w.code === item.code);
        if (exists) {
          added = false;
          return prev.filter((w) => w.code !== item.code);
        }
        added = true;
        return [...prev, item];
      });
      notify(added ? 'Đã thêm vào danh sách yêu thích!' : 'Đã xóa khỏi danh sách yêu thích!', 'success');
      return added;
    },
    [notify]
  );

  const removeFromWishlist = useCallback((code: string) => {
    setWishlist((prev) => prev.filter((w) => w.code !== code));
  }, []);

  const loginDemo = useCallback(
    (email: string, name?: string) => {
      const u: DemoUser = { email, name: name || email.split('@')[0] };
      setUser(u);
      localStorage.setItem(USER_KEY, JSON.stringify(u));
      notify('Đăng nhập thành công!', 'success');
    },
    [notify]
  );

  const logoutDemo = useCallback(() => {
    setUser(null);
    localStorage.removeItem(USER_KEY);
    notify('Đã đăng xuất tài khoản.', 'success');
  }, [notify]);

  const openCmpModal = useCallback(() => setCmpModalOpen(true), []);
  const closeCmpModal = useCallback(() => setCmpModalOpen(false), []);
  const saveCmpConsent = useCallback(() => {
    localStorage.setItem(CMP_KEY, 'saved');
    setCmpBannerVisible(false);
    setCmpModalOpen(false);
    notify('Đã lưu tùy chọn quyền riêng tư thành công!', 'success');
  }, [notify]);

  const cartTotalCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <AppContext.Provider
      value={{
        cart,
        wishlist,
        user,
        lang,
        toasts,
        cmpBannerVisible,
        cmpModalOpen,
        setLang,
        addToCart,
        updateCartQty,
        setItemQtyInCart,
        removeFromCart,
        clearCart,
        toggleWishlist,
        removeFromWishlist,
        loginDemo,
        logoutDemo,
        notify,
        openCmpModal,
        closeCmpModal,
        saveCmpConsent,
        cartTotalCount,
        cartSubtotal,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
